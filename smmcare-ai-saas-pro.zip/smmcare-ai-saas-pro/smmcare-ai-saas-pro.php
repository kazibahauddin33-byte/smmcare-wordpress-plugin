<?php
/*
Plugin Name: SMMCARE AI SaaS Pro
Description: Multi-tenant SaaS plugin with per-customer CRM, tickets, billing, social posting, Twilio, Google Calendar, AI tools, quotas, 2FA, and per-customer SMTP.
Version: 1.0.0
Author: SMMCARE
*/

if ( ! defined( 'ABSPATH' ) ) exit;

/* Basic constants */
if ( ! defined( 'SMMCARE_VERSION' ) ) define( 'SMMCARE_VERSION', '1.0.0' );
if ( ! defined( 'SMMCARE_FILE' ) ) define( 'SMMCARE_FILE', __FILE__ );
if ( ! defined( 'SMMCARE_DIR' ) ) define( 'SMMCARE_DIR', plugin_dir_path( SMMCARE_FILE ) );
if ( ! defined( 'SMMCARE_URL' ) ) define( 'SMMCARE_URL', plugin_dir_url( SMMCARE_FILE ) );

/**
 * Small helper: check if a table exists (returns boolean)
 */
function smmcare_table_exists( $table ) {
    global $wpdb;
    $table = trim( $table );
    if ( empty( $table ) ) return false;
    if ( strpos( $table, $wpdb->prefix ) === false && strpos( $table, 'smmcare_' ) === 0 ) {
        $table = $wpdb->prefix . $table;
    }
    $res = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
    return (bool) $res;
}

/**
 * Activation: create DB tables (idempotent)
 */
function smmcare_activate() {
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $sql = [];

    $sql[] = "CREATE TABLE {$wpdb->prefix}smmcare_customers (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      user_id BIGINT UNSIGNED DEFAULT 0,
      plan_slug VARCHAR(64) DEFAULT '',
      status VARCHAR(64) DEFAULT 'active',
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY user_id (user_id)
    ) $charset_collate;";

    $sql[] = "CREATE TABLE {$wpdb->prefix}smmcare_leads (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      customer_id BIGINT UNSIGNED DEFAULT 0,
      name VARCHAR(191) DEFAULT '',
      email VARCHAR(191) DEFAULT '',
      phone VARCHAR(50) DEFAULT '',
      company VARCHAR(191) DEFAULT '',
      tags TEXT,
      status VARCHAR(64) DEFAULT 'new',
      source VARCHAR(191) DEFAULT '',
      created_at DATETIME NOT NULL,
      updated_at DATETIME DEFAULT NULL,
      PRIMARY KEY (id),
      KEY customer_id (customer_id),
      KEY email (email)
    ) $charset_collate;";

    $sql[] = "CREATE TABLE {$wpdb->prefix}smmcare_lead_notes (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      lead_id BIGINT UNSIGNED NOT NULL,
      user_id BIGINT UNSIGNED DEFAULT 0,
      note TEXT,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY lead_id (lead_id)
    ) $charset_collate;";

    $sql[] = "CREATE TABLE {$wpdb->prefix}smmcare_tasks (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      customer_id BIGINT UNSIGNED NOT NULL,
      title VARCHAR(191) NOT NULL,
      description TEXT,
      due_date DATETIME DEFAULT NULL,
      status VARCHAR(50) DEFAULT 'open',
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY customer_id (customer_id)
    ) $charset_collate;";

    $sql[] = "CREATE TABLE {$wpdb->prefix}smmcare_tickets (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      customer_id BIGINT UNSIGNED DEFAULT 0,
      user_id BIGINT UNSIGNED DEFAULT 0,
      subject VARCHAR(191) DEFAULT '',
      status VARCHAR(50) DEFAULT 'open',
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY customer_id (customer_id)
    ) $charset_collate;";

    $sql[] = "CREATE TABLE {$wpdb->prefix}smmcare_ticket_messages (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      ticket_id BIGINT UNSIGNED NOT NULL,
      author_type VARCHAR(20) DEFAULT 'admin',
      author_id BIGINT UNSIGNED DEFAULT 0,
      message TEXT,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY ticket_id (ticket_id)
    ) $charset_collate;";

    $sql[] = "CREATE TABLE {$wpdb->prefix}smmcare_subscriptions (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      customer_id BIGINT UNSIGNED NOT NULL,
      stripe_subscription_id VARCHAR(191) DEFAULT '',
      plan_slug VARCHAR(64) DEFAULT '',
      status VARCHAR(64) DEFAULT '',
      current_period_end DATETIME DEFAULT NULL,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY customer_id (customer_id)
    ) $charset_collate;";

    $sql[] = "CREATE TABLE {$wpdb->prefix}smmcare_ai_logs (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      customer_id BIGINT UNSIGNED DEFAULT 0,
      endpoint VARCHAR(191),
      request_body LONGTEXT,
      response_body LONGTEXT,
      tokens_used BIGINT DEFAULT 0,
      cost_usd DECIMAL(10,4) DEFAULT 0,
      created_at DATETIME NOT NULL,
      PRIMARY KEY (id),
      KEY customer_id (customer_id)
    ) $charset_collate;";

    // Create tables only when they do not already exist.
    foreach ( $sql as $s ) {
        $table = false;
        if ( preg_match( '/CREATE\s+TABLE\s+`?([^`\s(]+)`?/i', $s, $m ) ) {
            $table = $m[1];
        } elseif ( preg_match( '/CREATE\s+TABLE\s+' . preg_quote( $wpdb->prefix, '/' ) . '([^\s(]+)/i', $s, $m2 ) ) {
            $table = $wpdb->prefix . $m2[1];
        }

        if ( $table && smmcare_table_exists( $table ) ) {
            error_log( "SMMCARE: Activation - table {$table} already exists; skipping dbDelta to avoid unsafe ALTERs." );
            continue;
        }

        dbDelta( $s );
    }

    // Ensure admin user has a customer record
    $user_id = get_current_user_id() ?: 0;
    if ( $user_id ) {
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}smmcare_customers WHERE user_id = %d LIMIT 1", $user_id ) );
        if ( ! $exists ) {
            $wpdb->insert( $wpdb->prefix . 'smmcare_customers', [ 'user_id'=>$user_id, 'plan_slug'=>'admin', 'status'=>'active', 'created_at'=>current_time('mysql') ] );
        }
    }

    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'smmcare_activate' );

/* Safe autoload/require of includes - require_once to avoid duplicates */
$includes = array(
  'includes/class-smmcare-multitenant.php',
  'includes/class-smmcare-settings.php',
  'includes/class-smmcare-pages.php',
  'includes/class-smmcare-email.php',
  'includes/class-smmcare-auth.php',
  'includes/class-smmcare-2fa.php',
  'includes/class-smmcare-social-store.php',
  'includes/class-smmcare-social-x.php',
  'includes/class-smmcare-social-linkedin.php',
  'includes/class-smmcare-social-facebook.php',
  'includes/class-smmcare-social-tiktok.php',
  'includes/class-smmcare-gcal.php',
  'includes/class-smmcare-twilio.php',
  'includes/class-smmcare-quotas.php',
  'includes/class-smmcare-ai.php',
  'includes/class-smmcare-ai-marketing.php',
  'includes/class-smmcare-crm.php',
  'includes/class-smmcare-crm-admin.php',
  'includes/class-smmcare-tickets.php',
  'includes/class-smmcare-subscriptions.php',
  'includes/class-smmcare-payments-stripe.php',
  'includes/class-smmcare-sms-campaigns.php',
  'includes/class-smmcare-reputation.php',
  'includes/class-smmcare-plans.php',
  'includes/class-smmcare-plans-admin.php',
  'includes/class-smmcare-customer.php',
  'includes/class-smmcare-front.php',
  'includes/class-smmcare-admin.php',
  'includes/class-smmcare-customer-ui.php',
  // ensure metrics is included so REST /metrics endpoints exist
  'includes/class-smmcare-metrics.php'
);

foreach ( $includes as $file ) {
    $path = SMMCARE_DIR . $file;
    if ( file_exists( $path ) ) {
        require_once $path;
    } else {
        error_log( "SMMCARE missing include: {$path}" );
    }
}

/* Start core services after includes */
add_action( 'plugins_loaded', function(){
    if ( class_exists( 'SMMCARE_Multitenant' ) ) SMMCARE_Multitenant::instance();
    if ( class_exists( 'SMMCARE_Settings' ) ) SMMCARE_Settings::instance();
    if ( class_exists( 'SMMCARE_Pages' ) ) SMMCARE_Pages::instance();
    if ( class_exists( 'SMMCARE_Email' ) ) SMMCARE_Email::instance();
    if ( class_exists( 'SMMCARE_Auth' ) ) SMMCARE_Auth::init();
    if ( class_exists( 'SMMCARE_2FA' ) ) SMMCARE_2FA::init();
    if ( class_exists( 'SMMCARE_Social_Store' ) ) SMMCARE_Social_Store::instance();
    if ( class_exists( 'SMMCARE_Twilio' ) ) SMMCARE_Twilio::instance();
    if ( class_exists( 'SMMCARE_AI' ) ) SMMCARE_AI::instance();
    if ( class_exists( 'SMMCARE_Quotas' ) ) SMMCARE_Quotas::init();
    if ( class_exists( 'SMMCARE_SMS_Campaigns' ) ) SMMCARE_SMS_Campaigns::init();
    if ( class_exists( 'SMMCARE_Plans' ) ) SMMCARE_Plans::instance();
    if ( class_exists( 'SMMCARE_Plans_Admin' ) ) SMMCARE_Plans_Admin::init();
    if ( class_exists( 'SMMCARE_Admin' ) ) SMMCARE_Admin::instance();
    if ( class_exists( 'SMMCARE_Customer' ) ) SMMCARE_Customer::instance();
    if ( class_exists( 'SMMCARE_CRM' ) ) SMMCARE_CRM::instance();
    if ( class_exists( 'SMMCARE_CRM_Admin' ) ) SMMCARE_CRM_Admin::instance();
    if ( class_exists( 'SMMCARE_Tickets' ) ) SMMCARE_Tickets::instance();
    if ( class_exists( 'SMMCARE_Subscriptions' ) ) SMMCARE_Subscriptions::instance();
    if ( class_exists( 'SMMCARE_Payments_Stripe' ) ) SMMCARE_Payments_Stripe::init();
    if ( class_exists( 'SMMCARE_Social_X' ) ) SMMCARE_Social_X::routes();
    if ( class_exists( 'SMMCARE_Social_Linkedin' ) ) SMMCARE_Social_Linkedin::routes();
    if ( class_exists( 'SMMCARE_Social_Facebook' ) ) SMMCARE_Social_Facebook::routes();
    if ( class_exists( 'SMMCARE_Social_Tiktok' ) ) SMMCARE_Social_Tiktok::routes();
    if ( class_exists( 'SMMCARE_GCal' ) ) SMMCARE_GCal::init();
    if ( class_exists( 'SMMCARE_Frontend' ) ) SMMCARE_Frontend::init();
    if ( class_exists( 'SMMCARE_Customer_UI' ) ) SMMCARE_Customer_UI::init();
    // initialize metrics so frontend can fetch /wp-json/smmcare/v1/metrics
    if ( class_exists( 'SMMCARE_Metrics' ) ) SMMCARE_Metrics::init();
}, 5 );

/* Enqueue front global assets */
add_action( 'wp_enqueue_scripts', function(){
    if ( file_exists( SMMCARE_DIR . 'assets/css/style.min.css' ) ) wp_enqueue_style( 'smmcare-global', SMMCARE_URL . 'assets/css/style.min.css', [], SMMCARE_VERSION );
    if ( file_exists( SMMCARE_DIR . 'assets/js/customer-frontend.js' ) ) {
        wp_enqueue_script( 'smmcare-customer-frontend', SMMCARE_URL . 'assets/js/customer-frontend.js', [ 'jquery' ], SMMCARE_VERSION, true );
        // Localize the script so front-end always has rest URL + nonce.
        wp_localize_script( 'smmcare-customer-frontend', 'smmcare', array(
            'rest_root' => esc_url_raw( rest_url( 'smmcare/v1' ) ),
            'rest_url'  => esc_url_raw( rest_url( 'smmcare/v1' ) ), // alias some scripts expect
            'nonce'     => wp_create_nonce( 'wp_rest' ),
        ) );
    }
}, 20 );

/* Admin activation check: if includes missing log a clear admin notice */
add_action( 'admin_notices', function() use ( $includes ) {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $missing = [];
    foreach ( $includes as $inc ) {
        $p = SMMCARE_DIR . $inc;
        if ( ! file_exists( $p ) ) $missing[] = $inc;
    }
    if ( ! empty( $missing ) ) {
        echo '<div class="notice notice-error"><p><strong>SMMCARE:</strong> some plugin files are missing. Check plugin folder. Missing files: <code>' . esc_html( implode( ', ', $missing ) ) . '</code></p></div>';
    }
} );
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AI Designer: image generation endpoints (DALL·E / Stable Diffusion adapter)
 * - For DALL·E via OpenAI key: calls OpenAI Images API (if key is present)
 * - For Stable Diffusion you'd wire external API
 */
class SMMCARE_AI_Designer {
    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
    }

    public static function routes() {
        register_rest_route( 'smmcare/v1', '/ai/image', [
            'methods' => 'POST',
            'callback' => [ __CLASS__, 'generate_image' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }

    public static function generate_image( WP_REST_Request $request ) {
        $p = $request->get_json_params();
        $prompt = sanitize_textarea_field( $p['prompt'] ?? '' );
        $size = sanitize_text_field( $p['size'] ?? '1024x1024' );

        if ( empty( $prompt ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'Prompt required' ], 400 );

        $openai_key = get_option( 'smmcare_openai_key', '' );
        if ( empty( $openai_key ) ) {
            // Return a placeholder data URL (1x1 PNG) so UI can behave gracefully
            $blank = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGNgYAAAAAMAAWgmWQ0AAAAASUVORK5CYII=';
            return rest_ensure_response( [ 'success' => true, 'data_url' => $blank, 'note' => 'No OpenAI key configured; placeholder image returned' ] );
        }

        // Call OpenAI Images API (example for DALL·E)
        $url = 'https://api.openai.com/v1/images/generations';
        $args = [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $openai_key,
            ],
            'body' => wp_json_encode( [
                'prompt' => $prompt,
                'n' => 1,
                'size' => $size,
            ] ),
            'timeout' => 45,
        ];

        $resp = wp_remote_post( $url, $args );
        if ( is_wp_error( $resp ) ) return rest_ensure_response( [ 'success' => false, 'message' => $resp->get_error_message() ], 500 );
        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( isset( $body['data'][0]['b64_json'] ) ) {
            $b64 = $body['data'][0]['b64_json'];
            $data_url = 'data:image/png;base64,' . $b64;
            return rest_ensure_response( [ 'success' => true, 'data_url' => $data_url ] );
        }
        // Some OpenAI images responses include url directly
        if ( isset( $body['data'][0]['url'] ) ) {
            return rest_ensure_response( [ 'success' => true, 'url' => $body['data'][0]['url'] ] );
        }

        return rest_ensure_response( [ 'success' => false, 'message' => 'Image generation failed', 'response' => $body ], 500 );
    }
}

SMMCARE_AI_Designer::init();
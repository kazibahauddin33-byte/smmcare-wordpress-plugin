<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Debug {
    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
    }

    public static function routes() {
        register_rest_route( 'smmcare/v1', '/debug/auth', [
            'methods' => 'GET',
            'callback' => [ __CLASS__, 'debug_auth' ],
            'permission_callback' => function(){ return current_user_can( 'manage_options' ); } // admin-only
        ] );
    }

    public static function debug_auth( WP_REST_Request $req ) {
        // return information about request and auth
        $headers = $req->get_headers();
        // Note: WP strips certain headers for security; we still return what WP sees
        $cookie_header = isset( $_SERVER['HTTP_COOKIE'] ) ? $_SERVER['HTTP_COOKIE'] : '';
        return rest_ensure_response( [
            'success' => true,
            'user_logged_in' => is_user_logged_in(),
            'current_user_id' => get_current_user_id(),
            'current_user_caps' => function_exists('wp_get_current_user') ? wp_get_current_user()->allcaps : [],
            'headers' => array(
                'X-WP-Nonce' => isset( $headers['x-wp-nonce'] ) ? $headers['x-wp-nonce'][0] : '',
                'Cookie' => $cookie_header,
            ),
            'server_time' => current_time( 'mysql' ),
        ] );
    }
}
SMMCARE_Debug::init();
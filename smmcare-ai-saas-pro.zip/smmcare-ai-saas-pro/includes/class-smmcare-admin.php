<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Admin {
    public static function instance() { static $i=null; if ( $i===null ) { $i=new self(); $i->hooks(); } return $i; }

    public function hooks() {
        add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'rest_api_init', [ $this, 'rest_routes' ] );
    }

    public function add_admin_menu() {
        add_menu_page( 'SMMCARE Pro', 'SMMCARE Pro', 'manage_options', 'smmcare-pro', [ $this, 'render_admin_dashboard' ], 'dashicons-chart-area', 58 );
        add_submenu_page( 'smmcare-pro', 'Customers', 'Customers', 'manage_options', 'smmcare-customers', [ $this, 'render_customers_page' ] );
        add_submenu_page( 'smmcare-pro', 'Tickets', 'Tickets', 'manage_options', 'smmcare-tickets', [ $this, 'render_tickets_page' ] );
    }

    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'smmcare-pro' ) === false ) return;
        wp_enqueue_style( 'smmcare-admin', SMMCARE_URL . 'assets/css/admin.css', [], SMMCARE_VERSION );
        wp_enqueue_style( 'smmcare-widgets', SMMCARE_URL . 'assets/css/widgets.css', [], SMMCARE_VERSION );
        wp_enqueue_style( 'smmcare-crm-variants', SMMCARE_URL . 'assets/css/crm-variants.css', [], SMMCARE_VERSION );
        wp_enqueue_script( 'smmcare-modal', SMMCARE_URL . 'assets/js/modal.js', [], SMMCARE_VERSION, true );
        wp_enqueue_script( 'smmcare-clipboard', SMMCARE_URL . 'assets/js/clipboard.js', [], SMMCARE_VERSION, true );
        wp_enqueue_script( 'chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '4.4.0', true );
        wp_enqueue_script( 'smmcare-charts-advanced', SMMCARE_URL . 'assets/js/charts-advanced.js', [ 'chart-js' ], SMMCARE_VERSION, true );
        wp_enqueue_script( 'smmcare-widgets', SMMCARE_URL . 'assets/js/widgets.js', [], SMMCARE_VERSION, true );
        wp_enqueue_script( 'react-js', 'https://unpkg.com/react@18/umd/react.production.min.js', [], '18.0.0', true );
        wp_enqueue_script( 'react-dom-js', 'https://unpkg.com/react-dom@18/umd/react-dom.production.min.js', [ 'react-js' ], '18.0.0', true );
        wp_enqueue_script( 'smmcare-admin-react', SMMCARE_URL . 'assets/js/admin-react-app.js', [ 'react-dom-js', 'smmcare-charts-advanced', 'smmcare-widgets' ], SMMCARE_VERSION, true );
        wp_enqueue_script( 'smmcare-admin-js', SMMCARE_URL . 'assets/js/admin-frontend.js', [ 'jquery' ], SMMCARE_VERSION, true );
        // Localize admin script with rest and ajax helpers + nonce
        wp_localize_script( 'smmcare-admin-js', 'smmcareAdmin', [
            'rest_root' => esc_url_raw( rest_url( 'smmcare/v1' ) ),
            'rest_url'  => esc_url_raw( rest_url( 'smmcare/v1' ) ), // alias for scripts which expect rest_url
            'ajax_url'  => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
            'nonce'     => wp_create_nonce( 'wp_rest' ),
        ] );
    }

    public function render_admin_dashboard() {
        if ( ! current_user_can('manage_options') ) return;
        ?>
        <div class="wrap">
          <h1>SMMCARE Pro — Admin Dashboard</h1>
          <div id="smmcare-admin-react-root"></div>
        </div>
        <?php
    }

    public function render_customers_page() {
        if ( ! current_user_can('manage_options') ) return;
        echo '<div class="wrap"><h1>Customers</h1><div id="smmcare-customers-list">Loading…</div></div>';
    }

    public function render_tickets_page() {
        if ( ! current_user_can('manage_options') ) return;
        echo '<div class="wrap"><h1>Tickets</h1><div id="smmcare-tickets-list">Loading…</div></div>';
    }

    public function rest_routes() {
        register_rest_route( 'smmcare/v1', '/admin/customers', [ 'methods'=>'GET','callback'=>[ $this, 'rest_list_customers' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/admin/customers/(?P<id>\d+)/impersonate', [ 'methods'=>'POST','callback'=>[ $this, 'rest_impersonate_customer' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/admin/tickets', [ 'methods'=>'GET','callback'=>[ $this, 'rest_list_tickets' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/admin/tickets/(?P<id>\d+)/reply', [ 'methods'=>'POST','callback'=>[ $this, 'rest_reply_ticket' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/admin/customers/(?P<id>\d+)/plan', [ 'methods'=>'POST','callback'=>[ $this, 'rest_change_plan' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/metrics/admin', [ 'methods'=>'GET','callback'=>[ $this, 'rest_admin_metrics' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
    }

    public function rest_list_customers() {
        global $wpdb;
        $rows = $wpdb->get_results( "SELECT c.*, u.user_login, u.user_email FROM {$wpdb->prefix}smmcare_customers c LEFT JOIN {$wpdb->users} u ON u.ID = c.user_id ORDER BY c.created_at DESC", ARRAY_A );
        return rest_ensure_response([ 'success'=>true,'data'=>$rows ]);
    }

    public function rest_impersonate_customer( $req ) {
        $id = intval( $req->get_param('id') );
        global $wpdb;
        $user_id = $wpdb->get_var( $wpdb->prepare("SELECT user_id FROM {$wpdb->prefix}smmcare_customers WHERE id=%d LIMIT 1",$id) );
        if ( ! $user_id ) return rest_ensure_response([ 'success'=>false,'message'=>'Customer not found' ],404);
        $secret = wp_generate_password(32,true,true);
        set_transient( 'smmcare_impersonate_'.$secret, intval($user_id), HOUR_IN_SECONDS );
        $url = add_query_arg( [ 'smmcare_impersonate'=>$secret ], home_url() );
        return rest_ensure_response([ 'success'=>true,'url'=>$url ]);
    }

    public function rest_list_tickets() {
        global $wpdb;
        $rows = $wpdb->get_results( "SELECT t.*, c.user_id FROM {$wpdb->prefix}smmcare_tickets t LEFT JOIN {$wpdb->prefix}smmcare_customers c ON c.id = t.customer_id ORDER BY t.created_at DESC", ARRAY_A );
        return rest_ensure_response([ 'success'=>true,'data'=>$rows ]);
    }

    public function rest_reply_ticket( $req ) {
        $id = intval($req->get_param('id'));
        $params = $req->get_json_params();
        $message = sanitize_textarea_field($params['message'] ?? '');
        if ( empty($message) ) return rest_ensure_response([ 'success'=>false,'message'=>'Message required' ],400);
        global $wpdb;
        $ticket = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->prefix}smmcare_tickets WHERE id=%d",$id) );
        if ( ! $ticket ) return rest_ensure_response([ 'success'=>false,'message'=>'Not found' ],404);
        $wpdb->insert( $wpdb->prefix . 'smmcare_ticket_messages', [ 'ticket_id'=>$id,'author_type'=>'admin','author_id'=>get_current_user_id(),'message'=>$message,'created_at'=>current_time('mysql') ] );
        $customer = $wpdb->get_row( $wpdb->prepare("SELECT c.*, u.user_email FROM {$wpdb->prefix}smmcare_customers c LEFT JOIN {$wpdb->users} u ON u.ID = c.user_id WHERE c.id=%d LIMIT 1", $ticket->customer_id ) );
        if ( $customer && ! empty($customer->user_email) ) SMMCARE_Email::instance()->send_email( $customer->user_email, "Reply to ticket: ".$ticket->subject, nl2br(esc_html($message)), $ticket->customer_id );
        return rest_ensure_response([ 'success'=>true ]);
    }

    public function rest_change_plan( $req ) {
        $id = intval($req->get_param('id'));
        $p = $req->get_json_params();
        $plan = sanitize_text_field($p['plan'] ?? '');
        if ( empty($plan) ) return rest_ensure_response([ 'success'=>false,'message'=>'Plan required' ],400);
        global $wpdb;
        $updated = $wpdb->update( $wpdb->prefix.'smmcare_customers', [ 'plan_slug'=>$plan ], [ 'id'=>$id ] );
        if ( $updated === false ) return rest_ensure_response([ 'success'=>false,'message'=>'Update failed' ],500);
        return rest_ensure_response([ 'success'=>true ]);
    }

    public function rest_admin_metrics() {
        global $wpdb;
        $total_customers = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_customers" );
        $total_tasks = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_tasks" );
        $total_campaigns = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_sms_campaigns" );
        $chart = [
          'labels' => [ 'Mon','Tue','Wed','Thu','Fri','Sat','Sun' ],
          'datasets' => [ [ 'label'=> 'Active Users', 'data'=> [12,19,7,15,22,13,9], 'borderColor'=> '#4a9df8', 'backgroundColor'=> 'rgba(74,157,248,0.08)' ] ]
        ];
        return rest_ensure_response([ 'success'=>true, 'data'=>[ 'total_customers'=> $total_customers, 'total_tasks'=> $total_tasks, 'total_campaigns'=> $total_campaigns, 'chart' => $chart, 'ai_usage' => [ 'tokens' => (int) $wpdb->get_var( "SELECT COALESCE(SUM(tokens_used),0) FROM {$wpdb->prefix}smmcare_ai_logs" ) ] ] ]);
    }
}
SMMCARE_Admin::instance();
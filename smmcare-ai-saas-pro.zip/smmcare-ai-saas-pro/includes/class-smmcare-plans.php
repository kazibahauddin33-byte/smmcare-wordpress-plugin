<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Plans {
    // Use an instance property to avoid static/non-static mismatch and dynamic property deprecation.
    private $plans = null;

    public static function instance() {
        static $i = null;
        if ( $i === null ) {
            $i = new self();
            $i->init();
        }
        return $i;
    }

    private function init() {
        // initialize instance property
        $this->plans = [
            'starter' => [
                'slug' => 'starter',
                'name' => 'Starter',
                'price_usd_month' => 19,
                'features' => [ 'AI credits', 'CRM basic' ],
            ],
            'pro' => [
                'slug' => 'pro',
                'name' => 'Pro',
                'price_usd_month' => 49,
                'features' => [ 'AI credits', 'CRM advanced', 'Priority Support' ],
            ],
            'enterprise' => [
                'slug' => 'enterprise',
                'name' => 'Enterprise',
                'price_usd_month' => 199,
                'features' => [ 'Unlimited AI', 'White-labeling' ],
            ],
        ];

        add_action( 'rest_api_init', [ $this, 'routes' ] );
    }

    public function routes() {
        register_rest_route( 'smmcare/v1', '/plans', [
            'methods' => 'GET',
            'callback' => [ $this, 'rest_list_plans' ],
            'permission_callback' => function(){ return is_user_logged_in(); }
        ] );

        register_rest_route( 'smmcare/v1', '/admin/plans', [
            'methods' => 'GET',
            'callback' => [ $this, 'rest_list_plans_admin' ],
            'permission_callback' => function(){ return current_user_can('manage_options'); }
        ] );

        register_rest_route( 'smmcare/v1', '/admin/customers/(?P<id>\d+)/plan', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_admin_change_plan' ],
            'permission_callback' => function(){ return current_user_can('manage_options'); }
        ] );
    }

    public function rest_list_plans() {
        return rest_ensure_response( [ 'success' => true, 'data' => array_values( $this->plans ) ] );
    }

    public function rest_list_plans_admin() {
        $settings = get_option( 'smmcare_settings', [] );
        // copy plans so we don't mutate the original
        $out = $this->plans;
        foreach ( $out as $k => &$p ) {
            $p['stripe_price_id'] = $settings[ 'stripe_price_' . $k ] ?? '';
        }
        return rest_ensure_response( [ 'success' => true, 'data' => array_values( $out ) ] );
    }

    public function rest_admin_change_plan( $req ) {
        global $wpdb;
        $id = intval( $req->get_param( 'id' ) );
        $p = $req->get_json_params();
        $plan = sanitize_text_field( $p['plan'] ?? '' );
        if ( empty( $plan ) || ! isset( $this->plans[ $plan ] ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Invalid plan' ], 400 );
        }
        $updated = $wpdb->update( $wpdb->prefix . 'smmcare_customers', [ 'plan_slug' => $plan ], [ 'id' => $id ] );
        if ( $updated === false ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Update failed' ], 500 );
        }
        SMMCARE_Subscriptions::upsert( $id, 'manual-' . $plan . '-' . time(), $plan, 'active', null );
        return rest_ensure_response( [ 'success' => true ] );
    }
}
SMMCARE_Plans::instance();
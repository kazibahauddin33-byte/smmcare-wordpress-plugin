<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Google Reviews invitation helper
 *
 * Stores a Google Place ID in option 'smmcare_google_place_id' and
 * exposes endpoints to generate a review link and send invites (email).
 *
 * Usage:
 *  - Admin sets Place ID in plugin settings (or use WP CLI):
 *      wp option update smmcare_google_place_id "ChIJ...PLACEID"
 *
 *  - REST endpoints (requires auth):
 *      GET  /wp-json/smmcare/v1/reviews/google/config      (manage_options)
 *      POST /wp-json/smmcare/v1/reviews/google/config      (manage_options) { place_id }
 *      POST /wp-json/smmcare/v1/reviews/google/send        (logged-in) { to, subject?, message? }
 */
class SMMCARE_Reviews_Google {
    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
    }

    public static function routes() {
        register_rest_route( 'smmcare/v1', '/reviews/google/config', [
            [
                'methods' => 'GET',
                'callback' => [ __CLASS__, 'get_config' ],
                'permission_callback' => function() { return current_user_can( 'manage_options' ); },
            ],
            [
                'methods' => 'POST',
                'callback' => [ __CLASS__, 'save_config' ],
                'permission_callback' => function() { return current_user_can( 'manage_options' ); },
                'args' => [
                    'place_id' => [ 'required' => true, 'type' => 'string' ],
                ],
            ],
        ] );

        register_rest_route( 'smmcare/v1', '/reviews/google/send', [
            'methods' => 'POST',
            'callback' => [ __CLASS__, 'send_invite' ],
            'permission_callback' => function() { return is_user_logged_in() && current_user_can( 'manage_options' ); },
            'args' => [
                'to' => [ 'required' => true, 'type' => 'string' ],
                'subject' => [ 'required' => false, 'type' => 'string' ],
                'message' => [ 'required' => false, 'type' => 'string' ],
            ],
        ] );
    }

    public static function get_config( $request ) {
        $place_id = get_option( 'smmcare_google_place_id', '' );
        return rest_ensure_response( [ 'success' => true, 'place_id' => $place_id ] );
    }

    public static function save_config( $request ) {
        $params = $request->get_json_params();
        $place_id = sanitize_text_field( $params['place_id'] ?? '' );
        if ( empty( $place_id ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'place_id required' ], 400 );
        }
        update_option( 'smmcare_google_place_id', $place_id );
        return rest_ensure_response( [ 'success' => true, 'place_id' => $place_id ] );
    }

    /**
     * build_review_link
     * Uses the canonical Google "write a review" URL for Business Profiles:
     *   https://search.google.com/local/writereview?placeid=PLACE_ID
     */
    public static function build_review_link( $place_id ) {
        $place_id = trim( $place_id );
        if ( empty( $place_id ) ) return '';
        return 'https://search.google.com/local/writereview?placeid=' . rawurlencode( $place_id );
    }

    public static function send_invite( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $to = sanitize_email( $params['to'] ?? '' );
        $subject = sanitize_text_field( $params['subject'] ?? 'Please leave us a review' );
        $message = wp_kses_post( $params['message'] ?? '' );

        if ( empty( $to ) || ! is_email( $to ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Valid recipient required' ], 400 );
        }

        $place_id = get_option( 'smmcare_google_place_id', '' );
        if ( empty( $place_id ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Google Place ID not configured' ], 400 );
        }

        $link = self::build_review_link( $place_id );

        $body  = '<p>Hi,</p>';
        $body .= '<p>We would really appreciate a quick review of our business on Google. It takes less than a minute. Thank you!</p>';
        if ( ! empty( $message ) ) {
            $body .= '<p>' . wp_kses_post( nl2br( esc_html( $message ) ) ) . '</p>';
        }
        $body .= '<p><a href="' . esc_url( $link ) . '" target="_blank" rel="noopener noreferrer">Leave a Google review</a></p>';
        $body .= '<p>Thanks,<br/>' . esc_html( get_bloginfo( 'name' ) ) . '</p>';

        // send via SMMCARE_Email abstraction if available, fallback to wp_mail
        if ( class_exists( 'SMMCARE_Email' ) ) {
            $ok = SMMCARE_Email::instance()->send_email( $to, $subject, $body );
        } else {
            $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
            $ok = wp_mail( $to, $subject, $body, $headers );
        }

        if ( $ok ) {
            return rest_ensure_response( [ 'success' => true, 'message' => 'Invite sent', 'review_link' => $link ] );
        }
        return rest_ensure_response( [ 'success' => false, 'message' => 'Send failed' ], 500 );
    }
}

SMMCARE_Reviews_Google::init();
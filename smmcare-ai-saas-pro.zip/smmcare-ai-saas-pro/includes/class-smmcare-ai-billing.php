<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * AI billing helpers:
 * - Estimate costs per model/token (admin configurable via options)
 * - Endpoint to return estimated cost of a request and to reconcile logged ai_logs
 */
class SMMCARE_AI_Billing {
    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
    }

    public static function routes() {
        register_rest_route( 'smmcare/v1', '/ai/cost/estimate', [
            'methods' => 'POST',
            'callback' => [ __CLASS__, 'estimate' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/ai/admin/usage', [
            'methods' => 'GET',
            'callback' => [ __CLASS__, 'admin_usage' ],
            'permission_callback' => function(){ return current_user_can( 'manage_options' ); },
        ] );
    }

    public static function estimate( WP_REST_Request $request ) {
        $p = $request->get_json_params();
        $model = sanitize_text_field( $p['model'] ?? 'gpt-3.5-turbo' );
        $tokens = intval( $p['tokens'] ?? 0 );
        if ( $tokens <= 0 ) return rest_ensure_response( [ 'success' => false, 'message' => 'tokens required' ], 400 );

        // pricing map (admin can override via option)
        $pricing = get_option( 'smmcare_ai_pricing', [
            'gpt-3.5-turbo' => 0.000002, // USD per token (example)
            'gpt-4' => 0.00006,
            'gpt-4o' => 0.00005,
        ] );
        $unit = isset( $pricing[$model] ) ? $pricing[$model] : $pricing['gpt-3.5-turbo'];
        $cost = round( $tokens * (float) $unit, 6 );

        return rest_ensure_response( [ 'success' => true, 'model' => $model, 'tokens' => $tokens, 'estimated_usd' => $cost ] );
    }

    public static function admin_usage( WP_REST_Request $request ) {
        global $wpdb;
        $from = sanitize_text_field( $request->get_param( 'from' ) ?? date( 'Y-m-d', strtotime( '-30 days' ) ) );
        $to = sanitize_text_field( $request->get_param( 'to' ) ?? date( 'Y-m-d' ) );

        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT customer_id, SUM(tokens_used) as tokens, SUM(cost_usd) as cost FROM {$wpdb->prefix}smmcare_ai_logs WHERE created_at BETWEEN %s AND %s GROUP BY customer_id", $from . ' 00:00:00', $to . ' 23:59:59' ) );

        return rest_ensure_response( [ 'success' => true, 'data' => $rows ] );
    }
}

SMMCARE_AI_Billing::init();
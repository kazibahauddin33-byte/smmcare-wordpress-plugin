<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMS integration (Twilio adapter placeholder)
 * - stores SMS sends in a lightweight log (ai_logs could be used, but keep separate)
 * - requires Twilio credentials in options or user meta
 */
class SMMCARE_SMS {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/sms/send', [
            'methods' => 'POST',
            'callback' => [ $this, 'send_sms' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }

    public function send_sms( WP_REST_Request $request ) {
        $p = $request->get_json_params();
        $to = sanitize_text_field( $p['to'] ?? '' );
        $message = sanitize_textarea_field( $p['message'] ?? '' );
        $user = get_current_user_id();

        if ( empty( $to ) || empty( $message ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'To and message required' ], 400 );
        // Check Twilio config
        $tw_sid = get_option( 'smmcare_twilio_sid', '' );
        $tw_token = get_option( 'smmcare_twilio_token', '' );
        $tw_from = get_option( 'smmcare_twilio_from', '' );

        if ( empty( $tw_sid ) || empty( $tw_token ) || empty( $tw_from ) ) {
            // fallback: record as queued
            global $wpdb;
            $table = $wpdb->prefix . 'smmcare_reviews'; // reuse reviews table as lightweight queue if no SMS table
            $wpdb->insert( $table, [
                'customer_id' => $user,
                'recipient' => $to,
                'status' => 'sms_queued',
                'message' => $message,
                'created_at' => current_time( 'mysql' ),
            ], [ '%d','%s','%s','%s','%s' ] );
            return rest_ensure_response( [ 'success' => true, 'queued' => true ] );
        }

        // Example Twilio REST call (requires curl or WP HTTP)
        $body = [
            'From' => $tw_from,
            'To' => $to,
            'Body' => $message,
        ];
        $url = "https://api.twilio.com/2010-04-01/Accounts/{$tw_sid}/Messages.json";
        $args = [
            'body' => $body,
            'headers' => [ 'Authorization' => 'Basic ' . base64_encode( $tw_sid . ':' . $tw_token ) ],
            'timeout' => 20,
        ];
        $resp = wp_remote_post( $url, $args );
        if ( is_wp_error( $resp ) ) return rest_ensure_response( [ 'success' => false, 'message' => $resp->get_error_message() ], 500 );
        $code = wp_remote_retrieve_response_code( $resp );
        if ( $code >= 200 && $code < 300 ) {
            return rest_ensure_response( [ 'success' => true, 'message' => 'Sent' ] );
        }
        return rest_ensure_response( [ 'success' => false, 'message' => 'Twilio API error', 'http_code' => $code ], 500 );
    }
}

SMMCARE_SMS::instance();
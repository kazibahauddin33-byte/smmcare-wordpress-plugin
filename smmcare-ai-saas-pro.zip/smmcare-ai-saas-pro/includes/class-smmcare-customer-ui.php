<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Customer_UI {
    public static function init() {
        add_shortcode( 'smmcare-customer-settings', [ __CLASS__, 'shortcode_settings' ] );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] );
    }

    public static function enqueue_assets() {
        if ( ! is_singular() ) return;
        wp_enqueue_script( 'smmcare-customer-settings', SMMCARE_URL . 'assets/js/customer-settings.js', [ 'jquery' ], SMMCARE_VERSION, true );
        wp_enqueue_style( 'smmcare-customer-settings-css', SMMCARE_URL . 'assets/css/customer-settings.css', [], SMMCARE_VERSION );
        wp_localize_script( 'smmcare-customer-settings', 'smmcareCustomer', [
            'rest_root' => esc_url_raw( rest_url( 'smmcare/v1' ) ),
            'nonce' => wp_create_nonce( 'wp_rest' ),
        ] );
    }

    public static function shortcode_settings( $atts ) {
        if ( ! is_user_logged_in() ) return '<p>Please log in to manage your settings.</p>';
        ob_start();
        ?>
        <div class="smmcare-customer-settings card" style="max-width:820px;padding:16px;">
            <h3>Your Email & Security</h3>

            <div class="smmcare-section">
                <h4>SMTP Settings</h4>
                <div id="smmcare-customer-smtp-form">
                    <label>Host</label><input id="smmcare-customer-smtp-host" />
                    <label>Port</label><input id="smmcare-customer-smtp-port" />
                    <label>Username</label><input id="smmcare-customer-smtp-user" />
                    <label>Password</label><input id="smmcare-customer-smtp-pass" type="password" />
                    <label>From Address</label><input id="smmcare-customer-smtp-from" />
                    <label>Encryption</label>
                    <select id="smmcare-customer-smtp-enc"><option value="">None</option><option value="ssl">SSL</option><option value="tls">TLS</option></select>
                    <div style="margin-top:10px;"><button id="smmcare-customer-smtp-save" class="button button-primary">Save SMTP</button> <span id="smmcare-customer-smtp-status"></span></div>
                </div>
            </div>

            <div class="smmcare-section" style="margin-top:12px;">
                <h4>Two-Factor Authentication</h4>
                <div id="smmcare-customer-2fa">
                    <label><input type="checkbox" id="smmcare-customer-2fa-enable" /> Enable 2FA (OTP)</label>
                    <div id="smmcare-customer-2fa-actions" style="margin-top:8px;">
                        <button id="smmcare-customer-2fa-request" class="button">Request Code</button>
                        <input id="smmcare-customer-2fa-code" placeholder="Enter code" style="width:160px;margin-left:8px" />
                        <button id="smmcare-customer-2fa-verify" class="button button-primary">Verify & Enable</button>
                    </div>
                    <div id="smmcare-customer-2fa-status"></div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
SMMCARE_Customer_UI::init();
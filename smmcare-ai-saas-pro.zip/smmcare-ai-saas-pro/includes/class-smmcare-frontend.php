<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Frontend {
    public static function init() {
        add_action( 'init', [ __CLASS__, 'add_rewrites' ] );
        add_filter( 'query_vars', [ __CLASS__, 'add_query_vars' ] );
        add_filter( 'template_include', [ __CLASS__, 'maybe_load_template' ], 20 );
    }
    public static function add_query_vars( $vars ) {
        $vars[] = 'smmcare_page';
        return $vars;
    }
    public static function add_rewrites() {
        $pages = [ 'dashboard','ai-tools','crm','planner','reviews','campaigns','customer-login','customer-signup','billing','admin-dashboard' ];
        foreach ( $pages as $s ) {
            add_rewrite_rule( '^' . $s . '/?$', 'index.php?smmcare_page=' . $s, 'top' );
        }
    }
    public static function maybe_load_template( $template ) {
        $page = get_query_var( 'smmcare_page' );
        if ( empty( $page ) ) return $template;
        $tpl_file = SMMCARE_DIR . 'templates/' . sanitize_file_name( $page ) . '.php';
        if ( file_exists( $tpl_file ) ) {
            include $tpl_file;
            exit;
        }
        return $template;
    }
}
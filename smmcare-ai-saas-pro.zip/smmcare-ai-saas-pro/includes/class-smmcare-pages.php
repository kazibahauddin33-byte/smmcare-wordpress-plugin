<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Pages {
    private static $instance = null;
    private $pages = [
        'dashboard'      => [ 'title' => 'Dashboard',       'slug' => 'dashboard' ],
        'crm'            => [ 'title' => 'CRM',             'slug' => 'crm' ],
        'campaigns'      => [ 'title' => 'Campaigns',       'slug' => 'campaigns' ],
        'billing'        => [ 'title' => 'Billing',         'slug' => 'billing' ],
        'admin-dashboard'=> [ 'title' => 'Admin Dashboard', 'slug' => 'admin-dashboard' ],
        'smmcare-2fa-verify' => [ 'title' => 'Verify 2FA',  'slug' => 'smmcare-2fa-verify' ],
    ];

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    private function hooks() {
        add_action( 'admin_init', [ $this, 'ensure_pages_exist' ] );
        add_action( 'init', [ $this, 'maybe_recreate_via_query' ] );
    }

    public function maybe_recreate_via_query() {
        if ( ! is_admin() ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( isset( $_GET['smmcare_recreate_pages'] ) && $_GET['smmcare_recreate_pages'] == '1' ) {
            $this->ensure_pages_exist( true );
            wp_safe_redirect( remove_query_arg( 'smmcare_recreate_pages' ) );
            exit;
        }
    }

    public function ensure_pages_exist( $force = false ) {
        if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) return;
        $existing = get_option( 'smmcare_pages', [] );
        $created = false;

        foreach ( $this->pages as $key => $p ) {
            $slug = $p['slug'];
            if ( ! $force && ! empty( $existing[ $key ] ) ) {
                $post = get_post( intval( $existing[ $key ] ) );
                if ( $post && $post->post_status !== 'trash' ) continue;
            }

            $by_path = get_page_by_path( $slug );
            if ( $by_path ) {
                $existing[ $key ] = $by_path->ID;
                $created = true;
                continue;
            }

            $content = $this->default_content_for( $key );
            $page_data = [
                'post_title'   => wp_strip_all_tags( $p['title'] ),
                'post_name'    => $slug,
                'post_content' => $content,
                'post_status'  => 'publish',
                'post_type'    => 'page',
            ];
                        $post_id = wp_insert_post( $page_data );
            if ( is_wp_error( $post_id ) || $post_id === 0 ) {
                $msg = is_wp_error( $post_id ) ? $post_id->get_error_message() : 'unknown';
                error_log( 'SMMCARE: failed to create page ' . $slug . ' - ' . $msg );
                continue;
            }
            $existing[ $key ] = intval( $post_id );
            $created = true;
        }

        if ( $created || $force ) {
            update_option( 'smmcare_pages', $existing );
            flush_rewrite_rules();
        }
    }

    private function default_content_for( $key ) {
        switch ( $key ) {
            case 'dashboard':
                return '<div id="smmcare-customer-kpis" class="smmcare-dashboard"></div><!-- [smmcare_dashboard] -->';
            case 'crm':
                return '<div id="smmcare-crm-root"><!-- CRM will render here --></div><!-- [smmcare_crm] -->';
            case 'campaigns':
                return '<div id="smmcare-campaigns-root"><!-- Campaigns UI --></div><!-- [smmcare_campaigns] -->';
            case 'billing':
                return '<div id="smmcare-billing-root"><!-- Billing UI --></div><!-- [smmcare_billing] -->';
            case 'admin-dashboard':
                return '<div id="smmcare-admin-react-root"><!-- Admin React app mounts here --></div>';
            case 'smmcare-2fa-verify':
                return '<!-- SMMCARE 2FA verify page --><div id="smmcare-2fa-root"></div>';
            default:
                return '<div id="smmcare-root"></div>';
        }
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class SMMCARE_Customer {
    private static $instance = null;
    private $customer_id = 0;
    public static function instance() { if ( null === self::$instance ) { self::$instance = new self(); add_action( 'init', [ self::$instance, 'resolve' ] ); add_action( 'rest_api_init', [ self::$instance, 'routes' ] ); } return self::$instance; }
    public function resolve() { $this->customer_id = SMMCARE_Multitenant::instance()->get_customer_id(); }
    public function get_customer_id() { return $this->customer_id; }
    public function routes() {
        register_rest_route( 'smmcare/v1', '/customer/branding', [ 'methods'=>'GET','callback'=>[ $this, 'rest_get_branding' ], 'permission_callback'=>function(){ return is_user_logged_in(); } ] );
        register_rest_route( 'smmcare/v1', '/customer/branding', [ 'methods'=>'POST','callback'=>[ $this, 'rest_save_branding' ], 'permission_callback'=>function(){ return is_user_logged_in(); } ] );
        register_rest_route( 'smmcare/v1', '/customer/smtp', [ 'methods'=>'GET','callback'=>[ $this, 'rest_get_smtp' ], 'permission_callback'=>function(){ return is_user_logged_in(); } ] );
        register_rest_route( 'smmcare/v1', '/customer/smtp', [ 'methods'=>'POST','callback'=>[ $this, 'rest_save_smtp' ], 'permission_callback'=>function(){ return is_user_logged_in(); } ] );
    }
    public function rest_get_branding() { $cid = $this->customer_id; if ( ! $cid ) return rest_ensure_response([ 'success'=>false,'message'=>'No customer' ],403); $data = get_option( "smmcare_customer_branding_{$cid}", [] ); return rest_ensure_response([ 'success'=>true,'data'=>$data ]); }
    public function rest_save_branding( $r ) { $cid = $this->customer_id; if ( ! $cid ) return rest_ensure_response([ 'success'=>false,'message'=>'No customer' ],403); $p = $r->get_json_params(); $allowed=['logo','accent_color','theme_mode','footer_text']; $save=[]; foreach($allowed as $k) if ( isset($p[$k]) ) $save[$k]=sanitize_text_field($p[$k]); update_option( "smmcare_customer_branding_{$cid}", $save ); return rest_ensure_response([ 'success'=>true,'data'=>$save ]); }
    public function rest_get_smtp() { $cid = $this->customer_id; if ( ! $cid ) return rest_ensure_response([ 'success'=>false,'message'=>'No customer' ],403); $data = get_option( "smmcare_customer_smtp_{$cid}", [] ); if ( isset($data['pass']) ) $data['pass'] = substr( $data['pass'],0,4 ) . '••••'; return rest_ensure_response([ 'success'=>true,'data'=>$data ]); }
    public function rest_save_smtp( $r ) { $cid = $this->customer_id; if ( ! $cid ) return rest_ensure_response([ 'success'=>false,'message'=>'No customer' ],403); $p = $r->get_json_params(); $save = ['host'=>sanitize_text_field($p['host']??''),'port'=>intval($p['port']??587),'user'=>sanitize_text_field($p['user']??''),'pass'=>sanitize_text_field($p['pass']??''),'from'=>sanitize_text_field($p['from']??get_option('admin_email')),'enc'=>sanitize_text_field($p['enc']??'')]; $settings = SMMCARE_Settings::instance(); $save['pass'] = $settings->maybe_encrypt( $save['pass'] ); update_option( "smmcare_customer_smtp_{$cid}", $save ); return rest_ensure_response([ 'success'=>true ]); }
    public function get_customer_smtp( $cid = 0 ) { $cid = $cid ?: $this->customer_id; if ( ! $cid ) return null; $s = get_option( "smmcare_customer_smtp_{$cid}", [] ); if ( ! $s ) return null; $settings = SMMCARE_Settings::instance(); if ( isset( $s['pass'] ) ) $s['pass'] = $settings->maybe_decrypt( $s['pass'] ); return $s; }
}
SMMCARE_Customer::instance();
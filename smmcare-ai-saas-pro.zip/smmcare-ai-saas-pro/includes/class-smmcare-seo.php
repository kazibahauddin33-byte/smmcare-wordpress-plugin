<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SEO module
 * - On-page analyzer using SMMCARE_AI (OpenAI) for suggestions
 * - Sitemap generator (writes sitemap.xml to uploads)
 * - Meta tag helper endpoint
 */
class SMMCARE_SEO {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }
    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'routes' ] );
        add_action( 'init', [ $this, 'maybe_register_sitemap_rewrite' ] );
    }

    public function routes() {
        register_rest_route( 'smmcare/v1', '/seo/analyze', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_analyze' ],
            'permission_callback' => function(){ return current_user_can( 'edit_posts' ); }
        ] );
        register_rest_route( 'smmcare/v1', '/seo/sitemap', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_generate_sitemap' ],
            'permission_callback' => function(){ return current_user_can( 'manage_options' ); }
        ] );
        register_rest_route( 'smmcare/v1', '/seo/meta', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_meta_suggestions' ],
            'permission_callback' => function(){ return current_user_can( 'edit_posts' ); }
        ] );
    }

    public function rest_analyze( WP_REST_Request $req ) {
        $params = $req->get_json_params();
        $content = sanitize_textarea_field( $params['content'] ?? '' );
        $url = esc_url_raw( $params['url'] ?? '' );
        if ( empty( $content ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'content required' ], 400 );
        // Use SMMCARE_AI if present
        if ( class_exists( 'SMMCARE_AI' ) ) {
            $ai = SMMCARE_AI::instance();
            // call the AI endpoint internally (but we have no direct method, so call REST)
            $prompt = "Analyze the following page content for SEO improvements. Provide: title suggestion, meta description (max 160 chars), keywords list (comma-separated), 3 recommended H2 headings, and a short content optimization checklist.\n\nContent:\n" . $content;
            $response = wp_remote_post( rest_url( 'smmcare/v1/ai/generate' ), [
                'headers' => [ 'Content-Type' => 'application/json' ],
                'body' => wp_json_encode( [ 'prompt' => $prompt, 'model' => 'gpt-3.5-turbo' ] ),
                'timeout' => 30,
            ] );
            $body = wp_remote_retrieve_body( $response );
            $data = json_decode( $body, true );
            return rest_ensure_response( [ 'success' => true, 'ai' => $data ] );
        }
        // fallback simple analysis
        $word_count = str_word_count( wp_strip_all_tags( $content ) );
        $suggest = [
            'title' => substr( wp_strip_all_tags( $content ), 0, 60 ),
            'meta' => substr( wp_strip_all_tags( $content ), 0, 150 ),
            'word_count' => $word_count,
            'recommendation' => 'Add more headings and include internal links.'
        ];
        return rest_ensure_response( [ 'success' => true, 'data' => $suggest ] );
    }

    public function rest_generate_sitemap( WP_REST_Request $req ) {
        $posts = get_posts( [ 'post_status' => 'publish', 'numberposts' => -1 ] );
        $home = home_url( '/' );
        $sitemap = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $sitemap .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        $sitemap .= "<url><loc>{$home}</loc><priority>1.0</priority></url>\n";
        foreach ( $posts as $p ) {
            $loc = get_permalink( $p );
            $dt = get_post_modified_time( 'c', true, $p );
            $sitemap .= "<url><loc>" . esc_url( $loc ) . "</loc><lastmod>" . esc_html( $dt ) . "</lastmod></url>\n";
        }
        $sitemap .= "</urlset>";
        // write to uploads
        $upload = wp_upload_dir();
        $file = trailingslashit( $upload['basedir'] ) . 'smmcare-sitemap.xml';
        file_put_contents( $file, $sitemap );
        $url = trailingslashit( $upload['baseurl'] ) . 'smmcare-sitemap.xml';
        return rest_ensure_response( [ 'success' => true, 'sitemap_url' => $url ] );
    }

    public function rest_meta_suggestions( WP_REST_Request $req ) {
        $params = $req->get_json_params();
        $title = sanitize_text_field( $params['title'] ?? '' );
        $content = sanitize_textarea_field( $params['content'] ?? '' );
        $prompt = "Suggest an SEO title (<=60 chars) and a meta description (<=160 chars) for this page content. Provide JSON object: {\"title\":\"...\",\"meta\":\"...\",\"keywords\":[...]}.\n\nContent:\n" . $content;
        if ( class_exists( 'SMMCARE_AI' ) ) {
            $resp = wp_remote_post( rest_url( 'smmcare/v1/ai/generate' ), [
                'headers' => [ 'Content-Type' => 'application/json' ],
                'body' => wp_json_encode( [ 'prompt' => $prompt, 'model' => 'gpt-3.5-turbo' ] ),
                'timeout' => 30,
            ] );
            $body = wp_remote_retrieve_body( $resp );
            $data = json_decode( $body, true );
            return rest_ensure_response( [ 'success' => true, 'ai' => $data ] );
        }
        return rest_ensure_response( [ 'success' => false, 'message' => 'AI not available' ], 501 );
    }

    public function maybe_register_sitemap_rewrite() {
        add_rewrite_rule( '^smmcare-sitemap\.xml$', 'index.php?__smmcare_sitemap=1', 'top' );
        add_rewrite_tag( '%__smmcare_sitemap%', '([01])' );
        add_action( 'template_redirect', function(){
            if ( get_query_var( '__smmcare_sitemap' ) ) {
                $upload = wp_upload_dir();
                $file = trailingslashit( $upload['basedir'] ) . 'smmcare-sitemap.xml';
                if ( file_exists( $file ) ) {
                    header( 'Content-Type: application/xml; charset=utf-8' );
                    readfile( $file );
                    exit;
                }
            }
        } );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Social_X {
    public static function routes() {
        add_action( 'rest_api_init', function(){
            register_rest_route( 'smmcare/v1', '/social/x/start', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_start'],'permission_callback'=>function(){return current_user_can('manage_options');} ]);
            register_rest_route( 'smmcare/v1', '/social/x/callback', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_callback'],'permission_callback'=>'__return_true' ]);
            register_rest_route( 'smmcare/v1', '/social/x/post', [ 'methods'=>'POST','callback'=>[__CLASS__,'rest_post'],'permission_callback'=>function(){return is_user_logged_in();} ]);
        } );
    }
    public static function rest_start( $req ) {
        $client_id = get_option( 'smmcare_x_client_id', '' );
        $redirect = rest_url( 'smmcare/v1/social/x/callback' );
        if ( empty($client_id) ) return rest_ensure_response([ 'success'=>false,'message'=>'X Client ID not set' ],400);
        $state = wp_create_nonce('smmcare_x_state');
        $url = 'https://twitter.com/i/oauth2/authorize?response_type=code&client_id=' . rawurlencode($client_id) . '&redirect_uri=' . rawurlencode($redirect) . '&scope=' . rawurlencode('tweet.read tweet.write users.read offline.access') . '&state=' . rawurlencode($state);
        return rest_ensure_response([ 'success'=>true,'url'=>$url ]);
    }
    public static function rest_callback( $req ) {
        return rest_ensure_response([ 'success'=>true,'message'=>'X callback (stub)' ] );
    }
    public static function rest_post( $req ) {
        $p = $req->get_json_params();
        $content = sanitize_textarea_field( $p['content'] ?? '' );
        if ( empty($content) ) return rest_ensure_response([ 'success'=>false,'message'=>'content required' ],400);
        $cid = SMMCARE_Multitenant::instance()->get_customer_id();
        $tokens = SMMCARE_Social_Store::instance()->get_tokens_by_customer( $cid, 'x' );
        if ( empty($tokens) ) return rest_ensure_response([ 'success'=>false,'message'=>'No X account connected' ],400);
        return rest_ensure_response([ 'success'=>true,'message'=>'posted (demo)' ]);
    }
}
SMMCARE_Social_X::routes();
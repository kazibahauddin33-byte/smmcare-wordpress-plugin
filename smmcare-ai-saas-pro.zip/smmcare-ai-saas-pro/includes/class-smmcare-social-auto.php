<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Social Auto-Posting module (patched to enforce 'posts' quota)
 */
class SMMCARE_Social_Auto {
    private static $instance = null;
    const TRANSIENT_OAUTH_PREFIX = 'smmcare_social_oauth_';

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'routes' ] );
        add_action( 'smmcare_five_min_cron', [ $this, 'cron_process_queue' ] );
    }

    public function routes() {
        register_rest_route( 'smmcare/v1', '/social/connect/(?P<provider>[a-zA-Z0-9_-]+)', [
            'methods' => 'GET',
            'callback' => [ $this, 'rest_oauth_start' ],
            'permission_callback' => function(){ return current_user_can( 'manage_options' ); }
        ] );
        register_rest_route( 'smmcare/v1', '/social/callback/(?P<provider>[a-zA-Z0-9_-]+)', [
            'methods' => 'GET',
            'callback' => [ $this, 'rest_oauth_callback' ],
            'permission_callback' => '__return_true'
        ] );
        register_rest_route( 'smmcare/v1', '/social/post', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_schedule_post' ],
            'permission_callback' => function(){ return is_user_logged_in(); }
        ] );
        register_rest_route( 'smmcare/v1', '/social/accounts', [
            'methods' => 'GET',
            'callback' => [ $this, 'rest_list_accounts' ],
            'permission_callback' => function(){ return is_user_logged_in(); }
        ] );
    }

    public function rest_schedule_post( $req ) {
        global $wpdb;
        $p = $req->get_json_params();
        $content = sanitize_textarea_field( $p['content'] ?? '' );
        $network = sanitize_text_field( $p['network'] ?? 'x' );
        $scheduled_for = sanitize_text_field( $p['scheduled_for'] ?? current_time( 'mysql' ) );
        $cid = SMMCARE_Multitenant::instance()->get_customer_id() ?: 0;
        if ( empty( $content ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'Content required' ], 400 );

        // Reserve one post quota for this scheduled post
        if ( ! SMMCARE_Quotas::check_and_consume( $cid, 'posts', 1 ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Post quota exceeded for your plan' ], 402 );
        }

        $wpdb->insert( $wpdb->prefix . 'smmcare_planner_posts', [
            'customer_id' => $cid,
            'content' => $content,
            'network' => $network,
            'scheduled_for' => date( 'Y-m-d H:i:s', strtotime( $scheduled_for ) ),
            'status' => 'scheduled',
            'created_at' => current_time( 'mysql' ),
        ], [ '%d','%s','%s','%s','%s','%s' ] );
        return rest_ensure_response( [ 'success' => true, 'post_id' => (int) $wpdb->insert_id ] );
    }

    public function cron_process_queue() {
        global $wpdb;
        $now = current_time( 'mysql' );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_planner_posts WHERE status IN ('scheduled','queued') AND scheduled_for <= %s LIMIT 20", $now ) );
        foreach ( $rows as $r ) {
            $cid = intval( $r->customer_id );
            $accounts = get_option( "smmcare_social_accounts_{$cid}", [] );
            $account = null;
            foreach ( $accounts as $a ) {
                if ( strtolower( $a['provider'] ) === strtolower( $r->network ) ) { $account = $a; break; }
            }
            if ( ! $account && ! empty( $accounts ) ) $account = $accounts[0];
            $ok = false;
            if ( $account ) {
                switch ( strtolower( $r->network ) ) {
                    case 'x':
                    case 'twitter':
                        $ok = SMMCARE_Social_X::post_from_row( $account, $r );
                        break;
                    case 'linkedin':
                        $ok = SMMCARE_Social_Linkedin::post_from_row( $account, $r );
                        break;
                    case 'facebook':
                    case 'instagram':
                        $ok = SMMCARE_Social_Facebook::post_from_row( $account, $r );
                        break;
                    case 'tiktok':
                        if ( class_exists( 'SMMCARE_Social_Tiktok' ) ) $ok = SMMCARE_Social_Tiktok::post_from_row( $account, $r );
                        else $ok = true;
                        break;
                    default:
                        $ok = true;
                        break;
                }
            }
            $wpdb->update( $wpdb->prefix . 'smmcare_planner_posts', [ 'status' => $ok ? 'posted' : 'failed' ], [ 'id' => $r->id ], [ '%s' ], [ '%d' ] );
        }
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class SMMCARE_CRM_Admin {
    public static function instance() { static $i=null; if ( $i===null ) { $i=new self(); $i->hooks(); } return $i; }
    public function hooks() { add_action( 'admin_menu', [ $this, 'add_menu' ], 60 ); add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] ); }
    public function add_menu() { add_submenu_page( 'smmcare-pro', 'Leads', 'Leads', 'manage_options', 'smmcare-crm-leads', [ $this, 'render_leads_page' ] ); }
    public function enqueue_assets( $hook ) { if ( strpos( $hook, 'smmcare-pro_page_smmcare-crm-leads' )===false ) return; wp_enqueue_style( 'smmcare-crm-css', SMMCARE_URL . 'assets/css/crm.css', [], SMMCARE_VERSION ); wp_enqueue_script( 'smmcare-crm-app', SMMCARE_URL . 'assets/js/crm-app.js', [ 'jquery' ], SMMCARE_VERSION, true ); wp_localize_script( 'smmcare-crm-app', 'smmcareCRM', [ 'rest_root'=>esc_url_raw( rest_url( 'smmcare/v1' ) ), 'nonce'=>wp_create_nonce( 'wp_rest' ) ] ); }
    public function render_leads_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        ?>
        <div class="wrap smmcare-crm-wrap">
          <h1>SMMCARE CRM — Leads</h1>
          <div class="smmcare-crm-tools">
            <div class="left">
              <input id="smmcare-crm-search" placeholder="Search leads..." />
              <select id="smmcare-crm-status-filter"><option value="">All statuses</option><option value="new">New</option><option value="contacted">Contacted</option></select>
              <button id="smmcare-crm-search-btn" class="button">Search</button>
            </div>
            <div class="right">
              <button id="smmcare-open-bulk-sms" class="button smmcare-open-bulk-sms">Bulk SMS</button>
            </div>
          </div>
          <div id="smmcare-crm-list"></div>
          <div id="smmcare-crm-pagination"></div>
          <div id="smmcare-crm-modal" style="display:none"></div>
        </div>
        <?php
    }
}
SMMCARE_CRM_Admin::instance();
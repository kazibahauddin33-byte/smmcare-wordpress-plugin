<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_2FA {
    public static function init() { add_action( 'rest_api_init', [ __CLASS__, 'routes' ] ); }
    public static function routes() {
        register_rest_route( 'smmcare/v1', '/2fa/request', [ 'methods'=>'POST','callback'=>[__CLASS__,'rest_request'],'permission_callback'=>'__return_true' ] );
        register_rest_route( 'smmcare/v1', '/2fa/verify', [ 'methods'=>'POST','callback'=>[__CLASS__,'rest_verify'],'permission_callback'=>'__return_true' ] );
    }
    public static function rest_request( WP_REST_Request $req ) {
        $params = $req->get_json_params();
        $user = wp_get_current_user();
        if ( ! $user || ! $user->ID ) return rest_ensure_response([ 'success'=>false,'message'=>'Login required' ],401);
        $method = sanitize_text_field( $params['method'] ?? 'email' );
        $code = rand(100000,999999);
        set_transient( 'smmcare_2fa_' . $user->ID, $code, 10*MINUTE_IN_SECONDS );
        $sent = false;
        if ( $method === 'sms' ) {
            $phone = sanitize_text_field( $params['phone'] ?? get_user_meta( $user->ID, 'phone', true ) );
            if ( $phone ) {
                $body = "Your verification code: {$code}";
                $tw = SMMCARE_Settings::instance()->get_twilio_credentials();
                if ( ! empty($tw['sid']) ) {
                    $url = "https://api.twilio.com/2010-04-01/Accounts/" . rawurlencode( $tw['sid'] ) . "/Messages.json";
                    $args = [ 'headers'=>[ 'Authorization'=>'Basic '.base64_encode($tw['sid'].':'.$tw['token']) ], 'body'=>[ 'From'=>$tw['from'], 'To'=>$phone, 'Body'=>$body ], 'timeout'=>20 ];
                    $resp = wp_remote_post( $url, $args );
                    if ( ! is_wp_error($resp) && wp_remote_retrieve_response_code($resp) < 300 ) $sent = true;
                }
            }
        } else {
            $email = $user->user_email;
            if ( $email ) {
                $subject = 'Your SMMCARE verification code';
                $body_html = "<p>Your verification code: <strong>{$code}</strong></p>";
                SMMCARE_Email::instance()->send_email( $email, $subject, $body_html, SMMCARE_Multitenant::instance()->get_customer_id() );
                $sent = true;
            }
        }
        if ( $sent ) return rest_ensure_response( [ 'success'=>true ] );
        return rest_ensure_response( [ 'success'=>false,'message'=>'Send failed' ],500 );
    }
    public static function rest_verify( WP_REST_Request $req ) {
        $params = $req->get_json_params();
        $user = wp_get_current_user();
        if ( ! $user || ! $user->ID ) return rest_ensure_response([ 'success'=>false,'message'=>'Login required' ],401);
        $code = sanitize_text_field( $params['code'] ?? '' );
        $stored = get_transient( 'smmcare_2fa_' . $user->ID );
        if ( $stored && (string)$stored === (string)$code ) {
            delete_transient( 'smmcare_2fa_' . $user->ID );
            $token = sanitize_text_field( $params['token'] ?? '' );
            if ( $token ) SMMCARE_Auth::mark_session_verified( $user->ID, $token );
            if ( isset( $params['enable'] ) && $params['enable'] ) update_user_meta( $user->ID, 'smmcare_2fa_enabled', 1 );
            return rest_ensure_response( [ 'success' => true ] );
        }
        return rest_ensure_response( [ 'success'=>false, 'message'=>'Invalid code' ],400 );
    }
}
SMMCARE_2FA::init();
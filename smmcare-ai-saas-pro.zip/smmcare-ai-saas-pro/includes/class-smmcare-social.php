<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Social API integrations (stubs for Facebook, Instagram, LinkedIn, X)
 * - stores connected accounts (user meta or options)
 * - provides endpoint to post content (posting requires proper access tokens)
 */
class SMMCARE_Social {
    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
    }

    public static function register_routes() {
        register_rest_route( 'smmcare/v1', '/social/post', [
            'methods' => 'POST',
            'callback' => [ __CLASS__, 'post_to_social' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/social/accounts', [
            'methods' => 'GET',
            'callback' => [ __CLASS__, 'list_accounts' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }

    public static function list_accounts( WP_REST_Request $request ) {
        $user = get_current_user_id();
        $accounts = get_user_meta( $user, 'smmcare_social_accounts', true );
        if ( ! is_array( $accounts ) ) $accounts = [];
        return rest_ensure_response( [ 'success' => true, 'data' => $accounts ] );
    }

    public static function post_to_social( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $network = sanitize_text_field( $params['network'] ?? '' );
        $content = sanitize_textarea_field( $params['content'] ?? '' );
        $attachments = $params['attachments'] ?? [];

        if ( empty( $network ) || empty( $content ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Network and content required' ], 400 );
        }

        // This is a placeholder. Each network requires its own SDK / OAuth flow.
        // We will return a mock response so UI can show "queued".
        // In production you'd call Facebook/IG/LinkedIn/X APIs with stored tokens.

        // save into planner_posts as a queued post (re-use planner table)
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_planner_posts';
        $user = get_current_user_id();
        $wpdb->insert( $table, [
            'customer_id' => $user,
            'content' => $content,
            'network' => $network,
            'scheduled_for' => current_time( 'mysql' ),
            'status' => 'queued',
            'created_at' => current_time( 'mysql' ),
        ], [ '%d','%s','%s','%s','%s','%s' ] );

        delete_transient( 'smmcare_metrics_user_' . $user );

        return rest_ensure_response( [ 'success' => true, 'message' => 'Queued for posting', 'post_id' => (int) $wpdb->insert_id ] );
    }
}

SMMCARE_Social::init();
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE Diagnostics - admin-only helper
 *
 * Usage:
 *  - Place this file at: wp-content/plugins/smmcare-ai-saas-pro/includes/class-smmcare-diagnostics.php
 *  - Ensure it's loaded by the plugin (add to $includes or require_once it).
 *  - Visit: /wp-admin/?smmcare_diag=1 while logged-in as an admin.
 *
 * This prints:
 *  - plugin active check
 *  - presence of key classes (SMMCARE_Metrics, SMMCARE_Pages, etc)
 *  - registered REST routes filtered for the smmcare namespace
 *  - contents of option 'smmcare_pages'
 *  - checks whether those pages exist in wp_posts
 *  - last 100 lines of wp-content/debug.log (if present)
 */
class SMMCARE_Diagnostics {
    public static function init() {
        add_action( 'admin_init', [ __CLASS__, 'maybe_run' ] );
    }

    public static function maybe_run() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( ! isset( $_GET['smmcare_diag'] ) || $_GET['smmcare_diag'] != '1' ) return;

        header( 'Content-Type: text/plain; charset=utf-8' );
        echo "=== SMMCARE Diagnostics ===\n\n";

        // Plugin active?
        if ( ! function_exists( 'get_plugins' ) ) require_once ABSPATH . 'wp-admin/includes/plugin.php';
        $plugin_file = 'smmcare-ai-saas-pro/smmcare-ai-saas-pro.php';
        $is_active = is_plugin_active( $plugin_file );
        echo "Plugin active ({$plugin_file}): " . ( $is_active ? 'YES' : 'NO' ) . "\n\n";

        // Classes we expect
        $classes = [
            'SMMCARE_Metrics',
            'SMMCARE_Pages',
            'SMMCARE_Frontend',
            'SMMCARE_Admin',
            'SMMCARE_Plans',
            'SMMCARE_Quotas',
        ];
        echo "Class existence:\n";
        foreach ( $classes as $c ) {
            echo " - {$c}: " . ( class_exists( $c ) ? 'loaded' : 'MISSING' ) . "\n";
        }
        echo "\n";

        // Registered REST routes for smmcare namespace
        echo "REST routes (filtered by namespace 'smmcare'):\n";
        if ( function_exists( 'rest_get_server' ) ) {
            $routes = rest_get_server()->get_routes();
            $found = [];
            foreach ( $routes as $route => $handlers ) {
                if ( strpos( $route, '/smmcare/' ) !== false || strpos( $route, '/smmcare/v1' ) !== false || strpos( $route, 'smmcare/v1' ) !== false ) {
                    $found[] = $route;
                }
            }
            if ( empty( $found ) ) {
                echo " - none found for 'smmcare' namespace (0 routes)\n";
            } else {
                foreach ( $found as $r ) echo " - {$r}\n";
            }
        } else {
            echo " - rest_get_server not available (WP < 4.7?)\n";
        }
        echo "\n";

        // Check smmcare_pages option
        global $wpdb;
        $opt = get_option( 'smmcare_pages', null );
        echo "Option 'smmcare_pages':\n";
        if ( $opt === null ) {
            echo " - option not found (null)\n";
        } elseif ( empty( $opt ) ) {
            echo " - option exists but empty (empty array or string)\n";
            var_export( $opt );
            echo "\n";
        } else {
            var_export( $opt );
            echo "\n\n";
            if ( is_array( $opt ) ) {
                foreach ( $opt as $key => $id ) {
                    $id = intval( $id );
                    $post = $id ? get_post( $id ) : null;
                    echo " - key={$key}, id={$id}, post_exists=" . ( $post ? 'YES' : 'NO' );
                    if ( $post ) echo ", post_status={$post->post_status}, post_title=" . $post->post_title;
                    echo "\n";
                }
            }
        }
        echo "\n";

        // Show rewrite rules presence of smmcare_page rewrites (approx)
        echo "Rewrite rules check (do we have smmcare-page rewrites?):\n";
        $rules = get_option( 'rewrite_rules' );
        $found_rules = [];
        if ( is_array( $rules ) ) {
            foreach ( $rules as $pattern => $dest ) {
                if ( strpos( $pattern, 'smmcare' ) !== false || strpos( $dest, 'smmcare' ) !== false ) {
                    $found_rules[ $pattern ] = $dest;
                }
            }
        }
        if ( empty( $found_rules ) ) {
            echo " - no smmcare rewrite rules discovered (you may need to flush permalinks)\n";
        } else {
            foreach ( $found_rules as $p => $d ) echo " - {$p} => {$d}\n";
        }
        echo "\n";

        // Show last 100 lines from wp-content/debug.log if exists
        $debug = WP_CONTENT_DIR . '/debug.log';
        echo "Last lines from wp-content/debug.log (if available):\n";
        if ( file_exists( $debug ) ) {
            $lines = @file( $debug, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
            if ( $lines === false ) {
                echo " - cannot read debug.log\n";
            } else {
                $show = array_slice( $lines, -100 );
                foreach ( $show as $ln ) echo $ln . "\n";
            }
        } else {
            echo " - debug.log not found at {$debug}\n";
        }
        echo "\n";

        // Quick server environment info
        echo "Environment:\n";
        echo " - PHP SAPI: " . php_sapi_name() . "\n";
        echo " - PHP version: " . phpversion() . "\n";
        echo " - WP version: " . get_bloginfo( 'version' ) . "\n";
        echo "\n";

        echo "=== End diagnostics ===\n";

        // Stop processing to avoid interfering with normal admin page
        exit;
    }
}

SMMCARE_Diagnostics::init();
<?php
// Patch: server-side enforcement to never return raw secret values.
// Replace existing rest_get_settings() with this implementation.
public function rest_get_settings( $request ) {
    $s = $this->get_all();
    // Instead of returning any secrets (even masked), return boolean flags and non-sensitive values only.
    $out = [
        'stripe_configured' => ! empty( $s['stripe_secret'] ?? '' ),
        'stripe_webhook_configured' => ! empty( $s['stripe_webhook_secret'] ?? '' ),
        'openai_configured' => ! empty( $s['openai_key'] ?? '' ),
        'twilio_configured' => ! empty( $s['twilio_sid'] ?? '' ) && ! empty( $s['twilio_token'] ?? '' ),
        'twilio_from' => $s['twilio_from'] ?? '',
        'stripe_price_starter' => $s['stripe_price_starter'] ?? '',
        'stripe_price_pro' => $s['stripe_price_pro'] ?? '',
        'stripe_price_enterprise' => $s['stripe_price_enterprise'] ?? '',
        'smtp_configured' => ! empty( $s['smtp_host'] ?? '' ) && ! empty( $s['smtp_user'] ?? '' ),
        'smtp_from' => $s['smtp_from'] ?? get_option( 'admin_email' ),
        // social apps presence flags
        'x_app_configured' => ! empty( $s['x_client_id'] ?? '' ) && ! empty( $s['x_client_secret'] ?? '' ),
        'linkedin_app_configured' => ! empty( $s['li_client_id'] ?? '' ) && ! empty( $s['li_client_secret'] ?? '' ),
        'facebook_app_configured' => ! empty( $s['fb_app_id'] ?? '' ) && ! empty( $s['fb_app_secret'] ?? '' ),
        'gcal_app_configured' => ! empty( $s['gcal_client_id'] ?? '' ) && ! empty( $s['gcal_client_secret'] ?? '' ),
        'tiktok_app_configured' => ! empty( $s['tiktok_client_id'] ?? '' ) && ! empty( $s['tiktok_client_secret'] ?? '' ),
    ];
    return rest_ensure_response( [ 'success' => true, 'data' => $out ] );
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Auth {
    public static function init() {
        add_action( 'wp_login', [ __CLASS__, 'handle_post_login' ], 10, 2 );
        add_action( 'init', [ __CLASS__, 'enforce_2fa_on_request' ] );
        add_action( 'init', [ __CLASS__, 'maybe_register_verify_route' ] );
    }

    public static function handle_post_login( $user_login, $user ) {
        if ( ! $user || ! $user->ID ) return;
        $enabled = get_user_meta( $user->ID, 'smmcare_2fa_enabled', true );
        if ( $enabled ) {
            $token = function_exists('wp_get_session_token') ? wp_get_session_token() : ( $_COOKIE['smmcare_session_token'] ?? '' );
            if ( empty( $token ) ) { $token = wp_generate_password(24,false,false); setcookie('smmcare_session_token',$token,0,COOKIEPATH,COOKIE_DOMAIN,is_ssl(),true); }
            set_transient( 'smmcare_2fa_pending_' . $user->ID . '_' . $token, [ 'issued'=>time() ], 10*MINUTE_IN_SECONDS );
            $verify_url = add_query_arg( [ 'uid' => $user->ID, 'token' => $token ], home_url( '/smmcare-2fa-verify' ) );
            wp_safe_redirect( $verify_url );
            exit;
        }
    }

    public static function is_session_pending( $user_id = 0 ) {
        if ( ! $user_id ) $user_id = get_current_user_id();
        if ( ! $user_id ) return false;
        $token = function_exists('wp_get_session_token') ? wp_get_session_token() : ( $_COOKIE['smmcare_session_token'] ?? '' );
        if ( ! $token ) return false;
        $key = 'smmcare_2fa_pending_' . $user_id . '_' . $token;
        return (bool) get_transient( $key );
    }

    public static function enforce_2fa_on_request() {
        if ( ! is_user_logged_in() ) return;
        $smmcare_page = get_query_var( 'smmcare_page', '' );
        if ( $smmcare_page === '2fa-verify' ) return;
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            $route = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
            if ( strpos( $route, '/smmcare/v1/2fa' ) !== false ) return;
        }
        if ( self::is_session_pending( get_current_user_id() ) ) {
            $token = function_exists('wp_get_session_token') ? wp_get_session_token() : ( $_COOKIE['smmcare_session_token'] ?? '' );
            $verify_url = add_query_arg( [ 'uid' => get_current_user_id(), 'token' => $token ], home_url( '/smmcare-2fa-verify' ) );
            wp_safe_redirect( $verify_url );
            exit;
        }
    }

    public static function mark_session_verified( $user_id, $token ) {
        if ( empty( $user_id ) || empty( $token ) ) return;
        delete_transient( 'smmcare_2fa_pending_' . $user_id . '_' . $token );
        set_transient( 'smmcare_2fa_verified_' . $user_id . '_' . $token, 1, HOUR_IN_SECONDS );
    }

    public static function maybe_register_verify_route() {
        add_rewrite_rule( '^smmcare-2fa-verify/?$', 'index.php?smmcare_page=2fa-verify', 'top' );
    }
}
SMMCARE_Auth::init();
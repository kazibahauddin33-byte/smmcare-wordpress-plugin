<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* core includes - single authoritative definitions, loaded in order */
$inc = dirname( __FILE__ );

require_once $inc . '/class-smmcare-multitenant.php';
require_once $inc . '/class-smmcare-settings.php';
require_once $inc . '/class-smmcare-email.php';
require_once $inc . '/class-smmcare-quotas.php';
require_once $inc . '/class-smmcare-auth.php';
require_once $inc . '/class-smmcare-2fa.php';
require_once $inc . '/class-smmcare-customer.php';
require_once $inc . '/class-smmcare-admin.php';
require_once $inc . '/class-smmcare-crm.php';
require_once $inc . '/class-smmcare-tickets.php';
require_once $inc . '/class-smmcare-subscriptions.php';
require_once $inc . '/class-smmcare-payments-stripe.php';
require_once $inc . '/class-smmcare-social-store.php';
require_once $inc . '/class-smmcare-social-x.php';
require_once $inc . '/class-smmcare-social-linkedin.php';
require_once $inc . '/class-smmcare-social-facebook.php';
require_once $inc . '/class-smmcare-social-tiktok.php';
require_once $inc . '/class-smmcare-gcal.php';
require_once $inc . '/class-smmcare-sms-campaigns.php';
require_once $inc . '/class-smmcare-reputation.php';
require_once $inc . '/class-smmcare-ai.php';
require_once $inc . '/class-smmcare-plans.php';
require_once $inc . '/class-smmcare-frontend.php';
require_once $inc . '/class-smmcare-customer-ui.php';

/* Instantiate common singletons */
SMMCARE_Multitenant::instance();
SMMCARE_Settings::instance();
SMMCARE_Email::instance();
SMMCARE_Quotas::init();
SMMCARE_Auth::init();
SMMCARE_2FA::init();
SMMCARE_Customer::instance();
SMMCARE_Admin::instance();
SMMCARE_CRM::instance();
SMMCARE_Tickets::instance();
SMMCARE_Subscriptions::instance();
SMMCARE_Payments_Stripe::init();
SMMCARE_Social_Store::instance();
SMMCARE_Social_X::routes();
SMMCARE_Social_Linkedin::routes();
SMMCARE_Social_Facebook::routes();
SMMCARE_Social_Tiktok::routes();
SMMCARE_GCal::init();
SMMCARE_SMS_Campaigns::init();
SMMCARE_Reputation::init();
SMMCARE_AI::instance();
SMMCARE_Plans::instance();
SMMCARE_Frontend::init();
SMMCARE_Customer_UI::init();
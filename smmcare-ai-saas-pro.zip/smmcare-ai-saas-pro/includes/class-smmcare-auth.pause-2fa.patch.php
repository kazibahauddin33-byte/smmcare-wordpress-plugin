<?php
// Improved 2FA flow: "pause" authentication instead of logging the user out.
// Mechanism:
// 1) After password login, if user has 2FA enabled, create a pending transient keyed by session token.
// 2) Keep user logged in but mark the current session as "pending-2fa" (store in WP session tokens or transient).
// 3) Add a runtime check (init) that redirects user to /smmcare-2fa-verify if session is pending and the current route is not verification.
// 4) On successful verify, clear the pending flag for this session and allow full access.

class SMMCARE_Auth {
    public static function init() {
        add_action( 'wp_login', [ __CLASS__, 'handle_post_login' ], 10, 2 );
        add_action( 'init', [ __CLASS__, 'enforce_2fa_on_request' ] );
        add_action( 'init', [ __CLASS__, 'maybe_register_verify_route' ] );
    }

    public static function handle_post_login( $user_login, $user ) {
        if ( ! $user || ! $user->ID ) return;
        $enabled = get_user_meta( $user->ID, 'smmcare_2fa_enabled', true );
        if ( $enabled ) {
            // Build a session token id (WordPress session manager)
            if ( function_exists( 'wp_get_session_token' ) ) {
                $token = wp_get_session_token();
            } else {
                // fallback to a cookie-based token
                $token = md5( wp_generate_password(12, false) . $user->ID );
                setcookie( 'smmcare_session_token', $token, 0, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
            }
            // store small transient marking pending status
            $key = 'smmcare_2fa_pending_' . $user->ID . '_' . $token;
            set_transient( $key, [ 'issued' => time() ], 10 * MINUTE_IN_SECONDS );

            // store a redirect so when verification finishes we can send them back
            // use wp_safe_redirect to verification page
            $verify_url = add_query_arg( [ 'uid' => $user->ID, 'token' => $token ], home_url( '/smmcare-2fa-verify' ) );
            wp_safe_redirect( $verify_url );
            exit;
        }
    }

    public static function is_session_pending( $user_id = 0 ) {
        if ( ! $user_id ) $user_id = get_current_user_id();
        if ( ! $user_id ) return false;
        $token = function_exists( 'wp_get_session_token' ) ? wp_get_session_token() : ( $_COOKIE['smmcare_session_token'] ?? '' );
        if ( ! $token ) return false;
        $key = 'smmcare_2fa_pending_' . $user_id . '_' . $token;
        return (bool) get_transient( $key );
    }

    public static function enforce_2fa_on_request() {
        // Only run for logged-in users
        if ( ! is_user_logged_in() ) return;
        $user_id = get_current_user_id();
        // allow access to verification page and REST endpoints used for verification
        $smmcare_page = get_query_var( 'smmcare_page', '' );
        if ( $smmcare_page === '2fa-verify' ) return;
        // For ajax/rest verification endpoints, allow them to run
        if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
            $route = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '';
            if ( strpos( $route, '/smmcare/v1/2fa' ) !== false ) return;
        }
        if ( self::is_session_pending( $user_id ) ) {
            // redirect to verification page if not already there
            $token = function_exists( 'wp_get_session_token' ) ? wp_get_session_token() : ( $_COOKIE['smmcare_session_token'] ?? '' );
            $verify_url = add_query_arg( [ 'uid' => $user_id, 'token' => $token ], home_url( '/smmcare-2fa-verify' ) );
            wp_safe_redirect( $verify_url );
            exit;
        }
    }

    public static function mark_session_verified( $user_id, $token ) {
        // delete pending transient to mark verified
        delete_transient( 'smmcare_2fa_pending_' . $user_id . '_' . $token );
        // Optionally set a verified transient for this session for a limited time
        set_transient( 'smmcare_2fa_verified_' . $user_id . '_' . $token, 1, 60 * 60 );
    }

    public static function maybe_register_verify_route() {
        add_rewrite_rule( '^smmcare-2fa-verify/?$', 'index.php?smmcare_page=2fa-verify', 'top' );
    }
}
SMMCARE_Auth::init();
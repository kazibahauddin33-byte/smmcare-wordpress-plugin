<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class SMMCARE_Social_Facebook {
    public static function routes() {
        add_action( 'rest_api_init', function(){
            register_rest_route( 'smmcare/v1', '/social/facebook/start', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_start'],'permission_callback'=>function(){return current_user_can('manage_options');} ]);
            register_rest_route( 'smmcare/v1', '/social/facebook/callback', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_callback'],'permission_callback'=>'__return_true' ]);
            register_rest_route( 'smmcare/v1', '/social/facebook/post', [ 'methods'=>'POST','callback'=>[__CLASS__,'rest_post'],'permission_callback'=>function(){return is_user_logged_in();} ]);
        } );
    }
    public static function rest_start() { $app_id = get_option('smmcare_fb_app_id',''); $redirect = rest_url('smmcare/v1/social/facebook/callback'); $url = 'https://www.facebook.com/v17.0/dialog/oauth?client_id=' . rawurlencode($app_id) . '&redirect_uri=' . rawurlencode($redirect) . '&scope=' . rawurlencode('pages_manage_posts,pages_read_engagement'); return rest_ensure_response([ 'success'=>true,'url'=>$url ]); }
    public static function rest_callback( $req ) { return rest_ensure_response([ 'success'=>true,'message'=>'Facebook callback (stub)' ] ); }
    public static function rest_post( $req ) { return rest_ensure_response([ 'success'=>true,'message'=>'facebook post (demo)' ]); }
}
SMMCARE_Social_Facebook::routes();
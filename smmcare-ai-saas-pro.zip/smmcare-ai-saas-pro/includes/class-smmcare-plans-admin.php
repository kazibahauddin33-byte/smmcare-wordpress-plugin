<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Plans_Admin {
    public static function init() { add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_assets' ] ); add_action( 'admin_footer', [ __CLASS__, 'render_plans_modal' ] ); }
    public static function enqueue_assets( $hook ) { if ( strpos( $hook, 'smmcare-pro_page_smmcare-settings' ) === false ) return; wp_enqueue_script( 'smmcare-plans-admin', SMMCARE_URL . 'assets/js/plans-admin.js', [ 'jquery' ], SMMCARE_VERSION, true ); wp_enqueue_style( 'smmcare-plans-css', SMMCARE_URL . 'assets/css/plans.css', [], SMMCARE_VERSION ); }
    public static function render_plans_modal() { if ( ! current_user_can( 'manage_options' ) ) return; ?>
      <div id="smmcare-plans-modal" style="display:none;">
        <div class="smmcare-plans-wrapper card" style="position:fixed;right:20px;bottom:20px;z-index:100000;">
          <h3>Plans Mapping</h3>
          <table class="form-table">
            <tr><th>Starter Stripe Price ID</th><td><input id="smmcare_price_starter" style="width:60%"/></td></tr>
            <tr><th>Pro Stripe Price ID</th><td><input id="smmcare_price_pro" style="width:60%"/></td></tr>
            <tr><th>Enterprise Stripe Price ID</th><td><input id="smmcare_price_enterprise" style="width:60%"/></td></tr>
          </table>
          <p><button id="smmcare_price_save" class="button button-primary">Save</button> <button id="smmcare_price_close" class="button">Close</button></p>
        </div>
      </div>
      <script>jQuery(function($){ $('#smmcare_price_save').on('click',function(){ var payload={ stripe_price_starter:$('#smmcare_price_starter').val(), stripe_price_pro:$('#smmcare_price_pro').val(), stripe_price_enterprise:$('#smmcare_price_enterprise').val() }; fetch('/wp-json/smmcare/v1/settings',{ method:'POST', credentials:'same-origin', headers:{ 'Content-Type':'application/json','X-WP-Nonce': window.smmcareSettings ? window.smmcareSettings.nonce : '' }, body: JSON.stringify(payload) }).then(r=>r.json()).then(d=>{ if ( d && d.success ) alert('Saved'); else alert('Save failed'); }); }); $('#smmcare_price_close').on('click',function(){ $('#smmcare-plans-modal').hide(); }); });</script>
    <?php }
}
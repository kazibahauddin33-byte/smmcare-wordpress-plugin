<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Multitenant {
    private static $instance = null;
    private $customer_id = 0;
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            add_action( 'init', [ self::$instance, 'resolve_context' ] );
        }
        return self::$instance;
    }
    public function resolve_context() {
        if ( isset( $_COOKIE['smmcare_impersonate'] ) ) {
            $key = sanitize_text_field( $_COOKIE['smmcare_impersonate'] );
            $user_id = get_transient( 'smmcare_impersonate_' . $key );
            if ( $user_id ) {
                global $wpdb;
                $cid = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}smmcare_customers WHERE user_id = %d LIMIT 1", intval( $user_id ) ) );
                $this->customer_id = $cid ? intval( $cid ) : 0;
                return;
            }
        }
        if ( is_user_logged_in() ) {
            $user_id = get_current_user_id();
            global $wpdb;
            $cid = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}smmcare_customers WHERE user_id = %d LIMIT 1", intval( $user_id ) ) );
            $this->customer_id = $cid ? intval( $cid ) : 0;
            return;
        }
        $this->customer_id = 0;
    }
    public function get_customer_id() { return $this->customer_id; }
}
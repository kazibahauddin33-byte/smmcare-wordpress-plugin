<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Customer_Branding {
    const META_KEY = 'smmcare_customer_branding';
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
        add_shortcode( 'smmcare_branding_form', array( __CLASS__, 'shortcode_form' ) );
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_front_assets' ), 25 );
        add_action( 'wp_head', array( __CLASS__, 'output_user_branding' ), 5 );
        add_action( 'wp_footer', array( __CLASS__, 'output_branding_modal' ), 20 );
    }
    public static function register_routes() {
        register_rest_route( 'smmcare/v1', '/customer/branding', array(
            array(
                'methods' => 'GET',
                'callback' => array( __CLASS__, 'rest_get_branding' ),
                'permission_callback' => function() { return is_user_logged_in(); },
            ),
            array(
                'methods' => 'POST',
                'callback' => array( __CLASS__, 'rest_save_branding' ),
                'permission_callback' => function() { return is_user_logged_in(); },
                'args' => array(
                    'logo' => array( 'required' => false, 'type' => 'string' ),
                    'accent_color' => array( 'required' => false, 'type' => 'string' ),
                    'theme_mode' => array( 'required' => false, 'type' => 'string' ),
                    'footer_text' => array( 'required' => false, 'type' => 'string' ),
                )
            )
        ) );
    }
    public static function rest_get_branding( WP_REST_Request $request ) {
        $user_id = get_current_user_id();
        $data = get_user_meta( $user_id, self::META_KEY, true );
        if ( ! is_array( $data ) ) $data = array();
        return rest_ensure_response( array( 'success' => true, 'data' => $data ) );
    }
    public static function rest_save_branding( WP_REST_Request $request ) {
        $user_id = get_current_user_id();
        $params = $request->get_json_params();
        if ( ! is_array( $params ) ) $params = array();
        $allowed = array( 'logo' => '', 'accent_color' => '', 'theme_mode' => '', 'footer_text' => '', );
        $save = array();
        foreach ( $allowed as $k => $v ) {
            if ( isset( $params[ $k ] ) ) {
                $val = $params[ $k ];
                if ( $k === 'accent_color' ) {
                    $val = sanitize_text_field( $val );
                    if ( ! preg_match( '/^#[0-9a-fA-F]{6}$/', $val ) ) $val = '';
                } elseif ( $k === 'logo' ) {
                    $val = esc_url_raw( $val );
                } else {
                    $val = sanitize_text_field( $val );
                }
                $save[ $k ] = $val;
            }
        }
        update_user_meta( $user_id, self::META_KEY, $save );
        // invalidate metrics
        delete_transient( 'smmcare_metrics_user_' . $user_id );
        return rest_ensure_response( array( 'success' => true, 'data' => $save ) );
    }
    public static function shortcode_form( $atts ) {
        if ( ! is_user_logged_in() ) return '<p>Please sign in to customize your branding.</p>';
        $user_id = get_current_user_id();
        $data = get_user_meta( $user_id, self::META_KEY, true );
        $logo = esc_url( $data['logo'] ?? '' );
        $accent = esc_attr( $data['accent_color'] ?? '#6b5cff' );
        $theme = esc_attr( $data['theme_mode'] ?? 'dark' );
        $footer = esc_attr( $data['footer_text'] ?? get_option( 'smmcare_footer_text', '© SMMCARE LLC' ) );
        wp_enqueue_media();
        wp_enqueue_script( 'smmcare-branding-js', SMMCARE_URL . 'assets/js/branding-admin.js', array( 'jquery' ), SMMCARE_VERSION, true );
        wp_enqueue_style( 'smmcare-branding-css', SMMCARE_URL . 'assets/css/branding.css', array(), SMMCARE_VERSION );
        wp_localize_script( 'smmcare-branding-js', 'smmcareBranding', array(
            'rest' => esc_url_raw( rest_url( 'smmcare/v1/customer/branding' ) ),
            'nonce' => wp_create_nonce( 'wp_rest' ),
            'defaults' => array( 'logo' => $logo, 'accent_color' => $accent, 'theme_mode' => $theme, 'footer_text' => $footer ),
        ) );
        ob_start();
        ?>
        <div class="smmcare-branding-widget">
          <h3>Customize your dashboard</h3>
          <div class="row">
            <label>Logo</label>
            <div class="control">
              <img class="branding-preview" src="<?php echo esc_attr( $logo ); ?>" alt="" onerror="this.style.display='none'"/>
              <input type="hidden" id="smmcare_branding_logo" value="<?php echo esc_attr( $logo ); ?>" />
              <button class="button" id="smmcare_upload_branding_logo">Upload / Choose</button>
              <button class="button" id="smmcare_remove_branding_logo">Remove</button>
            </div>
          </div>
          <div class="row">
            <label>Accent color</label>
            <div class="control">
              <input type="color" id="smmcare_branding_accent" value="<?php echo esc_attr( $accent ); ?>" />
              <span class="muted">Pick an accent color (hex)</span>
            </div>
          </div>
          <div class="row">
            <label>Theme</label>
            <div class="control">
              <select id="smmcare_branding_theme">
                <option value="dark" <?php selected( $theme, 'dark' ); ?>>Dark</option>
                <option value="light" <?php selected( $theme, 'light' ); ?>>Light</option>
              </select>
            </div>
          </div>
          <div class="row">
            <label>Footer text</label>
            <div class="control">
              <input type="text" id="smmcare_branding_footer" value="<?php echo $footer; ?>" />
            </div>
          </div>
          <div class="row actions">
            <button id="smmcare_save_branding" class="button button-primary">Save Branding</button>
            <span id="smmcare_branding_status" style="margin-left:12px"></span>
          </div>
        </div>
        <?php
        return ob_get_clean();
    }
    public static function enqueue_front_assets() {
        if ( ! is_user_logged_in() ) return;
        wp_register_style( 'smmcare-customer-branding-front', SMMCARE_URL . 'assets/css/branding.css', array(), SMMCARE_VERSION );
        wp_enqueue_style( 'smmcare-customer-branding-front' );
    }
    public static function output_user_branding() {
        if ( ! is_user_logged_in() ) return;
        $user_id = get_current_user_id();
        $data = get_user_meta( $user_id, self::META_KEY, true );
        if ( ! is_array( $data ) ) $data = array();
        $accent = isset( $data['accent_color'] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $data['accent_color'] ) ? $data['accent_color'] : '#6b5cff';
        $theme = isset( $data['theme_mode'] ) ? $data['theme_mode'] : 'dark';
        $logo = isset( $data['logo'] ) ? esc_url( $data['logo'] ) : '';
        $footer = isset( $data['footer_text'] ) ? wp_kses_post( $data['footer_text'] ) : '';
        echo "<style id='smmcare-user-branding' type='text/css'>\n";
        echo ":root { --smmcare-accent: {$accent}; }\n";
        if ( $theme === 'light' ) {
            echo "body { background: #f7fafc !important; color: #0b2540 !important; }\n";
            echo ".smmcare-app, .smmcare-dashboard-main, .card { background: #fff !important; color: #0b2540 !important; }\n";
        }
        echo "</style>\n";
        if ( $logo || $footer ) {
            $logo_js = $logo ? json_encode( $logo ) : 'null';
            $footer_js = $footer ? json_encode( $footer ) : 'null';
            echo "<script id='smmcare-user-branding-js'>\n";
            echo "(function(){document.addEventListener('DOMContentLoaded',function(){try{var l={$logo_js}; if(l){ var sel = ['.smmcare-dashboard-sidebar .brand img', '.smmcare-sidebar .brand img', '.smmcare-app .brand img', '.smmcare-sidebar .brand img']; sel.forEach(function(s){var img=document.querySelector(s); if(img){ img.src = l; img.style.display='block'; }} );} var f={$footer_js}; if(f){ var foot = document.querySelector('.smmcare-dashboard-footer, .smmcare-footer, footer'); if(foot){ foot.textContent = f; } } }catch(e){console && console.warn && console.warn('SMMCARE branding apply error',e);} });})();\n";
            echo "</script>\n";
        }
    }
    public static function output_branding_modal() {
        if ( ! is_user_logged_in() ) return;
        $should_show = false;
        if ( is_singular( 'page' ) ) {
            global $post;
            if ( $post && get_post_meta( $post->ID, '_smmcare_template', true ) ) {
                $should_show = true;
            }
        }
        if ( ! $should_show ) {
            $path = trim( parse_url( home_url( add_query_arg( [] ) ), PHP_URL_PATH ), '/' );
            $slugs = array( 'dashboard', 'ai-tools', 'social-planner', 'planner', 'crm', 'reviews', 'campaigns', 'customer-login', 'customer-signup', 'billing' );
            foreach ( $slugs as $s ) {
                if ( strpos( $_SERVER['REQUEST_URI'], '/' . $s ) !== false ) {
                    $should_show = true;
                    break;
                }
            }
        }
        if ( ! $should_show ) return;
        wp_enqueue_script( 'smmcare-branding-js' );
        wp_enqueue_style( 'smmcare-branding-css' );
        ?>
        <button id="smmcare-branding-fab" title="Customize dashboard" aria-label="Customize" style="position:fixed;right:20px;bottom:20px;z-index:99999;border-radius:50%;height:54px;width:54px;background:var(--smmcare-accent);border:none;color:#fff;font-size:22px;box-shadow:0 8px 20px rgba(11,33,58,.35)">⚙️</button>

        <div id="smmcare-branding-modal" style="display:none;position:fixed;right:24px;bottom:86px;z-index:100000;max-width:720px;width:92%;box-shadow:0 18px 60px rgba(2,6,23,.6);">
          <div style="background:rgba(6,10,20,.95);padding:14px;border-radius:10px;">
            <div style="display:flex;justify-content:space-between;align-items:center;color:#fff;margin-bottom:8px">
              <strong>Customize your dashboard</strong>
              <button id="smmcare-branding-close" style="background:transparent;border:0;color:#fff;font-size:18px">✕</button>
            </div>
            <div id="smmcare-branding-modal-content" style="color:#e6eef8">
              <?php echo do_shortcode( '[smmcare_branding_form]' ); ?>
            </div>
          </div>
        </div>

        <script>
        (function(){
          var fab = document.getElementById('smmcare-branding-fab');
          var modal = document.getElementById('smmcare-branding-modal');
          var close = document.getElementById('smmcare-branding-close');
          if(fab){
            fab.addEventListener('click', function(){ modal.style.display = 'block'; });
          }
          if(close){
            close.addEventListener('click', function(){ modal.style.display = 'none'; });
          }
        })();
        </script>
        <?php
    }
}
SMMCARE_Customer_Branding::init();
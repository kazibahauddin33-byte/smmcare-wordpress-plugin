<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * IMAP wrapper to fetch inbound mail for review invites or ticket creation.
 * This is a minimal, optional helper; requires PHP IMAP extension enabled.
 */
class SMMCARE_IMAP {
    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'register' ] );
    }

    public static function register() {
        register_rest_route( 'smmcare/v1', '/imap/fetch', [
            'methods' => 'POST',
            'callback' => [ __CLASS__, 'fetch_mail' ],
            'permission_callback' => function(){ return current_user_can( 'manage_options' ); },
        ] );
    }

    public static function fetch_mail( WP_REST_Request $request ) {
        $p = $request->get_json_params();
        $host = sanitize_text_field( $p['host'] ?? '' );
        $username = sanitize_text_field( $p['username'] ?? '' );
        $password = $p['password'] ?? '';
        $mailbox = sanitize_text_field( $p['mailbox'] ?? 'INBOX' );
        if ( empty( $host ) || empty( $username ) || empty( $password ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'host/username/password required' ], 400 );
        }
        if ( ! function_exists( 'imap_open' ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'PHP IMAP extension not enabled' ], 501 );
        }

        $conn_str = "{" . $host . "}$mailbox";
        $mbox = @imap_open( $conn_str, $username, $password, 0, 3 );
        if ( ! $mbox ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'IMAP connect failed: ' . imap_last_error() ], 500 );
        }
        $msgs = [];
        $num = imap_num_msg( $mbox );
        for ( $i = max(1, $num - 49); $i <= $num; $i++ ) {
            $header = imap_headerinfo( $mbox, $i );
            $body = imap_body( $mbox, $i );
            $msgs[] = [
                'subject' => $header->subject ?? '',
                'from' => $header->fromaddress ?? '',
                'date' => $header->date ?? '',
                'snippet' => wp_trim_words( wp_strip_all_tags( $body ), 50 ),
            ];
        }
        imap_close( $mbox );
        return rest_ensure_response( [ 'success' => true, 'count' => count( $msgs ), 'messages' => $msgs ] );
    }
}

SMMCARE_IMAP::init();
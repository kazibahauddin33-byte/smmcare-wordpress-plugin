<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_GCal {
    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
    }
    public static function routes() {
        register_rest_route( 'smmcare/v1', '/gcal/start', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_start'],'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/gcal/callback', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_callback'],'permission_callback'=>'__return_true' ]);
        register_rest_route( 'smmcare/v1', '/gcal/calendars', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_list_calendars'],'permission_callback'=>function(){return is_user_logged_in();} ]);
        register_rest_route( 'smmcare/v1', '/gcal/book', [ 'methods'=>'POST','callback'=>[__CLASS__,'rest_create_event'],'permission_callback'=>function(){return is_user_logged_in();} ]);
    }
    public static function rest_start() { $client_id = get_option('smmcare_gcal_client_id',''); $redirect = rest_url('smmcare/v1/gcal/callback'); $url = 'https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=' . rawurlencode($client_id) . '&redirect_uri=' . rawurlencode($redirect) . '&scope=' . rawurlencode('https://www.googleapis.com/auth/calendar') . '&access_type=offline&prompt=consent'; return rest_ensure_response([ 'success'=>true,'url'=>$url ]); }
    public static function rest_callback( $req ) { return rest_ensure_response([ 'success'=>true,'message'=>'GCal callback (stub)' ]); }
    public static function rest_list_calendars() { return rest_ensure_response([ 'success'=>true,'data'=>[] ]); }
    public static function rest_create_event( $req ) { return rest_ensure_response([ 'success'=>true,'event'=>[] ]); }
}
SMMCARE_GCal::init();
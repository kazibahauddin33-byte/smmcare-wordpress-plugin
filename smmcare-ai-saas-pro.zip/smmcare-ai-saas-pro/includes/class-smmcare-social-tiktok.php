<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Social_Tiktok {
    public static function routes() {
        add_action( 'rest_api_init', function(){
            register_rest_route( 'smmcare/v1', '/social/tiktok/start', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_start'],'permission_callback'=>function(){return current_user_can('manage_options');} ]);
            register_rest_route( 'smmcare/v1', '/social/tiktok/callback', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_callback'],'permission_callback'=>'__return_true' ]);
            register_rest_route( 'smmcare/v1', '/social/tiktok/post', [ 'methods'=>'POST','callback'=>[__CLASS__,'rest_post'],'permission_callback'=>function(){return is_user_logged_in();} ]);
        } );
    }
    public static function rest_start() { return rest_ensure_response([ 'success'=>true,'message'=>'TikTok stub' ]); }
    public static function rest_callback( $req ) { return rest_ensure_response([ 'success'=>true,'message'=>'TikTok callback stub' ]); }
    public static function rest_post( $req ) { return rest_ensure_response([ 'success'=>true,'message'=>'TikTok post queued (demo)' ]); }
}
SMMCARE_Social_Tiktok::routes();
<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class SMMCARE_Quotas {
    public static function init() { add_action( 'admin_init', [ __CLASS__, 'maybe_create_table' ] ); }
    public static function maybe_create_table() {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'smmcare_usage';
        // If table exists, skip dbDelta to avoid altering columns in-place (some MariaDB versions choke on dbDelta ALTERs)
        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        if ( $exists ) {
            error_log( "SMMCARE: maybe_create_table - table {$table} already exists, skipping dbDelta." );
            return;
        }
        $sql = "CREATE TABLE {$table} ( id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, customer_id BIGINT UNSIGNED NOT NULL, feature VARCHAR(64) NOT NULL, amount BIGINT UNSIGNED DEFAULT 0, period_start DATE DEFAULT NULL, updated_at DATETIME NOT NULL, PRIMARY KEY (id), KEY customer_feature (customer_id,feature) ) {$charset};";
        dbDelta( $sql );
    }
    public static function get_limits_for_plan( $plan ) {
        $map = [ 'starter'=>['ai_tokens'=>10000,'sms'=>200,'posts'=>200], 'pro'=>['ai_tokens'=>250000,'sms'=>2000,'posts'=>2000], 'enterprise'=>['ai_tokens'=>2000000,'sms'=>20000,'posts'=>20000] ];
        return $map[$plan] ?? $map['starter'];
    }
    public static function check_and_consume( $customer_id, $feature, $amount = 1 ) {
        global $wpdb;
        $cust = $wpdb->get_row( $wpdb->prepare( "SELECT plan_slug FROM {$wpdb->prefix}smmcare_customers WHERE id = %d LIMIT 1", $customer_id ) );
        $plan = $cust ? $cust->plan_slug : 'starter';
        $limits = self::get_limits_for_plan( $plan );
        $limit = $limits[$feature] ?? PHP_INT_MAX;
        $today = date( 'Y-m-d' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_usage WHERE customer_id = %d AND feature = %s AND period_start = %s", $customer_id, $feature, $today ), ARRAY_A );
        if ( $row ) {
            $used = intval( $row['amount'] );
            if ( $used + $amount > $limit ) return false;
            $wpdb->update( $wpdb->prefix . 'smmcare_usage', [ 'amount' => $used + $amount, 'updated_at' => current_time('mysql') ], [ 'id' => $row['id'] ] );
            return true;
        } else {
            if ( $amount > $limit ) return false;
            $wpdb->insert( $wpdb->prefix . 'smmcare_usage', [ 'customer_id'=>$customer_id, 'feature'=>$feature, 'amount'=>$amount, 'period_start'=>$today, 'updated_at'=>current_time('mysql') ] );
            return true;
        }
    }
}
SMMCARE_Quotas::init();
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Settings {
    private static $instance = null;
    const OPTION_KEY = 'smmcare_settings';

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'rest_api_init', [ $this, 'rest_routes' ] );
    }

    public function add_menu() {
        add_submenu_page( 'smmcare-pro', 'Settings', 'Settings', 'manage_options', 'smmcare-settings', [ $this, 'render_settings_page' ] );
    }

    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'smmcare-pro_page_smmcare-settings' ) === false ) return;
        wp_enqueue_style( 'smmcare-settings-css', SMMCARE_URL . 'assets/css/settings.css', [], SMMCARE_VERSION );
        wp_enqueue_script( 'smmcare-settings-js', SMMCARE_URL . 'assets/js/settings-admin.js', [ 'jquery' ], SMMCARE_VERSION, true );
        wp_localize_script( 'smmcare-settings-js', 'smmcareSettings', [ 'rest_root'=>esc_url_raw( rest_url( 'smmcare/v1' ) ), 'nonce'=>wp_create_nonce( 'wp_rest' ) ] );
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $s = $this->get_all();
        $mask = function( $v ) { return $v ? substr( $v, 0, 4 ) . '••••' : ''; };
        ?>
        <div class="wrap smmcare-settings-wrap">
          <h1>SMMCARE Settings</h1>
          <form id="smmcare-settings-form">
            <h2>Billing / Stripe</h2>
            <table class="form-table">
              <tr><th>Stripe Secret Key</th><td><input type="password" id="smmcare_stripe_secret" value="<?php echo esc_attr( $mask($s['stripe_secret']??'') ); ?>" style="width:60%"/></td></tr>
              <tr><th>Stripe Webhook Secret</th><td><input type="password" id="smmcare_stripe_webhook_secret" value="<?php echo esc_attr( $mask($s['stripe_webhook_secret']??'') ); ?>" style="width:60%"/></td></tr>
              <tr><th>Starter price id</th><td><input id="smmcare_price_starter" value="<?php echo esc_attr( $s['stripe_price_starter'] ?? '' ); ?>" style="width:50%"/></td></tr>
              <tr><th>Pro price id</th><td><input id="smmcare_price_pro" value="<?php echo esc_attr( $s['stripe_price_pro'] ?? '' ); ?>" style="width:50%"/></td></tr>
              <tr><th>Enterprise price id</th><td><input id="smmcare_price_enterprise" value="<?php echo esc_attr( $s['stripe_price_enterprise'] ?? '' ); ?>" style="width:50%"/></td></tr>
            </table>

            <h2>OpenAI</h2>
            <table class="form-table">
              <tr><th>OpenAI API Key</th><td><input type="password" id="smmcare_openai_key" value="<?php echo esc_attr( $mask($s['openai_key']??'') ); ?>" style="width:60%" /></td></tr>
            </table>

            <h2>Twilio</h2>
            <table class="form-table">
              <tr><th>Twilio SID</th><td><input type="password" id="smmcare_twilio_sid" value="<?php echo esc_attr( $mask($s['twilio_sid']??'') ); ?>" style="width:60%"/></td></tr>
              <tr><th>Twilio Token</th><td><input type="password" id="smmcare_twilio_token" value="<?php echo esc_attr( $mask($s['twilio_token']??'') ); ?>" style="width:60%"/></td></tr>
              <tr><th>From Phone</th><td><input type="text" id="smmcare_twilio_from" value="<?php echo esc_attr( $s['twilio_from'] ?? '' ); ?>" /></td></tr>
            </table>

            <h2>SMTP (Site)</h2>
            <table class="form-table">
              <tr><th>Host</th><td><input id="smmcare_smtp_host" value="<?php echo esc_attr( $s['smtp_host']??'' ); ?>"/></td></tr>
              <tr><th>Port</th><td><input id="smmcare_smtp_port" value="<?php echo esc_attr( $s['smtp_port']??'587' ); ?>"/></td></tr>
              <tr><th>User</th><td><input id="smmcare_smtp_user" value="<?php echo esc_attr( $mask( $s['smtp_user']??'' ) ); ?>"/></td></tr>
              <tr><th>Password</th><td><input type="password" id="smmcare_smtp_pass" value="<?php echo esc_attr( $mask( $s['smtp_pass']??'' ) ); ?>"/></td></tr>
              <tr><th>Encryption</th><td><select id="smmcare_smtp_enc"><option value="">None</option><option value="ssl" <?php selected($s['smtp_enc']??'','ssl');?>>SSL</option><option value="tls" <?php selected($s['smtp_enc']??'','tls');?>>TLS</option></select></td></tr>
              <tr><th>From</th><td><input id="smmcare_smtp_from" value="<?php echo esc_attr( $s['smtp_from'] ?? get_option('admin_email') ); ?>"/></td></tr>
            </table>

            <h2>Social App Keys</h2>
            <table class="form-table">
              <tr><th>X Client ID</th><td><input id="smmcare_x_client_id" value="<?php echo esc_attr( $s['x_client_id']??'' ); ?>"/></td></tr>
              <tr><th>X Client Secret</th><td><input type="password" id="smmcare_x_client_secret" value="<?php echo esc_attr( $mask($s['x_client_secret']??'') ); ?>"/></td></tr>
              <tr><th>LinkedIn Client ID</th><td><input id="smmcare_li_client_id" value="<?php echo esc_attr( $s['li_client_id']??'' ); ?>"/></td></tr>
              <tr><th>LinkedIn Client Secret</th><td><input type="password" id="smmcare_li_client_secret" value="<?php echo esc_attr( $mask($s['li_client_secret']??'') ); ?>"/></td></tr>
              <tr><th>Facebook App ID</th><td><input id="smmcare_fb_app_id" value="<?php echo esc_attr( $s['fb_app_id']??'' ); ?>"/></td></tr>
              <tr><th>Facebook App Secret</th><td><input type="password" id="smmcare_fb_app_secret" value="<?php echo esc_attr( $mask($s['fb_app_secret']??'') ); ?>"/></td></tr>
              <tr><th>Google Client ID</th><td><input id="smmcare_gcal_client_id" value="<?php echo esc_attr( $s['gcal_client_id']??'' ); ?>"/></td></tr>
              <tr><th>Google Client Secret</th><td><input type="password" id="smmcare_gcal_client_secret" value="<?php echo esc_attr( $mask($s['gcal_client_secret']??'') ); ?>"/></td></tr>
              <tr><th>TikTok Client ID</th><td><input id="smmcare_tiktok_client_id" value="<?php echo esc_attr( $s['tiktok_client_id']??'' ); ?>"/></td></tr>
              <tr><th>TikTok Client Secret</th><td><input type="password" id="smmcare_tiktok_client_secret" value="<?php echo esc_attr( $mask($s['tiktok_client_secret']??'') ); ?>"/></td></tr>
            </table>

            <p><button id="smmcare-settings-save" class="button button-primary">Save Settings</button></p>
          </form>
        </div>
        <?php
    }

    public function rest_routes() {
        register_rest_route( 'smmcare/v1', '/settings', [
            'methods' => 'GET',
            'callback' => [ $this, 'rest_get_settings' ],
            'permission_callback' => function(){ return current_user_can( 'manage_options' ); }
        ] );
        register_rest_route( 'smmcare/v1', '/settings', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_save_settings' ],
            'permission_callback' => function(){ return current_user_can( 'manage_options' ); }
        ] );
        register_rest_route( 'smmcare/v1', '/settings/twilio-test', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_twilio_test' ],
            'permission_callback' => function(){ return current_user_can( 'manage_options' ); }
        ] );
    }

    public function rest_get_settings( $request ) {
        $s = $this->get_all();
        $out = [
            'stripe_configured' => ! empty( $s['stripe_secret'] ?? '' ),
            'stripe_webhook_configured' => ! empty( $s['stripe_webhook_secret'] ?? '' ),
            'openai_configured' => ! empty( $s['openai_key'] ?? '' ),
            'twilio_configured' => ! empty( $s['twilio_sid'] ?? '' ) && ! empty( $s['twilio_token'] ?? '' ),
            'twilio_from' => $s['twilio_from'] ?? '',
            'stripe_price_starter' => $s['stripe_price_starter'] ?? '',
            'stripe_price_pro' => $s['stripe_price_pro'] ?? '',
            'stripe_price_enterprise' => $s['stripe_price_enterprise'] ?? '',
            'smtp_configured' => ! empty( $s['smtp_host'] ?? '' ) && ! empty( $s['smtp_user'] ?? '' ),
            'smtp_from' => $s['smtp_from'] ?? get_option( 'admin_email' ),
            'x_app_configured' => ! empty( $s['x_client_id'] ?? '' ) && ! empty( $s['x_client_secret'] ?? '' ),
            'linkedin_app_configured' => ! empty( $s['li_client_id'] ?? '' ) && ! empty( $s['li_client_secret'] ?? '' ),
            'facebook_app_configured' => ! empty( $s['fb_app_id'] ?? '' ) && ! empty( $s['fb_app_secret'] ?? '' ),
            'gcal_app_configured' => ! empty( $s['gcal_client_id'] ?? '' ) && ! empty( $s['gcal_client_secret'] ?? '' ),
            'tiktok_app_configured' => ! empty( $s['tiktok_client_id'] ?? '' ) && ! empty( $s['tiktok_client_secret'] ?? '' ),
        ];
        return rest_ensure_response( [ 'success' => true, 'data' => $out ] );
    }

    public function rest_save_settings( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $current = $this->get_all();
        $keys = [ 'stripe_secret','stripe_webhook_secret','openai_key','twilio_sid','twilio_token','twilio_from','stripe_price_starter','stripe_price_pro','stripe_price_enterprise','smtp_host','smtp_port','smtp_user','smtp_pass','smtp_from','smtp_enc',
            'x_client_id','x_client_secret','li_client_id','li_client_secret','fb_app_id','fb_app_secret','gcal_client_id','gcal_client_secret','tiktok_client_id','tiktok_client_secret' ];
        foreach ( $keys as $k ) {
            if ( isset( $params[ $k ] ) ) {
                $val = $params[ $k ];
                if ( is_string( $val ) && preg_match( '/[••]{1,}|…|\\u2022/u', $val ) ) continue;
                if ( in_array( $k, [ 'stripe_secret','stripe_webhook_secret','openai_key','twilio_sid','twilio_token','smtp_pass','smtp_user','x_client_secret','li_client_secret','fb_app_secret','gcal_client_secret','tiktok_client_secret' ], true ) ) {
                    $current[ $k ] = $this->maybe_encrypt( $val );
                } else {
                    $current[ $k ] = sanitize_text_field( $val );
                }
            }
        }
        $current['last_updated'] = current_time( 'mysql' );
        update_option( self::OPTION_KEY, $current );
        return rest_ensure_response( [ 'success' => true ] );
    }

    public function rest_twilio_test( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $to = sanitize_text_field( $params['to'] ?? '' );
        $message = sanitize_textarea_field( $params['message'] ?? 'Test message' );
        if ( empty( $to ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'recipient required' ], 400 );
        $tw = $this->get_twilio_credentials();
        if ( empty( $tw['sid'] ) || empty( $tw['token'] ) || empty( $tw['from'] ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'Twilio incomplete' ], 400 );
        $url = "https://api.twilio.com/2010-04-01/Accounts/" . rawurlencode( $tw['sid'] ) . "/Messages.json";
        $args = [ 'headers'=>[ 'Authorization'=>'Basic '.base64_encode( $tw['sid'] . ':' . $tw['token'] ) ], 'body'=>[ 'From'=>$tw['from'], 'To'=>$to, 'Body'=>$message ], 'timeout'=>30 ];
        $resp = wp_remote_post( $url, $args );
        if ( is_wp_error( $resp ) ) return rest_ensure_response( [ 'success' => false, 'message' => $resp->get_error_message() ], 500 );
        $code = wp_remote_retrieve_response_code( $resp );
        $data = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( $code >= 200 && $code < 300 ) return rest_ensure_response( [ 'success' => true, 'response' => $data ] );
        return rest_ensure_response( [ 'success' => false, 'message' => 'Twilio API error', 'response' => $data ], $code ?: 500 );
    }

    /* Helpers */
    public function get_all() { $s = get_option( self::OPTION_KEY, [] ); if ( ! is_array( $s ) ) $s = []; $decrypt_keys = [ 'stripe_secret','stripe_webhook_secret','openai_key','twilio_sid','twilio_token','smtp_pass','smtp_user','x_client_secret','li_client_secret','fb_app_secret','gcal_client_secret','tiktok_client_secret' ]; foreach ( $decrypt_keys as $k ) if ( isset( $s[$k] ) && is_string( $s[$k] ) && $this->looks_encrypted( $s[$k] ) ) { $dec = $this->maybe_decrypt( $s[$k] ); if ( $dec !== false ) $s[$k] = $dec; } return $s; }
    public function get_twilio_credentials() { $a = $this->get_all(); return [ 'sid'=>$a['twilio_sid']??'', 'token'=>$a['twilio_token']??'', 'from'=>$a['twilio_from']??'' ]; }
    public function get_smtp_site_credentials() { $a = $this->get_all(); return [ 'host'=>$a['smtp_host']??'', 'port'=>intval($a['smtp_port']??587), 'user'=>$a['smtp_user']??'', 'pass'=>$a['smtp_pass']??'', 'from'=>$a['smtp_from']??get_option('admin_email'), 'enc'=>$a['smtp_enc']??'' ]; }
    private function looks_encrypted( $s ) { return preg_match( '/^[A-Za-z0-9+\/]+=*$/', $s ) && strlen( $s ) > 24; }
    public function maybe_encrypt( $p ) { if ( defined('SMMCARE_SECRET_KEY') && SMMCARE_SECRET_KEY ) return $this->encrypt( $p, SMMCARE_SECRET_KEY ); if ( defined('AUTH_SALT') && AUTH_SALT ) return $this->encrypt( $p, AUTH_SALT ); return $p; }
    public function maybe_decrypt( $c ) { if ( defined('SMMCARE_SECRET_KEY') && SMMCARE_SECRET_KEY ) return $this->decrypt( $c, SMMCARE_SECRET_KEY ); if ( defined('AUTH_SALT') && AUTH_SALT ) return $this->decrypt( $c, AUTH_SALT ); return $c; }
    private function encrypt( $pt, $key ) { if ( empty($pt) ) return ''; $iv = openssl_random_pseudo_bytes(16); $k = substr( hash('sha256', $key, true), 0, 32 ); $cipher = openssl_encrypt( $pt, 'AES-256-CBC', $k, OPENSSL_RAW_DATA, $iv ); if ( $cipher === false ) return $pt; return base64_encode( $iv . $cipher ); }
    private function decrypt( $b64, $key ) { if ( empty($b64) ) return ''; $raw = base64_decode( $b64 ); if ( $raw === false || strlen($raw) <= 16 ) return false; $iv = substr( $raw, 0, 16 ); $cipher = substr( $raw, 16 ); $k = substr( hash('sha256', $key, true), 0, 32 ); $plain = openssl_decrypt( $cipher, 'AES-256-CBC', $k, OPENSSL_RAW_DATA, $iv ); return $plain === false ? false : $plain; }
}
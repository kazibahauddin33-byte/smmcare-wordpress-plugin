<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class SMMCARE_SMS_Campaigns {
    public static function init() { add_action('rest_api_init', [ __CLASS__, 'routes' ] ); add_action( 'smmcare_five_min_cron', [ __CLASS__, 'process_queue' ] ); add_action( 'admin_init', [ __CLASS__, 'maybe_create_tables' ] ); }
    public static function routes() {
        register_rest_route( 'smmcare/v1', '/sms/campaigns', [ 'methods'=>'POST','callback'=>[ __CLASS__, 'create_campaign' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/sms/campaigns/(?P<id>\d+)/queue', [ 'methods'=>'POST','callback'=>[ __CLASS__, 'queue_campaign' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/sms/queue', [ 'methods'=>'GET','callback'=>[ __CLASS__, 'list_queue' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
    }
    public static function maybe_create_tables() { 
        require_once ABSPATH . 'wp-admin/includes/upgrade.php'; 
        global $wpdb; 
        $charset = $wpdb->get_charset_collate(); 

        $table_queue = $wpdb->prefix . 'smmcare_sms_queue';
        $q1 = "CREATE TABLE {$table_queue} ( id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, campaign_id BIGINT UNSIGNED NOT NULL, customer_id BIGINT UNSIGNED DEFAULT 0, to_number VARCHAR(64) NOT NULL, body TEXT, status VARCHAR(32) DEFAULT 'queued', attempt INT DEFAULT 0, last_attempt_at DATETIME DEFAULT NULL, created_at DATETIME NOT NULL, PRIMARY KEY (id), KEY campaign_id (campaign_id), KEY customer_id (customer_id), KEY status (status) ) {$charset};";

        $table_logs = $wpdb->prefix . 'smmcare_sms_logs';
        $q2 = "CREATE TABLE {$table_logs} ( id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, queue_id BIGINT UNSIGNED NOT NULL, response LONGTEXT, code INT DEFAULT 0, created_at DATETIME NOT NULL, PRIMARY KEY (id), KEY queue_id (queue_id) ) {$charset};";

        $table_campaigns = $wpdb->prefix . 'smmcare_sms_campaigns';
        $q3 = "CREATE TABLE IF NOT EXISTS {$table_campaigns} ( id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, customer_id BIGINT UNSIGNED DEFAULT 0, title VARCHAR(191) DEFAULT '', body TEXT, created_at DATETIME NOT NULL, PRIMARY KEY (id) ) {$charset};";

        // Create only missing tables to avoid dbDelta ALTER generation on existing tables
        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_queue ) ) ) {
            dbDelta( $q1 );
        } else {
            error_log( "SMMCARE: maybe_create_tables - {$table_queue} already exists, skipping creation." );
        }

        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_logs ) ) ) {
            dbDelta( $q2 );
        } else {
            error_log( "SMMCARE: maybe_create_tables - {$table_logs} already exists, skipping creation." );
        }

        if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_campaigns ) ) ) {
            dbDelta( $q3 );
        } else {
            error_log( "SMMCARE: maybe_create_tables - {$table_campaigns} already exists, skipping creation." );
        }
    }
    public static function create_campaign( $req ) { $p = $req->get_json_params(); $title = sanitize_text_field($p['title']??''); $body = sanitize_textarea_field($p['body']??''); $customer_id = intval($p['customer_id'] ?? 0); if ( empty($title) || empty($body) ) return rest_ensure_response([ 'success'=>false,'message'=>'title/body required' ],400); global $wpdb; $wpdb->insert( $wpdb->prefix.'smmcare_sms_campaigns', [ 'customer_id'=>$customer_id, 'title'=>$title, 'body'=>$body, 'created_at'=>current_time('mysql') ] ); return rest_ensure_response([ 'success'=>true, 'campaign_id'=>(int)$wpdb->insert_id ]); }
    public static function queue_campaign( $req ) { $id = intval($req->get_param('id')); $p = $req->get_json_params(); $recipients = $p['recipients'] ?? []; if ( ! is_array($recipients) || empty($recipients) ) return rest_ensure_response([ 'success'=>false,'message'=>'recipients required' ],400); global $wpdb; $campaign = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->prefix}smmcare_sms_campaigns WHERE id=%d LIMIT 1",$id) ); if ( ! $campaign ) return rest_ensure_response([ 'success'=>false,'message'=>'Campaign not found' ],404); $count = 0; foreach ( $recipients as $to ) { $to = sanitize_text_field($to); if ( empty($to) ) continue; $wpdb->insert( $wpdb->prefix.'smmcare_sms_queue', [ 'campaign_id'=>$id, 'customer_id'=>$campaign->customer_id, 'to_number'=>$to, 'body'=>$campaign->body, 'status'=>'queued', 'created_at'=>current_time('mysql') ] ); $count++; } return rest_ensure_response([ 'success'=>true,'queued'=>$count ]); }
    public static function list_queue() { global $wpdb; $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_sms_queue ORDER BY created_at DESC LIMIT 200", ARRAY_A ); return rest_ensure_response([ 'success'=>true,'data'=>$rows ]); }
    public static function process_queue() {
        global $wpdb;
        $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_sms_queue WHERE status='queued' ORDER BY created_at ASC LIMIT 200" );
        $sent_by_customer = [];
        foreach ( $rows as $r ) {
            $cid = intval( $r->customer_id );
            $plan_slug = $wpdb->get_var( $wpdb->prepare( "SELECT plan_slug FROM {$wpdb->prefix}smmcare_customers WHERE id = %d LIMIT 1", $cid ) );
            $limit = 20; if ( $plan_slug === 'pro' ) $limit = 200; if ( $plan_slug === 'enterprise' ) $limit = 1000;
            if ( ! isset( $sent_by_customer[$cid] ) ) $sent_by_customer[$cid] = 0;
            if ( $sent_by_customer[$cid] >= $limit ) continue;
            $settings = SMMCARE_Settings::instance()->get_twilio_credentials();
            if ( empty($settings['sid']) ) { $wpdb->update( $wpdb->prefix . 'smmcare_sms_queue', [ 'status'=>'failed','attempt'=> $r->attempt + 1, 'last_attempt_at'=>current_time('mysql') ], [ 'id'=>$r->id ] ); continue; }
            $url = "https://api.twilio.com/2010-04-01/Accounts/" . rawurlencode($settings['sid']) . "/Messages.json";
            $args = [ 'headers'=>[ 'Authorization'=>'Basic '.base64_encode($settings['sid'].':'.$settings['token']) ], 'body'=>[ 'From'=>$settings['from'], 'To'=>$r->to_number, 'Body'=>$r->body ], 'timeout'=>30 ];
            $resp = wp_remote_post( $url, $args );
            $code = is_wp_error($resp) ? 500 : wp_remote_retrieve_response_code($resp);
            $resp_body = is_wp_error($resp) ? $resp->get_error_message() : wp_remote_retrieve_body($resp);
            if ( $code >=200 && $code < 300 ) $wpdb->update( $wpdb->prefix . 'smmcare_sms_queue', [ 'status'=>'sent','attempt'=> $r->attempt + 1,'last_attempt_at'=>current_time('mysql') ], [ 'id'=>$r->id ] );
            else $wpdb->update( $wpdb->prefix . 'smmcare_sms_queue', [ 'status'=>'failed','attempt'=> $r->attempt + 1,'last_attempt_at'=>current_time('mysql') ], [ 'id'=>$r->id ] );
            $wpdb->insert( $wpdb->prefix . 'smmcare_sms_logs', [ 'queue_id'=>$r->id, 'response'=>$resp_body, 'code'=>intval($code), 'created_at'=>current_time('mysql') ] );
            $sent_by_customer[$cid]++;
        }
    }
}
SMMCARE_SMS_Campaigns::init();
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Social_Store {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            add_action( 'admin_init', [ self::$instance, 'maybe_create_table' ] );
        }
        return self::$instance;
    }
    public function maybe_create_table() {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        $table = $wpdb->prefix . 'smmcare_social_tokens';

        // If table exists, skip dbDelta to avoid unsafe ALTERs
        $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
        if ( $exists ) {
            error_log( "SMMCARE: maybe_create_table - table {$table} already exists, skipping dbDelta." );
            return;
        }

        $sql = "CREATE TABLE {$table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            customer_id BIGINT UNSIGNED DEFAULT 0,
            provider VARCHAR(64) NOT NULL,
            account_id VARCHAR(191) DEFAULT '',
            access_token LONGTEXT,
            refresh_token LONGTEXT,
            expires_at DATETIME DEFAULT NULL,
            meta LONGTEXT,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY customer_id (customer_id),
            KEY provider (provider),
            KEY account_id (account_id)
        ) {$charset_collate};";
        dbDelta( $sql );
    }
    public function save_token( $customer_id, $provider, $account_id, $access_token, $refresh_token = '', $expires_at = null, $meta = [] ) {
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_social_tokens';
        $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE provider=%s AND account_id=%s AND customer_id=%d LIMIT 1", $provider, $account_id, $customer_id ) );
        $data = [ 'customer_id'=>$customer_id, 'provider'=>$provider, 'account_id'=>$account_id, 'access_token'=>maybe_serialize($access_token),'refresh_token'=>maybe_serialize($refresh_token),'expires_at'=>$expires_at?date('Y-m-d H:i:s',intval($expires_at)):null,'meta'=>wp_json_encode($meta),'updated_at'=>current_time('mysql') ];
        if ( $exists ) { $wpdb->update( $table, $data, [ 'id'=>$exists ] ); return $exists; } else { $wpdb->insert( $table, $data ); return (int)$wpdb->insert_id; }
    }
    public function get_tokens_by_customer( $customer_id, $provider = '' ) {
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_social_tokens';
        if ( $provider ) $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE customer_id=%d AND provider=%s", $customer_id, $provider ), ARRAY_A );
        else $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE customer_id=%d", $customer_id ), ARRAY_A );
        return array_map(function($r){ $r['access_token']=maybe_unserialize($r['access_token']); $r['refresh_token']=maybe_unserialize($r['refresh_token']); $r['meta']=json_decode($r['meta']?:'{}',true); return $r; }, $rows);
    }
    public function get_token( $provider, $account_id, $customer_id = 0 ) {
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_social_tokens';
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE provider=%s AND account_id=%s AND customer_id=%d LIMIT 1", $provider, $account_id, $customer_id ), ARRAY_A );
        if ( ! $row ) return null;
        $row['access_token'] = maybe_unserialize( $row['access_token'] );
        $row['refresh_token'] = maybe_unserialize( $row['refresh_token'] );
        $row['meta'] = json_decode( $row['meta']?:'{}', true );
        return $row;
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE DB Fix utility (safe rename + recreate)
 *
 * Usage:
 *  - Place this file at: wp-content/plugins/smmcare-ai-saas-pro/includes/class-smmcare-db-fix.php
 *  - Take a full DB backup first.
 *  - As WP admin visit: /wp-admin/?smmcare_fix_db=1
 *
 * This will:
 *  - Rename existing target tables to *_broken_<timestamp> (preserves data).
 *  - Create fresh tables using dbDelta with the correct CREATE TABLE definitions.
 *  - Show an admin notice with results and log them.
 *
 * IMPORTANT: This does not migrate data from the renamed tables into the new tables.
 * If you want data migrated, run SHOW CREATE TABLE for the *_broken_* tables and paste them here;
 * I will prepare column-accurate migration SQL.
 */
class SMMCARE_DB_Fix {
    public static function init() {
        add_action( 'admin_init', [ __CLASS__, 'maybe_run' ] );
    }

    public static function maybe_run() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( ! isset( $_GET['smmcare_fix_db'] ) || $_GET['smmcare_fix_db'] != '1' ) return;

        global $wpdb;
        $prefix = $wpdb->prefix;

        // Tables we will ensure exist (correct CREATE TABLE SQL)
        $targets = [
            'smmcare_usage' => "CREATE TABLE {$prefix}smmcare_usage (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                customer_id BIGINT UNSIGNED NOT NULL,
                feature VARCHAR(64) NOT NULL,
                amount BIGINT UNSIGNED DEFAULT 0,
                period_start DATE DEFAULT NULL,
                updated_at DATETIME NOT NULL,
                PRIMARY KEY (id),
                KEY customer_feature (customer_id,feature)
            ) {$wpdb->get_charset_collate()};",

            'smmcare_sms_queue' => "CREATE TABLE {$prefix}smmcare_sms_queue (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                campaign_id BIGINT UNSIGNED NOT NULL,
                customer_id BIGINT UNSIGNED DEFAULT 0,
                to_number VARCHAR(64) NOT NULL,
                body TEXT,
                status VARCHAR(32) DEFAULT 'queued',
                attempt INT DEFAULT 0,
                last_attempt_at DATETIME DEFAULT NULL,
                created_at DATETIME NOT NULL,
                PRIMARY KEY (id),
                KEY campaign_id (campaign_id),
                KEY customer_id (customer_id),
                KEY status (status)
            ) {$wpdb->get_charset_collate()};",

            'smmcare_sms_logs' => "CREATE TABLE {$prefix}smmcare_sms_logs (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                queue_id BIGINT UNSIGNED NOT NULL,
                response LONGTEXT,
                code INT DEFAULT 0,
                created_at DATETIME NOT NULL,
                PRIMARY KEY (id),
                KEY queue_id (queue_id)
            ) {$wpdb->get_charset_collate()};",
        ];

        // Safety: require a DB backup confirmation param optionally
        // (We trust that admin has backed up per instructions above.)

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $ts = date( 'Ymd_His' );
        $messages = [];

        foreach ( $targets as $short => $create_sql ) {
            $table = $prefix . $short;

            // Check if table exists
            $exists = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
            if ( $exists ) {
                $backup = $table . '_broken_' . $ts;
                // ensure backup name not colliding
                if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $backup ) ) ) {
                    $backup .= '_' . substr( wp_generate_password( 6, false, false ), 0, 6 );
                }
                $rename_sql = "RENAME TABLE `{$table}` TO `{$backup}`;";
                $res = $wpdb->query( $rename_sql );
                if ( $res === false ) {
                    $messages[] = "ERROR: Failed to rename {$table} to {$backup}. SQL: {$rename_sql}";
                    error_log( "SMMCARE DB Fix: Failed rename {$table} -> {$backup}. MySQL said: " . $wpdb->last_error );
                    continue;
                } else {
                    $messages[] = "Renamed {$table} -> {$backup}";
                    error_log( "SMMCARE DB Fix: Renamed {$table} -> {$backup}" );
                }
            } else {
                $messages[] = "Table {$table} does not exist (will be created fresh).";
                error_log( "SMMCARE DB Fix: Table {$table} does not exist (creating fresh)." );
            }

            // Create clean table using dbDelta
            dbDelta( $create_sql );

            // Verify creation
            $created = $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table ) );
            if ( $created ) {
                $messages[] = "Created fresh table {$table}.";
                error_log( "SMMCARE DB Fix: Created fresh table {$table}." );
            } else {
                $messages[] = "ERROR: Failed to create {$table}. Check DB logs.";
                error_log( "SMMCARE DB Fix: Failed to create {$table}. last_error: " . $wpdb->last_error );
            }
        }

        // Admin notice with results
        add_action( 'admin_notices', function() use ( $messages ) {
            echo '<div class="notice notice-success"><p><strong>SMMCARE DB Fix results:</strong></p><ul>';
            foreach ( $messages as $m ) {
                echo '<li>' . esc_html( $m ) . '</li>';
            }
            echo '</ul><p>Backup tables preserved with _broken_TIMESTAMP suffix. If you need data migrated, run SHOW CREATE TABLE on the backup tables and paste results into chat and I will prepare migration SQL.</p></div>';
        } );

        // Redirect to remove query param to avoid re-running accidentally
        wp_safe_redirect( remove_query_arg( 'smmcare_fix_db' ) );
        exit;
    }
}
SMMCARE_DB_Fix::init();
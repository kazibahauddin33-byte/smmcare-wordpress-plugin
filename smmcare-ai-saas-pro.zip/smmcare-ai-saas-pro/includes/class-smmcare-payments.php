<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Payments {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }
    public function hooks() {
        add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_media' ] );
    }
    public function admin_enqueue_media( $hook ) {
        if ( strpos( $hook, 'smmcare-pro' ) === false && strpos( $hook, 'toplevel_page_smmcare-pro' ) === false ) return;
        wp_enqueue_media();
        wp_enqueue_script( 'smmcare-admin-media', SMMCARE_URL . 'assets/js/admin.min.js', [ 'jquery' ], SMMCARE_VERSION, true );
    }
    public function add_admin_menu() {
        add_menu_page( 'SMMCARE Pro', 'SMMCARE Pro', 'manage_options', 'smmcare-pro', [ $this, 'settings_page' ], 'dashicons-chart-area', 59 );
    }
    public function settings_page() {
        // minimal; main admin page lives in class-smmcare-admin.php
    }
    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/payments/create-checkout', [
            'methods' => 'POST',
            'callback' => [ $this, 'create_checkout' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/payments/webhook', [
            'methods' => 'POST',
            'callback' => [ $this, 'handle_webhook' ],
            'permission_callback' => '__return_true',
        ] );
    }
    public function create_checkout( WP_REST_Request $request ) {
        return rest_ensure_response( [ 'success' => false, 'message' => 'Stripe not configured in this build' ], 501 );
    }
    public function handle_webhook( WP_REST_Request $request ) {
        return rest_ensure_response( [ 'success' => true ] );
    }
}
SMMCARE_Payments::instance();
<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class SMMCARE_Twilio {
    private static $instance = null;
    public static function instance() { if ( null === self::$instance ) { self::$instance = new self(); add_action( 'rest_api_init', [ self::$instance, 'routes' ] ); } return self::$instance; }
    public function routes() {
        register_rest_route( 'smmcare/v1', '/twilio/config', [ 'methods'=>'GET','callback'=>[ $this, 'rest_get_config' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/twilio/config', [ 'methods'=>'POST','callback'=>[ $this, 'rest_save_config' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
        register_rest_route( 'smmcare/v1', '/twilio/send', [ 'methods'=>'POST','callback'=>[ $this, 'rest_send_sms' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]);
    }
    public function rest_get_config() { $s = SMMCARE_Settings::instance()->get_all(); return rest_ensure_response([ 'success'=>true,'data'=>['sid'=>!empty($s['twilio_sid']),'from'=>$s['twilio_from']??'']]); }
    public function rest_save_config( $req ) { $p = $req->get_json_params(); $cur = SMMCARE_Settings::instance()->get_all(); if ( isset($p['sid']) ) $cur['twilio_sid'] = SMMCARE_Settings::instance()->maybe_encrypt($p['sid']); if ( isset($p['token']) ) $cur['twilio_token'] = SMMCARE_Settings::instance()->maybe_encrypt($p['token']); if ( isset($p['from']) ) $cur['twilio_from'] = sanitize_text_field($p['from']); update_option( SMMCARE_Settings::OPTION_KEY, $cur ); return rest_ensure_response([ 'success'=>true ]); }
    public function rest_send_sms( $req ) {
        $p = $req->get_json_params();
        $to = sanitize_text_field( $p['to'] ?? '' );
        $message = sanitize_textarea_field( $p['message'] ?? '' );
        $customer_id = intval( $p['customer_id'] ?? SMMCARE_Multitenant::instance()->get_customer_id() );
        if ( empty($to) || empty($message) ) return rest_ensure_response([ 'success'=>false,'message'=>'to and message required' ],400);
        if ( ! SMMCARE_Quotas::check_and_consume( $customer_id, 'sms', 1 ) ) return rest_ensure_response([ 'success'=>false,'message'=>'SMS quota exceeded' ],402);
        $tw = SMMCARE_Settings::instance()->get_twilio_credentials();
        if ( empty($tw['sid']) ) return rest_ensure_response([ 'success'=>false,'message'=>'Twilio not configured' ],400);
        $url = "https://api.twilio.com/2010-04-01/Accounts/".rawurlencode($tw['sid'])."/Messages.json";
        $args = [ 'headers'=>[ 'Authorization'=>'Basic '.base64_encode($tw['sid'].':'.$tw['token']) ], 'body'=>[ 'From'=>$tw['from'],'To'=>$to,'Body'=>$message ], 'timeout'=>30 ];
        $resp = wp_remote_post( $url, $args );
        if ( is_wp_error($resp) ) return rest_ensure_response([ 'success'=>false,'message'=>$resp->get_error_message() ],500);
        $code = wp_remote_retrieve_response_code($resp); $data = json_decode( wp_remote_retrieve_body($resp), true );
        if ( $code >=200 && $code < 300 ) { global $wpdb; $wpdb->insert( $wpdb->prefix . 'smmcare_ai_logs', [ 'customer_id'=>$customer_id, 'endpoint'=>'/twilio/send', 'request_body'=>wp_json_encode(['to'=>$to,'body'=>$message]), 'response_body'=>wp_json_encode($data), 'tokens_used'=>0,'cost_usd'=>0,'created_at'=>current_time('mysql') ] ); return rest_ensure_response([ 'success'=>true,'response'=>$data ]); }
        return rest_ensure_response([ 'success'=>false,'message'=>'Twilio error','response'=>$data ], $code ?: 500);
    }
}
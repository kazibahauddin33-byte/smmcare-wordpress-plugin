<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class SMMCARE_Frontend {
    public static function init() {
        add_action( 'init', [ __CLASS__, 'add_rewrites' ] );
        add_filter( 'query_vars', [ __CLASS__, 'add_query_vars' ] );
        add_filter( 'template_include', [ __CLASS__, 'maybe_load_template' ], 20 );
    }
    public static function add_query_vars( $vars ) { $vars[] = 'smmcare_page'; return $vars; }
    public static function add_rewrites() { $pages = [ 'dashboard','ai-tools','crm','campaigns','billing','admin-dashboard','smmcare-2fa-verify' ]; foreach ( $pages as $p ) add_rewrite_rule( '^' . $p . '/?$', 'index.php?smmcare_page=' . $p, 'top' ); }
    public static function maybe_load_template( $template ) { $page = get_query_var( 'smmcare_page' ); if ( empty($page) ) return $template; $tpl = SMMCARE_DIR . 'templates/' . sanitize_file_name( $page ) . '.php'; if ( file_exists( $tpl ) ) { include $tpl; exit; } return $template; }
}
SMMCARE_Frontend::init();
<?php
if ( ! defined( 'ABSPATH' ) ) exit;
class SMMCARE_Payments_Stripe {
    public static function init() { add_action( 'rest_api_init', [ __CLASS__, 'routes' ] ); }
    public static function routes() {
        register_rest_route( 'smmcare/v1', '/payments/create-checkout', [ 'methods'=>'POST','callback'=>[ __CLASS__,'create_checkout' ], 'permission_callback'=>function(){ return is_user_logged_in(); } ]);
        register_rest_route( 'smmcare/v1', '/payments/webhook', [ 'methods'=>'POST','callback'=>[ __CLASS__,'webhook' ], 'permission_callback'=>'__return_true' ]);
    }
    private static function secret() { return trim( get_option( 'smmcare_stripe_secret', '' ) ); }
    private static function webhook_secret() { return trim( get_option( 'smmcare_stripe_webhook_secret', '' ) ); }
    public static function create_checkout( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $secret = self::secret();
        if ( empty( $secret ) ) return rest_ensure_response([ 'success'=>false,'message'=>'Stripe not configured' ],500);
        $price_id = sanitize_text_field( $params['price_id'] ?? '' );
        $success_url = esc_url_raw( $params['success_url'] ?? home_url('/') );
        $cancel_url = esc_url_raw( $params['cancel_url'] ?? home_url('/') );
        $body = [ 'payment_method_types[]'=>'card','success_url'=>$success_url,'cancel_url'=>$cancel_url ];
        if ( $price_id ) { $body['line_items[0][price]'] = $price_id; $body['mode'] = 'subscription'; $body['line_items[0][quantity]'] = 1; } else { $amount = intval( $params['amount'] ?? 0 ); if ( $amount <= 0 ) return rest_ensure_response([ 'success'=>false,'message'=>'amount required' ],400); $currency = sanitize_text_field( $params['currency'] ?? 'usd' ); $body['line_items[0][price_data][currency]'] = $currency; $body['line_items[0][price_data][product_data][name]'] = sanitize_text_field( $params['description'] ?? 'SMMCARE purchase' ); $body['line_items[0][price_data][unit_amount]'] = $amount; $body['line_items[0][quantity]'] = 1; $body['mode'] = 'payment'; }
        $body['metadata[user_id]'] = (string) get_current_user_id();
        $args = [ 'headers'=>[ 'Authorization'=>'Bearer '.$secret, 'Content-Type'=>'application/x-www-form-urlencoded' ], 'body'=>$body, 'timeout'=>30 ];
        $resp = wp_remote_post( 'https://api.stripe.com/v1/checkout/sessions', $args );
        if ( is_wp_error($resp) ) return rest_ensure_response([ 'success'=>false,'message'=>$resp->get_error_message() ],500);
        $code = wp_remote_retrieve_response_code($resp); $b = json_decode( wp_remote_retrieve_body($resp), true );
        if ( $code >=200 && $code < 300 && isset($b['id']) ) return rest_ensure_response([ 'success'=>true,'session'=>$b ]);
        return rest_ensure_response([ 'success'=>false,'message'=>'Stripe error','response'=>$b ], $code ?: 500 );
    }
    public static function webhook( WP_REST_Request $request ) {
        $raw = file_get_contents( 'php://input' );
        $event = json_decode( $raw, true );
        if ( empty($event) || ! isset( $event['type'] ) ) return rest_ensure_response([ 'success'=>false,'message'=>'Invalid payload' ],400);
        global $wpdb;
        switch ( $event['type'] ) {
            case 'checkout.session.completed':
                $sess = $event['data']['object'] ?? null;
                if ( $sess ) {
                    $customer_user_id = intval( $sess['metadata']['user_id'] ?? 0 );
                    $stripe_sub_id = $sess['subscription'] ?? '';
                    $plan_slug = $sess['display_items'][0]['plan']['id'] ?? '';
                    if ( $customer_user_id ) {
                        $cid = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}smmcare_customers WHERE user_id=%d LIMIT 1", $customer_user_id ) );
                        if ( $cid ) SMMCARE_Subscriptions::upsert( $cid, $stripe_sub_id ?: $sess['id'], $plan_slug ?: 'stripe', 'active', $sess['current_period_end'] ?? null );
                    }
                }
                break;
        }
        return rest_ensure_response([ 'success'=>true ]);
    }
}
SMMCARE_Payments_Stripe::init();
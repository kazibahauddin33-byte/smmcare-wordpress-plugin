<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Campaigns: manage email campaigns (create/list/send)
 * - stores campaigns in smmcare_email_campaigns table (created by activation)
 * - lightweight send placeholder that uses SMMCARE_Email
 */
class SMMCARE_Campaigns {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/campaigns', [
            'methods' => 'POST',
            'callback' => [ $this, 'create_campaign' ],
            'permission_callback' => function() { return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/campaigns', [
            'methods' => 'GET',
            'callback' => [ $this, 'list_campaigns' ],
            'permission_callback' => function() { return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/campaigns/(?P<id>\d+)/send', [
            'methods' => 'POST',
            'callback' => [ $this, 'send_campaign' ],
            'permission_callback' => function() { return current_user_can( 'manage_options' ) || is_user_logged_in(); },
        ] );
    }

    public function create_campaign( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $subject = sanitize_text_field( $params['subject'] ?? '' );
        $body = wp_kses_post( $params['body'] ?? '' );
        $list_id = sanitize_text_field( $params['list_id'] ?? '' );
        $scheduled_at = sanitize_text_field( $params['scheduled_at'] ?? null );
        $user = get_current_user_id();

        if ( empty( $subject ) || empty( $body ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Subject and body are required' ], 400 );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_email_campaigns';
        $wpdb->insert( $table, [
            'customer_id' => $user,
            'subject' => $subject,
            'body' => $body,
            'list_id' => $list_id,
            'scheduled_at' => $scheduled_at ? date( 'Y-m-d H:i:s', strtotime( $scheduled_at ) ) : null,
            'status' => $scheduled_at ? 'scheduled' : 'pending',
            'created_at' => current_time( 'mysql' ),
        ], [ '%d','%s','%s','%s','%s','%s','%s' ] );

        delete_transient( 'smmcare_metrics_user_' . $user );

        return rest_ensure_response( [ 'success' => true, 'message' => 'Campaign saved', 'campaign_id' => (int) $wpdb->insert_id ] );
    }

    public function list_campaigns( WP_REST_Request $request ) {
        global $wpdb;
        $user = get_current_user_id();
        if ( current_user_can( 'manage_options' ) ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_email_campaigns ORDER BY created_at DESC LIMIT 500" );
        } else {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_email_campaigns WHERE customer_id = %d ORDER BY created_at DESC LIMIT 500", $user ) );
        }
        return rest_ensure_response( [ 'success' => true, 'data' => $rows ] );
    }

    public function send_campaign( WP_REST_Request $request ) {
        $id = intval( $request->get_param( 'id' ) );
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_email_campaigns WHERE id = %d", $id ) );
        if ( ! $row ) return rest_ensure_response( [ 'success' => false, 'message' => 'Campaign not found' ], 404 );

        // permission: admins or owner
        if ( ! current_user_can( 'manage_options' ) && $row->customer_id != get_current_user_id() ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Forbidden' ], 403 );
        }

        // recipients: simple comma separated list in list_id for now
        $recipients = array_filter( array_map( 'trim', explode( ',', $row->list_id ) ) );
        if ( empty( $recipients ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'No recipients specified' ], 400 );
        }

        // send using SMMCARE_Email abstraction; queueing is recommended in production
        $sent = 0;
        $email = class_exists( 'SMMCARE_Email' ) ? SMMCARE_Email::instance() : null;
        foreach ( $recipients as $to ) {
            if ( ! is_email( $to ) ) continue;
            $ok = $email ? $email->send_email( $to, $row->subject, $row->body, $row->customer_id ) : wp_mail( $to, $row->subject, $row->body );
            if ( $ok ) $sent++;
        }

        $wpdb->update( $wpdb->prefix . 'smmcare_email_campaigns', [ 'status' => 'sent' ], [ 'id' => $id ], [ '%s' ], [ '%d' ] );
        delete_transient( 'smmcare_metrics_user_' . $row->customer_id );

        return rest_ensure_response( [ 'success' => true, 'sent' => $sent ] );
    }
}

SMMCARE_Campaigns::instance();
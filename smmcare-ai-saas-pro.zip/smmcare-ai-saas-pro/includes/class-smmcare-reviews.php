<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Reviews {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }
    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }
    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/reviews/send', [
            'methods' => 'POST',
            'callback' => [ $this, 'send_invite' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/reviews', [
            'methods' => 'GET',
            'callback' => [ $this, 'list_reviews' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }
    public function send_invite( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $recipient = sanitize_text_field( $params['recipient'] ?? '' );
        $via = sanitize_text_field( $params['via'] ?? 'email' );
        $user = get_current_user_id();
        if ( empty( $recipient ) || ! is_email( $recipient ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Valid recipient required' ], 400 );
        }
        $ai_message = 'Please leave us a review: ' . home_url();
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_reviews';
        $wpdb->insert( $table, [
            'customer_id' => $user,
            'recipient' => $recipient,
            'status' => 'sent',
            'message' => $ai_message,
            'created_at' => current_time( 'mysql' ),
        ], [ '%d','%s','%s','%s','%s' ] );
        if ( $via === 'sms' ) {
            // placeholder for SMS integration
        } else {
            if ( class_exists( 'SMMCARE_Email' ) ) {
                SMMCARE_Email::instance()->send_email( $recipient, 'Please leave us a review', $ai_message, get_current_user_id() );
            } else {
                wp_mail( $recipient, 'Please leave us a review', $ai_message );
            }
        }
        delete_transient( 'smmcare_metrics_user_' . $user );
        return rest_ensure_response( [ 'success' => true, 'message' => 'Invite queued' ] );
    }
    public function list_reviews() {
        global $wpdb;
        $user = get_current_user_id();
        if ( current_user_can( 'manage_options' ) ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_reviews ORDER BY created_at DESC LIMIT 500" );
        } else {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_reviews WHERE customer_id = %d ORDER BY created_at DESC LIMIT 500", $user ) );
        }
        return rest_ensure_response( [ 'success' => true, 'data' => $rows ] );
    }
}
SMMCARE_Reviews::instance();
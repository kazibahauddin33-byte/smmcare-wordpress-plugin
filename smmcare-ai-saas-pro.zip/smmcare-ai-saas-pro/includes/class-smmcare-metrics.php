<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Metrics {
    public static function init() {
        add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
    }

    public static function register_routes() {
        register_rest_route( 'smmcare/v1', '/metrics', array(
            'methods' => 'GET',
            'callback' => array( __CLASS__, 'get_metrics' ),
            'permission_callback' => function() { return is_user_logged_in(); },
        ) );
        register_rest_route( 'smmcare/v1', '/metrics/admin', array(
            'methods' => 'GET',
            'callback' => array( __CLASS__, 'get_metrics_admin' ),
            'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        ) );
    }

    /**
     * Metrics for current customer
     */
    public static function get_metrics( $request ) {
        $user_id = get_current_user_id();
        if ( ! $user_id ) return rest_ensure_response( array( 'success' => false, 'message' => 'Not logged in' ), 403 );

        $transient_key = 'smmcare_metrics_user_' . $user_id;
        $cached = get_transient( $transient_key );
        if ( $cached ) return rest_ensure_response( array( 'success' => true, 'data' => $cached ) );

        global $wpdb;

        // Tasks
        $tasks_open = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_tasks WHERE customer_id = %d AND status != %s", $user_id, 'completed' ) );
        $tasks_completed = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_tasks WHERE customer_id = %d AND status = %s", $user_id, 'completed' ) );

        // Planner
        $planner_scheduled = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_planner_posts WHERE customer_id = %d AND status = %s", $user_id, 'scheduled' ) );
        $planner_published = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_planner_posts WHERE customer_id = %d AND status = %s", $user_id, 'published' ) );

        // Campaigns
        $campaigns_pending = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_email_campaigns WHERE customer_id = %d AND status IN ('pending','scheduled')", $user_id ) );
        $campaigns_sent = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_email_campaigns WHERE customer_id = %d AND status = %s", $user_id, 'sent' ) );

        // Tickets & Reviews
        $tickets_open = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_tickets WHERE customer_id = %d AND status != %s", $user_id, 'closed' ) );
        $reviews_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_reviews WHERE customer_id = %d", $user_id ) );
        $reviews_avg = (float) $wpdb->get_var( $wpdb->prepare( "SELECT AVG(rating) FROM {$wpdb->prefix}smmcare_reviews WHERE customer_id = %d", $user_id ) );
        if ( $reviews_avg === null ) $reviews_avg = 0;

        // Subscriptions
        $plan = get_user_meta( $user_id, 'smmcare_plan', true ) ?: 'starter';
        $subscription = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_subscriptions WHERE customer_id = %d ORDER BY id DESC LIMIT 1", $user_id ), ARRAY_A );

        // Users stats (placeholders)
        $monthly_users = 0;
        $pageviews = 0;
        $new_signups = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_registered >= %s", date( 'Y-m-d H:i:s', strtotime( '-30 days' ) ) ) );

        // AI usage (from ai_logs)
        $ai_tokens = (int) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(tokens_used) FROM {$wpdb->prefix}smmcare_ai_logs WHERE customer_id = %d", $user_id ) );
        $ai_cost = (float) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(cost_usd) FROM {$wpdb->prefix}smmcare_ai_logs WHERE customer_id = %d", $user_id ) );
        if ( $ai_cost === null ) $ai_cost = 0;

        $data = array(
            'pageviews' => $pageviews,
            'monthly_users' => $monthly_users,
            'new_signups' => $new_signups,
            'subscriptions' => array( 'plan' => $plan, 'subscription' => $subscription ),
            'tasks' => array( 'open' => $tasks_open, 'completed' => $tasks_completed ),
            'planner' => array( 'scheduled' => $planner_scheduled, 'published' => $planner_published ),
            'campaigns' => array( 'pending' => $campaigns_pending, 'sent' => $campaigns_sent ),
            'tickets' => array( 'open' => $tickets_open ),
            'reviews' => array( 'avg' => round( (float) $reviews_avg, 2 ), 'count' => $reviews_count ),
            'ai_usage' => array( 'tokens' => $ai_tokens ?: 0, 'cost_usd' => round( (float) $ai_cost, 4 ) ),
            'generated_at' => current_time( 'mysql' ),
        );

        // Cache for 90 seconds
        set_transient( $transient_key, $data, 90 );

        return rest_ensure_response( array( 'success' => true, 'data' => $data ) );
    }

    /**
     * Admin aggregated metrics
     */
    public static function get_metrics_admin( $request ) {
        global $wpdb;
        $cache_key = 'smmcare_metrics_admin';
        $cached = get_transient( $cache_key );
        if ( $cached ) return rest_ensure_response( array( 'success' => true, 'data' => $cached ) );

        $total_customers = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->users} WHERE ID IN (SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'smmcare_plan')" );
        $total_tasks = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_tasks" );
        $total_campaigns = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}smmcare_email_campaigns" );
        $total_ai_tokens = (int) $wpdb->get_var( "SELECT SUM(tokens_used) FROM {$wpdb->prefix}smmcare_ai_logs" );
        $total_ai_cost = (float) $wpdb->get_var( "SELECT SUM(cost_usd) FROM {$wpdb->prefix}smmcare_ai_logs" );
        if ( $total_ai_cost === null ) $total_ai_cost = 0;

        $data = array(
            'total_customers' => $total_customers,
            'total_tasks' => $total_tasks,
            'total_campaigns' => $total_campaigns,
            'ai_usage' => array( 'tokens' => $total_ai_tokens ?: 0, 'cost_usd' => round( (float) $total_ai_cost, 4 ) ),
            'generated_at' => current_time( 'mysql' ),
        );

        set_transient( $cache_key, $data, 60 );

        return rest_ensure_response( array( 'success' => true, 'data' => $data ) );
    }
}

SMMCARE_Metrics::init();
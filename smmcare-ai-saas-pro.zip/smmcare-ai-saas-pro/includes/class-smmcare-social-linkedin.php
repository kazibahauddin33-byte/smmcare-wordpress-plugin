<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Social_Linkedin {
    public static function routes() {
        add_action( 'rest_api_init', function(){
            register_rest_route( 'smmcare/v1', '/social/linkedin/start', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_start'],'permission_callback'=>function(){return current_user_can('manage_options');} ]);
            register_rest_route( 'smmcare/v1', '/social/linkedin/callback', [ 'methods'=>'GET','callback'=>[__CLASS__,'rest_callback'],'permission_callback'=>'__return_true' ]);
            register_rest_route( 'smmcare/v1', '/social/linkedin/post', [ 'methods'=>'POST','callback'=>[__CLASS__,'rest_post'],'permission_callback'=>function(){return is_user_logged_in();} ]);
        } );
    }
    public static function rest_start() { $client_id = get_option('smmcare_li_client_id',''); $redirect = rest_url('smmcare/v1/social/linkedin/callback'); $url = 'https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=' . rawurlencode($client_id) . '&redirect_uri=' . rawurlencode($redirect) . '&scope=' . rawurlencode('r_liteprofile w_member_social'); return rest_ensure_response([ 'success'=>true,'url'=>$url ]); }
    public static function rest_callback( $req ) { return rest_ensure_response([ 'success'=>true,'message'=>'LinkedIn callback (stub)' ] ); }
    public static function rest_post( $req ) { $p = $req->get_json_params(); return rest_ensure_response([ 'success'=>true,'message'=>'linkedin post (demo)' ]); }
}
SMMCARE_Social_Linkedin::routes();
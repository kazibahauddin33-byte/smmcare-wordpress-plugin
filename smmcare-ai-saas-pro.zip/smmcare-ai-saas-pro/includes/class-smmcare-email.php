<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Email {
    private static $instance = null;
    public static function instance() { if ( null === self::$instance ) { self::$instance = new self(); add_action( 'phpmailer_init', [ self::$instance, 'maybe_configure_phpmailer' ] ); } return self::$instance; }

    public function send_email( $to, $subject, $html, $customer_id = 0 ) {
        $smtp = null;
        if ( $customer_id && class_exists('SMMCARE_Customer') ) {
            $cs = SMMCARE_Customer::instance();
            $c = $cs->get_customer_smtp( $customer_id );
            if ( is_array($c) && ! empty($c['host']) ) $smtp = $c;
        }
        if ( ! $smtp && class_exists('SMMCARE_Settings') ) {
            $s = SMMCARE_Settings::instance()->get_smtp_site_credentials();
            if ( is_array($s) && ! empty($s['host']) ) $smtp = $s;
        }
        if ( $smtp ) {
            $override = [
                'host' => $smtp['host'] ?? '',
                'port' => intval( $smtp['port'] ?? 587 ),
                'username' => $smtp['user'] ?? '',
                'password' => $smtp['pass'] ?? '',
                'from_email' => $smtp['from'] ?? get_option( 'admin_email' ),
                'from_name' => $smtp['from_name'] ?? get_bloginfo( 'name' ),
                'encryption' => $smtp['enc'] ?? '',
            ];
            set_transient( 'smmcare_smtp_override', $override, 30 );
        }
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        $ok = wp_mail( $to, $subject, $html, $headers );
        if ( isset( $override ) ) delete_transient( 'smmcare_smtp_override' );
        return $ok;
    }

    public function maybe_configure_phpmailer( $phpmailer ) {
        $override = get_transient( 'smmcare_smtp_override' );
        if ( $override && is_array( $override ) ) {
            $phpmailer->isSMTP();
            $phpmailer->Host = $override['host'];
            $phpmailer->Port = intval( $override['port'] );
            if ( in_array( $override['encryption'], ['ssl','tls'], true ) ) $phpmailer->SMTPSecure = $override['encryption'];
            $phpmailer->SMTPAuth = ! empty( $override['username'] );
            if ( $phpmailer->SMTPAuth ) { $phpmailer->Username = $override['username']; $phpmailer->Password = $override['password']; }
            $phpmailer->From = $override['from_email'] ?? $phpmailer->From;
            $phpmailer->FromName = $override['from_name'] ?? $phpmailer->FromName;
            return;
        }
        if ( class_exists('SMMCARE_Settings') ) {
            $site = SMMCARE_Settings::instance()->get_smtp_site_credentials();
            if ( ! empty( $site['host'] ) ) {
                $phpmailer->isSMTP();
                $phpmailer->Host = $site['host'];
                $phpmailer->Port = intval( $site['port'] ?? 587 );
                if ( ! empty( $site['enc'] ) && in_array( $site['enc'], ['ssl','tls'], true ) ) $phpmailer->SMTPSecure = $site['enc'];
                $phpmailer->SMTPAuth = ! empty( $site['user'] );
                if ( $phpmailer->SMTPAuth ) { $phpmailer->Username = $site['user']; $phpmailer->Password = $site['pass']; }
                $phpmailer->From = $site['from'] ?? $phpmailer->From;
                $phpmailer->FromName = get_bloginfo( 'name' );
            }
        }
    }
}
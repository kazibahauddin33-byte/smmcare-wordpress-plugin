<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Subscriptions {
    public static function instance() { static $i=null; if ($i===null) { $i=new self(); add_action('rest_api_init',[$i,'routes']); } return $i; }
    public function routes() { register_rest_route('smmcare/v1','/subscriptions',[ 'methods'=>'GET','callback'=>[ $this,'list' ], 'permission_callback'=>function(){return current_user_can('manage_options');} ]); }
    public function list() { global $wpdb; $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_subscriptions ORDER BY created_at DESC", ARRAY_A ); return rest_ensure_response([ 'success'=>true,'data'=>$rows ]); }
    public static function upsert( $customer_id, $stripe_sub_id, $plan_slug, $status, $period_end ) { global $wpdb; $table = $wpdb->prefix.'smmcare_subscriptions'; $exists = $wpdb->get_var( $wpdb->prepare("SELECT id FROM {$table} WHERE stripe_subscription_id=%s LIMIT 1",$stripe_sub_id) ); $data=[ 'customer_id'=>$customer_id,'stripe_subscription_id'=>$stripe_sub_id,'plan_slug'=>$plan_slug,'status'=>$status,'current_period_end'=>$period_end?date('Y-m-d H:i:s',intval($period_end)):null,'created_at'=>current_time('mysql') ]; if ( $exists ) { $wpdb->update($table,$data,['id'=>$exists]); return $exists; } else { $wpdb->insert($table,$data); return (int)$wpdb->insert_id; } }
}
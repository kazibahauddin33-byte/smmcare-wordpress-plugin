<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Lightweight OAuth helper endpoints for third-party integrations.
 * This provides start/callback endpoints that set transients for polling by admin JS.
 * In production you should implement full OAuth flows per provider.
 */
class SMMCARE_OAuth {
    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'routes' ] );
    }

    public static function routes() {
        register_rest_route( 'smmcare/v1', '/oauth/start/(?P<provider>[a-zA-Z0-9_-]+)', [
            'methods' => 'GET',
            'callback' => [ __CLASS__, 'start' ],
            'permission_callback' => function(){ return current_user_can( 'manage_options' ); },
        ] );
        register_rest_route( 'smmcare/v1', '/oauth/callback/(?P<provider>[a-zA-Z0-9_-]+)', [
            'methods' => 'GET,POST',
            'callback' => [ __CLASS__, 'callback' ],
            'permission_callback' => '__return_true',
        ] );
    }

    public static function start( WP_REST_Request $request ) {
        $provider = sanitize_text_field( $request->get_param( 'provider' ) );
        // generate a secret poll key and return the popup URL (callback will set transient)
        $key = wp_generate_password( 24, false );
        $redirect = rest_url( "smmcare/v1/oauth/callback/{$provider}?key={$key}" );
        // In real flow you'd redirect to provider's auth URL; for demo we return callback directly
        $popup = $redirect; // for demo, open callback directly
        // store a pending transient so pollers can check
        set_transient( 'smmcare_oauth_pending_' . $key, 'pending', HOUR_IN_SECONDS );
        return rest_ensure_response( [ 'success' => true, 'popup' => $popup, 'key' => $key ] );
    }

    public static function callback( WP_REST_Request $request ) {
        $provider = sanitize_text_field( $request->get_param( 'provider' ) );
        $key = sanitize_text_field( $request->get_param( 'key' ) );
        if ( empty( $key ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'Missing key' ], 400 );

        // simulate storing credentials (in production you capture code and exchange for tokens)
        $data = [
            'provider' => $provider,
            'token' => wp_generate_password( 40, true, true ),
            'connected_at' => current_time( 'mysql' ),
            'user_id' => get_current_user_id() ?: 0,
        ];
        // persist for admin poll (transient keyed by smmcare_oauth_{key})
        set_transient( 'smmcare_oauth_' . $key, $data, 300 );
        // if invoked via browser popup, show a simple page
        if ( php_sapi_name() !== 'cli' ) {
            echo '<!doctype html><html><head><meta charset="utf-8"><title>Connected</title></head><body><h3>Connected — You can close this window.</h3><script>setTimeout(function(){ window.close(); }, 1200);</script></body></html>';
            exit;
        }
        return rest_ensure_response( [ 'success' => true, 'data' => $data ] );
    }
}

SMMCARE_OAuth::init();
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_AI {
    private static $instance = null;
    private $openai_key = '';
    public static function instance() { if ( null === self::$instance ) { self::$instance = new self(); self::$instance->openai_key = get_option('smmcare_openai_key',''); add_action( 'rest_api_init', [ self::$instance, 'routes' ] ); } return self::$instance; }
    public function routes() {
        register_rest_route( 'smmcare/v1', '/ai/generate', [ 'methods'=>'POST','callback'=>[ $this, 'generate' ], 'permission_callback'=>function(){ return is_user_logged_in(); } ]);
    }
    public function generate( WP_REST_Request $request ) {
        $p = $request->get_json_params();
        $prompt = sanitize_textarea_field( $p['prompt'] ?? '' );
        $model = sanitize_text_field( $p['model'] ?? 'gpt-3.5-turbo' );
        if ( empty($prompt) ) return rest_ensure_response([ 'success'=>false,'message'=>'prompt required' ],400);
        $cid = SMMCARE_Multitenant::instance()->get_customer_id() ?: 0;
        $approx_tokens = max(1, (int)ceil(strlen($prompt)/4));
        if ( ! SMMCARE_Quotas::check_and_consume( $cid, 'ai_tokens', $approx_tokens ) ) return rest_ensure_response([ 'success'=>false,'message'=>'AI quota exceeded' ],402);
        if ( empty( $this->openai_key ) ) {
            $mock = "Mock AI response: " . substr( $prompt, 0, 300 );
            global $wpdb;
            $wpdb->insert( $wpdb->prefix . 'smmcare_ai_logs', [ 'customer_id'=>$cid, 'endpoint'=>'/ai/generate', 'request_body'=>wp_json_encode($p), 'response_body'=>$mock, 'tokens_used'=>$approx_tokens, 'cost_usd'=>0, 'created_at'=>current_time('mysql') ] );
            return rest_ensure_response([ 'success'=>true, 'data'=>$mock ]);
        }
        $body = [ 'model'=>$model, 'messages'=>[ ['role'=>'system','content'=>'You are SMMCARE assistant.'], ['role'=>'user','content'=>$prompt] ], 'max_tokens'=>max(100,min(1500,$approx_tokens*4)) ];
        $args = [ 'headers'=>[ 'Content-Type'=>'application/json', 'Authorization'=>'Bearer '.$this->openai_key ], 'body'=>wp_json_encode($body), 'timeout'=>45 ];
        $resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', $args );
        if ( is_wp_error($resp) ) return rest_ensure_response([ 'success'=>false,'message'=>$resp->get_error_message() ],500);
        $data = json_decode( wp_remote_retrieve_body($resp), true );
        $text = $data['choices'][0]['message']['content'] ?? '';
        global $wpdb;
        $tokens_used = intval( $data['usage']['total_tokens'] ?? $approx_tokens );
        $wpdb->insert( $wpdb->prefix . 'smmcare_ai_logs', [ 'customer_id'=>$cid, 'endpoint'=>'/ai/generate', 'request_body'=>wp_json_encode($body), 'response_body'=>wp_json_encode($data), 'tokens_used'=>$tokens_used, 'cost_usd'=>0, 'created_at'=>current_time('mysql') ] );
        return rest_ensure_response([ 'success'=>true, 'data'=>trim( $text ) ]);
    }
}
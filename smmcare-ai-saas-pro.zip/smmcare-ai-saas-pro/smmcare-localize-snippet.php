// Add this immediately after wp_enqueue_script( 'smmcare-customer-frontend', ... );
wp_localize_script( 'smmcare-customer-frontend', 'smmcare', array(
    'rest_root' => esc_url_raw( rest_url( 'smmcare/v1' ) ),
    'nonce'     => wp_create_nonce( 'wp_rest' ),
) );
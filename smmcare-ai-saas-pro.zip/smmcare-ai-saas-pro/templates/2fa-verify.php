<?php if ( ! defined( 'ABSPATH' ) ) exit; get_header(); $uid = intval( $_GET['uid'] ?? 0 ); $token = sanitize_text_field( $_GET['token'] ?? '' ); ?>
<div style="max-width:720px;margin:40px auto;background:#fff;padding:22px;border-radius:12px;">
  <h2>Two-Factor Verification</h2>
  <div id="smmcare-2fa-status"></div>
  <div><label>Method</label><select id="smmcare-2fa-method"><option value="email">Email</option><option value="sms">SMS</option></select><input type="text" id="smmcare-2fa-phone" placeholder="Phone" style="display:none;margin-left:8px" /><button id="smmcare-2fa-request" class="button">Request</button></div>
  <div style="margin-top:12px"><input id="smmcare-2fa-code" placeholder="Code" /><button id="smmcare-2fa-verify" class="button button-primary">Verify</button></div>
</div>
<script>window.smmcare2fa = { uid: <?php echo json_encode($uid); ?>, token: <?php echo json_encode($token); ?> };</script>
<script src="<?php echo esc_url( SMMCARE_URL . 'assets/js/2fa-verify.js' ); ?>"></script>
<?php get_footer(); exit; ?>
<?php if ( ! defined( 'ABSPATH' ) ) exit; get_header(); $cid = SMMCARE_Multitenant::instance()->get_customer_id(); $branding = $cid ? get_option( "smmcare_customer_branding_{$cid}", [] ) : []; ?>
<div class="smmcare-dashboard-wrap">
  <aside class="smmcare-sidebar"><div class="brand"><strong>SMMCARE</strong></div><nav><a href="<?php echo esc_url( home_url('/dashboard') ); ?>">Dashboard</a><a href="<?php echo esc_url( home_url('/crm') ); ?>">CRM</a><a href="<?php echo esc_url( home_url('/campaigns') ); ?>">Campaigns</a></nav></aside>
  <main class="smmcare-content"><h1>Welcome</h1><div id="smmcare-customer-kpis">Loading…</div></main>
</div>
<?php get_footer(); exit; ?>
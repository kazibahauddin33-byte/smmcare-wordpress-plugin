<?php if(!defined('ABSPATH')) exit;
$logo = esc_url(get_option('smmcare_branding_logo', SMMCARE_URL.'assets/img/smmcare-logo.svg'));
$footer = esc_html(get_option('smmcare_footer_text','© SMMCARE LLC'));
get_header(); ?>
<div class="smmcare-app">
  <aside class="smmcare-sidebar">
    <div class="brand"><img src="<?php echo $logo;?>" alt="logo"/><strong style="font-size:16px">SMMCARE</strong></div>
    <nav>
      <a href="<?php echo esc_url(home_url('/dashboard')); ?>">Dashboard</a>
      <a class="active" href="<?php echo esc_url(home_url('/ai-tools')); ?>">AI Tools</a>
    </nav>
  </aside>
  <main class="smmcare-content">
    <div class="card">
      <h3>AI Tools</h3>
      <p>Choose a tool and provide a prompt.</p>
      <div style="display:grid;grid-template-columns:1fr 320px;gap:12px">
        <div>
          <label>Tool</label>
          <select id="smmcare-ai-tool" style="width:100%;padding:8px;border-radius:8px;border:1px solid #e6e9ef">
            <option value="blog">Blog Writer</option>
            <option value="ads">Ad Copy</option>
            <option value="social">Social Post</option>
            <option value="email">Email Campaign</option>
          </select>
          <label style="margin-top:8px">Prompt</label>
          <textarea id="smmcare-ai-prompt" rows="8" style="width:100%;padding:8px;border-radius:8px;border:1px solid #e6e9ef"></textarea>
          <div style="margin-top:8px"><button id="smmcare-ai-run" class="btn">Generate</button></div>
        </div>
        <div>
          <h4>Result</h4>
          <div id="smmcare-ai-result" style="min-height:220px;background:#fff;padding:12px;border-radius:8px;color:#0b2540"></div>
        </div>
      </div>
    </div>
    <footer class="smmcare-footer"><?php echo $footer;?></footer>
  </main>
</div>
<?php get_footer(); exit; ?>
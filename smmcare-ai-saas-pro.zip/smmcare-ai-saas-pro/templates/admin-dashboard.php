<?php if ( ! defined( 'ABSPATH' ) ) exit; get_header(); if ( ! current_user_can('manage_options') ) { wp_safe_redirect( home_url('/') ); exit; } ?>
<div class="smmcare-admin-frontend"><h1>Admin Front Panel</h1><div id="smmcare-admin-kpis"></div><canvas id="smmcare-admin-chart"></canvas></div>
<?php get_footer(); exit; ?>
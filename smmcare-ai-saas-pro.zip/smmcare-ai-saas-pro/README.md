```text
SMMCARE AI SaaS Pro — Full multi-tenant plugin
Version: 1.0.0

Quick install:
1) Upload folder 'smmcare-ai-saas-pro' into wp-content/plugins/
2) Activate plugin from WP Admin -> Plugins.
3) Visit Settings -> Permalinks and Save (flush rewrite rules).
4) Admin: WP Admin -> SMMCARE Pro (manage customers, impersonate, respond to tickets).
5) Customer pages:
   - /dashboard
   - /ai-tools
   - /crm
   - /campaigns
   - /billing
6) Configure:
   - Stripe keys: set via WP Options (smmcare_stripe_secret, smmcare_stripe_webhook_secret) or via admin UI (future).
   - OpenAI key: smmcare_openai_key option.

Security:
- Do not commit secrets to the repo.
- Use server-side environment variables for production secrets.
- Ensure DB backups before activating on production.

Notes:
- Per-customer branding stored as option smmcare_customer_branding_{customer_id}.
- Admin impersonation creates a short-lived transient; admins can generate impersonation links via admin UI.
- The plugin creates all required tables on activation via dbDelta.
```
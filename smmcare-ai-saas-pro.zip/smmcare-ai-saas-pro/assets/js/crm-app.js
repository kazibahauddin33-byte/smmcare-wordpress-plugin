// Minimal CRM admin interactions (list leads, search)
jQuery(function($){
  var root = '/wp-json/smmcare/v1';
  var nonce = (typeof smmcareCRM !== 'undefined' && smmcareCRM.nonce) ? smmcareCRM.nonce : '';
  function loadLeads() {
    fetch(root + '/crm/leads', { credentials:'same-origin', headers:{ 'X-WP-Nonce': nonce } })
      .then(r=>r.json()).then(function(d){
        if ( d && d.success ) {
          var html = '<table class="smmcare-table"><thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Actions</th></tr></thead><tbody>';
          d.data.forEach(function(l){
            html += '<tr><td>' + (l.name||'—') + '</td><td>' + (l.email||'—') + '</td><td>' + (l.phone||'—') + '</td><td><button class="button smmcare-open-lead" data-id="'+l.id+'">Open</button></td></tr>';
          });
          html += '</tbody></table>';
          $('#smmcare-crm-list').html(html);
        }
      });
  }
  $(document).on('click', '#smmcare-crm-search-btn', function(){ loadLeads(); });
  $(document).on('click', '.smmcare-open-lead', function(){
    var id = $(this).data('id');
    // open modal with lead details (left as exercise)
    alert('Open lead ' + id);
  });
  $(document).ready(function(){ loadLeads(); });
});
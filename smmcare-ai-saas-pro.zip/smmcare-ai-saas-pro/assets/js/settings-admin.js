// Settings admin JS: loads/saves settings via REST and supports Twilio test SMS.
// Uses localized smmcareSettings.rest_root and smmcareSettings.nonce
jQuery(function($){
  var root = (typeof smmcareSettings !== 'undefined' && smmcareSettings.rest_root) ? smmcareSettings.rest_root : '/wp-json/smmcare/v1';
  var nonce = (typeof smmcareSettings !== 'undefined' && smmcareSettings.nonce) ? smmcareSettings.nonce : '';

  function loadSettings(){
    fetch(root + '/settings', { credentials:'same-origin', headers:{ 'X-WP-Nonce': nonce } })
      .then(function(r){ return r.json(); })
      .then(function(d){
        if ( d && d.success && d.data ) {
          $('#smmcare_stripe_secret').val(d.data.stripe_configured ? '••••' : '');
          $('#smmcare_stripe_webhook_secret').val(d.data.stripe_webhook_configured ? '••••' : '');
          $('#smmcare_openai_key').val(d.data.openai_configured ? '••••' : '');
          $('#smmcare_twilio_sid').val(d.data.twilio_configured ? '••••' : '');
          $('#smmcare_twilio_from').val(d.data.twilio_from || '');
          $('#smmcare_price_starter').val(d.data.stripe_price_starter || '');
          $('#smmcare_price_pro').val(d.data.stripe_price_pro || '');
          $('#smmcare_price_enterprise').val(d.data.stripe_price_enterprise || '');
          $('#smmcare_smtp_host').val(d.data.smtp_configured ? $('#smmcare_smtp_host').val() : '');
          $('#smmcare_smtp_from').val(d.data.smtp_from || '');
          // Social app presence flags can be used to show connection hints
          $('#smmcare_x_client_id').val(d.data.x_app_configured ? $('#smmcare_x_client_id').val() : '');
        }
      }).catch(function(){ console.warn('Failed to load settings'); });
  }

  $('#smmcare-settings-save').on('click', function(e){
    e.preventDefault();
    var payload = {
      stripe_secret: $('#smmcare_stripe_secret').val().trim(),
      stripe_webhook_secret: $('#smmcare_stripe_webhook_secret').val().trim(),
      openai_key: $('#smmcare_openai_key').val().trim(),
      twilio_sid: $('#smmcare_twilio_sid').val().trim(),
      twilio_token: $('#smmcare_twilio_token').val() ? $('#smmcare_twilio_token').val().trim() : '',
      twilio_from: $('#smmcare_twilio_from').val().trim(),
      stripe_price_starter: $('#smmcare_price_starter').val().trim(),
      stripe_price_pro: $('#smmcare_price_pro').val().trim(),
      stripe_price_enterprise: $('#smmcare_price_enterprise').val().trim(),
      smtp_host: $('#smmcare_smtp_host').val().trim(),
      smtp_port: $('#smmcare_smtp_port').val().trim(),
      smtp_user: $('#smmcare_smtp_user').val().trim(),
      smtp_pass: $('#smmcare_smtp_pass').val() ? $('#smmcare_smtp_pass').val().trim() : '',
      smtp_from: $('#smmcare_smtp_from').val().trim(),
      smtp_enc: $('#smmcare_smtp_enc').val(),
      x_client_id: $('#smmcare_x_client_id').val().trim(),
      x_client_secret: $('#smmcare_x_client_secret').val() ? $('#smmcare_x_client_secret').val().trim() : '',
      li_client_id: $('#smmcare_li_client_id').val().trim(),
      li_client_secret: $('#smmcare_li_client_secret').val() ? $('#smmcare_li_client_secret').val().trim() : '',
      fb_app_id: $('#smmcare_fb_app_id').val().trim(),
      fb_app_secret: $('#smmcare_fb_app_secret').val() ? $('#smmcare_fb_app_secret').val().trim() : '',
      gcal_client_id: $('#smmcare_gcal_client_id').val().trim(),
      gcal_client_secret: $('#smmcare_gcal_client_secret').val() ? $('#smmcare_gcal_client_secret').val().trim() : '',
      tiktok_client_id: $('#smmcare_tiktok_client_id').val().trim(),
      tiktok_client_secret: $('#smmcare_tiktok_client_secret').val() ? $('#smmcare_tiktok_client_secret').val().trim() : ''
    };
    fetch(root + '/settings', {
      method:'POST', credentials:'same-origin',
      headers:{ 'Content-Type':'application/json', 'X-WP-Nonce': nonce },
      body: JSON.stringify(payload)
    }).then(r=>r.json()).then(function(d){
      if ( d && d.success ) {
        alert('Settings saved');
        setTimeout(function(){ loadSettings(); }, 600);
      } else {
        alert('Save failed: ' + (d && d.message ? d.message : 'Unknown'));
      }
    }).catch(function(){ alert('Network error saving settings'); });
  });

  $('#smmcare_twilio_test_send').on('click', function(e){
    e.preventDefault();
    var to = $('#smmcare_twilio_test_to').val().trim();
    if (!to) return alert('Enter a recipient phone number');
    var message = prompt('Message to send (test):', 'This is a test from SMMCARE');
    if ( message === null ) return;
    $('#smmcare_twilio_test_result').text('Sending…');
    fetch(root + '/settings/twilio-test', {
      method:'POST', credentials:'same-origin',
      headers:{ 'Content-Type':'application/json', 'X-WP-Nonce': nonce },
      body: JSON.stringify({ to: to, message: message })
    }).then(r=>r.json()).then(function(d){
      if ( d && d.success ) {
        $('#smmcare_twilio_test_result').text('Sent');
      } else {
        $('#smmcare_twilio_test_result').text('Failed: ' + (d && d.message ? d.message : 'Unknown'));
      }
    }).catch(function(){ $('#smmcare_twilio_test_result').text('Network error'); });
  });

  $(document).ready(function(){ loadSettings(); });
});
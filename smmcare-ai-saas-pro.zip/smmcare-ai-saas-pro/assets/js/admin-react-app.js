/**
 * Small React-based admin app (embedded via CDN React & ReactDOM).
 * This is a lightweight single-file React app that mounts into #smmcare-admin-react-root.
 * It uses Chart.js via SmmcareCharts (charts-advanced.js) for chart rendering.
 *
 * The file intentionally avoids build tooling by relying on React/ReactDOM from CDN.
 *
 * Usage: ensure Chart.js, charts-advanced.js, and this file are enqueued on the admin dashboard page.
 */
(function(){
  // Ensure React is present
  if (typeof window.React === 'undefined' || typeof window.ReactDOM === 'undefined') {
    console.warn('React/ReactDOM not loaded. admin-react-app requires React and ReactDOM (CDN or wp_enqueue).');
    return;
  }
  var e = window.React.createElement;
  var useState = window.React.useState;
  var useEffect = window.React.useEffect;

  function KpiCard(props){
    return e('div', { className: 'smmcare-kpi' },
      e('div', { className: 'kpi-label' }, props.title),
      e('div', { className: 'kpi-value' }, props.value),
      props.delta ? e('div', { className: 'kpi-meta' }, e('span', { className: 'kpi-delta' }, props.delta)) : null
    );
  }

  function ChartWrapper({type, data, options, id}){
    var ref = window.React.useRef();
    useEffect(function(){
      if (!ref.current) return;
      var ctx = ref.current.getContext('2d');
      // destroy existing chart instance if any stored
      if (ref._chart) { try { ref._chart.destroy(); } catch(e){} ref._chart = null; }
      if (type === 'line') ref._chart = window.SmmcareCharts.initLineChart(ctx, data.labels, data.datasets, options);
      else if (type === 'pie') ref._chart = window.SmmcareCharts.initPieChart(ctx, data.labels, data.values, options);
      else if (type === 'radar') ref._chart = window.SmmcareCharts.initRadarChart(ctx, data.labels, data.datasets, options);
      return function(){ if (ref._chart) try{ ref._chart.destroy(); }catch(e){} };
    }, [JSON.stringify(data), type]);
    return e('canvas', { id: id || 'smmcare-chart-' + Math.random().toString(36).slice(2,8), ref: ref, style: { width: '100%', height: '240px' } });
  }

  function AdminApp(){
    var [kpis, setKpis] = useState({ customers: 0, tasks: 0, campaigns: 0 });
    var [chartData, setChartData] = useState({
      labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
      datasets: [{ label: 'Active Users', data: [12, 19, 7, 15, 22, 13, 9], borderColor: '#4a9df8', backgroundColor: 'rgba(74,157,248,0.08)' }]
    });
    useEffect(function(){
      // initial fetch - hooks to /smmcare/v1/metrics/admin if present
      fetch('/wp-json/smmcare/v1/metrics/admin', { credentials: 'same-origin' }).then(r=>r.json()).then(function(d){
        if (d && d.success && d.data) {
          setKpis({ customers: d.data.total_customers||0, tasks: d.data.total_tasks||0, campaigns: d.data.total_campaigns||0 });
          // example mapping
          if (d.data.chart && d.data.chart.labels) setChartData(d.data.chart);
        }
      }).catch(function(){});
    }, []);
    return e('div', { className: 'smmcare-admin-react' },
      e('div', { className: 'smmcare-kpis' },
        e(KpiCard, { title: 'Customers', value: kpis.customers }),
        e(KpiCard, { title: 'Open Tasks', value: kpis.tasks }),
        e(KpiCard, { title: 'Campaigns', value: kpis.campaigns })
      ),
      e('div', { className: 'smmcare-chart-card smmcare-card' },
        e('h3', null, 'Weekly Activity'),
        e(ChartWrapper, { type: 'line', data: chartData })
      )
    );
  }

  function mount(){
    var root = document.getElementById('smmcare-admin-react-root');
    if (!root) return;
    window.ReactDOM.render(e(AdminApp), root);
  }

  // wait for DOM ready
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
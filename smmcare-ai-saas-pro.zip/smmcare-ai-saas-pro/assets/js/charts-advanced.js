/**
 * Advanced Chart helpers for SMMCARE (wrappers around Chart.js)
 * Exposes:
 *  - initLineChart(ctx, labels, datasets, options)
 *  - initPieChart(ctx, labels, values, options)
 *  - initRadarChart(ctx, labels, datasets, options)
 *
 * Requires Chart.js to be available as window.Chart
 */
(function(window){
  function ensureChart() {
    if (typeof Chart === 'undefined') {
      console.warn('Chart.js not loaded. Please enqueue Chart.js before charts-advanced.js');
      return false;
    }
    return true;
  }

  function initLineChart(ctx, labels, datasets, options){
    if (!ensureChart()) return null;
    options = options || {};
    return new Chart(ctx, {
      type: 'line',
      data: { labels: labels, datasets: datasets },
      options: Object.assign({
        responsive: true,
        interaction: { mode: 'index', intersect: false },
        stacked: false,
        plugins: { legend: { display: true } },
        scales: {
          x: { display: true },
          y: { display: true, beginAtZero: true }
        }
      }, options)
    });
  }

  function initPieChart(ctx, labels, values, options){
    if (!ensureChart()) return null;
    options = options || {};
    return new Chart(ctx, {
      type: 'pie',
      data: { labels: labels, datasets: [{ data: values, backgroundColor: options.backgroundColor || [
        '#4a9df8','#6b5cff','#ff7a2d','#34d399','#f97316','#60a5fa','#a78bfa'
      ] }]},
      options: Object.assign({ responsive: true, plugins: { legend: { position: 'right' } } }, options)
    });
  }

  function initRadarChart(ctx, labels, datasets, options){
    if (!ensureChart()) return null;
    options = options || {};
    return new Chart(ctx, {
      type: 'radar',
      data: { labels: labels, datasets: datasets },
      options: Object.assign({ responsive: true, elements: { line: { borderWidth: 2 } } }, options)
    });
  }

  window.SmmcareCharts = {
    initLineChart: initLineChart,
    initPieChart: initPieChart,
    initRadarChart: initRadarChart
  };
})(window);
/* Small admin helper to ensure nonce/localization and handle form uploads gracefully */
jQuery(function($){
  // intercept import form to submit via fetch and show progress
  $('#smmcare-crm-import-form').on('submit', function(e){
    e.preventDefault();
    var file = $('#smmcare-crm-import-file')[0].files[0];
    if (!file) return alert('Select CSV file');
    var fd = new FormData();
    fd.append('csv', file);
    fetch( (window.smmcareCRM && window.smmcareCRM.rest_root ? window.smmcareCRM.rest_root : '/wp-json/smmcare/v1') + '/crm/leads/import', {
      method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': window.smmcareCRM ? window.smmcareCRM.nonce : '' }, body: fd
    }).then(r=>r.json()).then(function(d){
      if ( d && d.success ) { alert('Imported ' + d.imported + ' leads'); location.reload(); } else { alert('Import failed: ' + (d.message||'unknown')); }
    }).catch(function(){ alert('Network error'); });
  });
});
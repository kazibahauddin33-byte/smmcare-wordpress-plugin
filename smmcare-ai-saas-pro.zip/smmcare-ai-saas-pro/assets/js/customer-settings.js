jQuery(function($){
  var root = (typeof smmcareCustomer !== 'undefined' && smmcareCustomer.rest_root) ? smmcareCustomer.rest_root : '/wp-json/smmcare/v1';
  var nonce = (typeof smmcareCustomer !== 'undefined' && smmcareCustomer.nonce) ? smmcareCustomer.nonce : '';

  function loadSmtp(){
    fetch(root + '/customer/smtp', { credentials:'same-origin', headers:{ 'X-WP-Nonce': nonce } })
      .then(r=>r.json()).then(function(d){
        if ( d && d.success ) {
          var s = d.data || {};
          $('#smmcare-customer-smtp-host').val(s.host||'');
          $('#smmcare-customer-smtp-port').val(s.port||587);
          $('#smmcare-customer-smtp-user').val(s.user||'');
          $('#smmcare-customer-smtp-from').val(s.from||'');
          $('#smmcare-customer-smtp-enc').val(s.enc||'');
        }
      });
  }

  $('#smmcare-customer-smtp-save').on('click', function(){
    var payload = {
      host: $('#smmcare-customer-smtp-host').val().trim(),
      port: parseInt($('#smmcare-customer-smtp-port').val(),10) || 587,
      user: $('#smmcare-customer-smtp-user').val().trim(),
      pass: $('#smmcare-customer-smtp-pass').val().trim(),
      from: $('#smmcare-customer-smtp-from').val().trim(),
      enc: $('#smmcare-customer-smtp-enc').val()
    };
    $('#smmcare-customer-smtp-status').text('Saving…');
    fetch(root + '/customer/smtp', { method:'POST', credentials:'same-origin', headers:{ 'Content-Type':'application/json','X-WP-Nonce': nonce }, body: JSON.stringify(payload) })
      .then(r=>r.json()).then(function(d){ $('#smmcare-customer-smtp-status').text((d && d.success) ? 'Saved' : 'Save failed'); });
  });

  $('#smmcare-customer-2fa-request').on('click', function(){
    var method = 'email';
    fetch(root + '/2fa/request', { method:'POST', credentials:'same-origin', headers:{ 'Content-Type':'application/json','X-WP-Nonce': nonce }, body: JSON.stringify({ method: method }) })
      .then(r=>r.json()).then(function(d){ $('#smmcare-customer-2fa-status').text((d && d.success) ? 'Code sent' : 'Send failed'); });
  });

  $('#smmcare-customer-2fa-verify').on('click', function(){
    var code = $('#smmcare-customer-2fa-code').val().trim();
    if ( ! code ) return alert('Enter code');
    fetch(root + '/2fa/verify', { method:'POST', credentials:'same-origin', headers:{ 'Content-Type':'application/json','X-WP-Nonce': nonce }, body: JSON.stringify({ code: code, enable: 1 }) })
      .then(r=>r.json()).then(function(d){ $('#smmcare-customer-2fa-status').text((d && d.success) ? '2FA enabled' : 'Verify failed'); });
  });

  $(document).ready(function(){ loadSmtp(); });
});
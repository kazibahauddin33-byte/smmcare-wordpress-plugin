// Small helper to open/close SMMCARE modals.
// Usage:
//   var modal = SmmcareModal.open({ title: 'My Title', html: '<p>..</p>' });
//   modal.close();
var SmmcareModal = (function(){
  function build(html, opts){
    opts = opts || {};
    var $overlay = document.createElement('div');
    $overlay.className = 'smmcare-modal';
    var inner = document.createElement('div');
    inner.className = 'smmcare-modal-inner';
    var header = document.createElement('div');
    header.className = 'smmcare-modal-header';
    var title = document.createElement('div');
    title.innerHTML = opts.title || '';
    var close = document.createElement('button');
    close.className = 'smmcare-modal-close';
    close.innerHTML = '&times;';
    close.onclick = function(){ document.body.removeChild($overlay); };
    header.appendChild(title);
    header.appendChild(close);
    inner.appendChild(header);
    var body = document.createElement('div');
    body.className = 'smmcare-modal-body';
    if ( typeof html === 'string' ) body.innerHTML = html; else body.appendChild(html);
    inner.appendChild(body);
    $overlay.appendChild(inner);
    return $overlay;
  }
  return {
    open: function(opts){
      var node = build(opts.html || '', opts);
      document.body.appendChild(node);
      return { close: function(){ if (node.parentNode) node.parentNode.removeChild(node); } };
    }
  };
})();
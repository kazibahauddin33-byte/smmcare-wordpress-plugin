/* Enhanced customer/admin dashboard small UI improvements
   - Provides quick KPIs, improved layout and hooks for charts.
*/
jQuery(function($){
  var root = '/wp-json/smmcare/v1';
  var nonce = (typeof smmcare !== 'undefined' && smmcare.nonce) ? smmcare.nonce : '';

  function loadQuickKPIs(){
    fetch(root + '/metrics', { credentials:'same-origin', headers:{ 'X-WP-Nonce': nonce } }).then(r=>r.json()).then(function(d){
      if ( d && d.success && d.data ) {
        $('#smmcare-kpi-open-tasks').text( d.data.tasks ? d.data.tasks.open : 0 );
        $('#smmcare-kpi-ai-usage').text( d.data.ai ? (d.data.ai.tokens_used || 0) : 0 );
        $('#smmcare-kpi-sent-sms').text( d.data.sms ? d.data.sms.sent : 0 );
      }
    }).catch(function(){});
  }

  $(document).ready(function(){
    if ( $('#smmcare-kpi-open-tasks').length ) loadQuickKPIs();
    setInterval(loadQuickKPIs, 20000);
  });
});
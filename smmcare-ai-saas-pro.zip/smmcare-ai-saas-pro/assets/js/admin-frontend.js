// Admin frontend helpers (KPIs polling)
jQuery(function($){
  var root = '/wp-json/smmcare/v1';
  function fetchAdminMetrics(){
    fetch(root + '/metrics/admin', { credentials:'same-origin' }).then(r=>r.json()).then(function(d){
      if ( d && d.success && d.data ) {
        $('#smmcare-admin-kpis').html('<div>Total customers: ' + (d.data.total_customers||0) + '</div>');
        if ( typeof Chart !== 'undefined' && document.getElementById('smmcare-admin-chart') ) {
          // render simple chart - plugin should enqueue Chart.js when needed
        }
      }
    }).catch(function(){});
  }
  $(document).ready(function(){ fetchAdminMetrics(); setInterval(fetchAdminMetrics, 15000); });
});
/* Admin JS for sending Google review invites from SMMCARE admin page.
   Requires smmcareAdmin.rest_root and smmcareAdmin.nonce localized on admin page.
*/
jQuery(function($){
  $(document).on('click', '#smmcare-send-google-review', function(e){
    e.preventDefault();
    var to = $('#smmcare-google-review-to').val();
    var msg = $('#smmcare-google-review-message').val();
    if (!to) { alert('Enter a recipient email'); return; }
    var rest = (smmcareAdmin && smmcareAdmin.rest_root) ? smmcareAdmin.rest_root : '/wp-json/smmcare/v1';
    fetch(rest + '/reviews/google/send', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': smmcareAdmin.nonce || '' },
      body: JSON.stringify({ to: to, message: msg })
    }).then(r=>r.json()).then(function(d){
      if (d && d.success) { alert('Invite sent'); } else { alert('Send failed: ' + (d.message || 'Unknown')); }
    }).catch(function(err){ alert('Network error: ' + err.message); });
  });
});
// Lightweight customer dashboard interactions (robust auth + nonce)
jQuery(function($){
  var root = (typeof smmcare !== 'undefined' && smmcare.rest_root) ? smmcare.rest_root : '/wp-json/smmcare/v1';
  var nonce = (typeof smmcare !== 'undefined' && smmcare.nonce) ? smmcare.nonce : '';

  function loadKPIs(){
    var headers = {};
    if ( nonce ) headers['X-WP-Nonce'] = nonce;

    fetch(root + '/metrics', {
      credentials: 'same-origin', // include cookies for same-origin requests
      headers: headers,
      method: 'GET',
      cache: 'no-cache'
    }).then(function(r){
      if ( r.status === 401 || r.status === 403 ) {
        console && console.warn && console.warn('SMMCARE: metrics fetch unauthorized', r.status);
        return r.json().then(function(body){ $('#smmcare-customer-kpis').html('<div class="smmcare-empty">Unauthorized (login required)</div>'); });
      }
      return r.json();
    }).then(function(d){
      if ( d && d.success && d.data ) {
        var tasks_open = d.data.tasks ? d.data.tasks.open : 0;
        var ai_tokens = (d.data.ai_usage && d.data.ai_usage.tokens) ? d.data.ai_usage.tokens : (d.data.ai && d.data.ai.tokens_used ? d.data.ai.tokens_used : 0);
        $('#smmcare-customer-kpis').html('<div>Open tasks: '+ tasks_open +'</div><div>AI usage: '+ ai_tokens +'</div>');
      } else {
        console && console.warn && console.warn('SMMCARE metrics empty or unauthorized', d);
        $('#smmcare-customer-kpis').html('<div class="smmcare-empty">No metrics available.</div>');
      }
    }).catch(function(err){
      console && console.error && console.error('SMMCARE: metrics fetch failed', err);
      $('#smmcare-customer-kpis').html('<div class="smmcare-empty">Load failed</div>');
    });
  }

  $(document).ready(function(){
    loadKPIs();
    setInterval(loadKPIs, 20000);
  });
});
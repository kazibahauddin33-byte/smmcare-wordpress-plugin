// Simple Chart.js initialization for the dashboard canvas #smmcare-tasks-chart
(function(){
  if (typeof Chart === 'undefined') return;
  document.addEventListener('DOMContentLoaded', function(){
    var ctx = document.getElementById('smmcare-tasks-chart');
    if (!ctx) return;
    try {
      if (ctx.tagName !== 'CANVAS') {
        var wrapper = document.getElementById('smmcare-tasks-chart');
        var canvas = document.createElement('canvas');
        canvas.id = 'smmcare-tasks-chart-canvas';
        wrapper.appendChild(canvas);
        ctx = canvas;
      }
      var chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
          datasets: [{
            label: 'Tasks',
            data: [12, 19, 9, 24, 15, 10, 18],
            borderColor: '#0f4aa3',
            backgroundColor: 'rgba(15,74,163,0.08)',
            fill: true,
            tension: 0.4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: { x: { display: true }, y: { display: true } }
        }
      });
    } catch (e) {
      console.error('SMMCARE: dashboard chart init failed', e);
    }
  });
})();
// Very small copy-to-clipboard helper used in admin UIs.
function smmcareCopyToClipboard(text) {
  if (!navigator.clipboard) {
    var ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch(e) { console.warn('copy failed', e); }
    document.body.removeChild(ta);
    return;
  }
  navigator.clipboard.writeText(text).catch(function(err){ console.warn('clipboard write failed', err); });
}
// Frontend JS for 2FA verify page
jQuery(function($){
  var root = '/wp-json/smmcare/v1';
  function showStatus(msg, klass) { $('#smmcare-2fa-status').text(msg).attr('class', klass || ''); }

  $('#smmcare-2fa-method').on('change', function(){
    if ( $(this).val() === 'sms' ) $('#smmcare-2fa-phone').show(); else $('#smmcare-2fa-phone').hide();
  });

  $('#smmcare-2fa-request').on('click', function(){
    var method = $('#smmcare-2fa-method').val();
    var phone = $('#smmcare-2fa-phone').val();
    var body = { method: method };
    if ( method === 'sms' ) body.phone = phone;
    showStatus('Requesting code…');
    fetch(root + '/2fa/request', {
      method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    }).then(r=>r.json()).then(function(d){
      if ( d && d.success ) showStatus('Code sent. Check your ' + method);
      else showStatus('Request failed: ' + (d && d.message ? d.message : 'Unknown'), 'error');
    }).catch(function(){ showStatus('Network error', 'error'); });
  });

  $('#smmcare-2fa-verify').on('click', function(){
    var code = $('#smmcare-2fa-code').val().trim();
    if ( ! code ) return alert('Enter code');
    var token = window.smmcare2fa ? window.smmcare2fa.token || '' : '';
    showStatus('Verifying…');
    fetch(root + '/2fa/verify', {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type':'application/json' },
      body: JSON.stringify({ code: code, token: token })
    }).then(r=>r.json()).then(function(d){
      if ( d && d.success ) {
        showStatus('Verified — redirecting…');
        window.location = '/dashboard';
      } else {
        showStatus('Verify failed: ' + (d && d.message ? d.message : 'Unknown'), 'error');
      }
    }).catch(function(){ showStatus('Network error', 'error'); });
  });
});
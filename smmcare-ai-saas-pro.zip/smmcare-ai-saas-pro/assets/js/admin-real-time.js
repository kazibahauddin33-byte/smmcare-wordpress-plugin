/* Admin real-time analytics - lightweight polling for charts and KPIs.
   Uses /smmcare/v1/metrics/admin to build charts.
*/
(function(){
  var root = '/wp-json/smmcare/v1';
  var adminKpiEl = document.getElementById('smmcare-admin-kpis');
  var chartEl = document.getElementById('smmcare-admin-chart');

  function fetchAdminMetrics(){
    fetch(root + '/metrics/admin', { credentials:'same-origin' }).then(r=>r.json()).then(function(d){
      if ( d && d.success ) renderMetrics(d.data);
    }).catch(function(){ console.warn('Failed metrics'); });
  }

  function renderMetrics(data){
    if ( adminKpiEl ) {
      adminKpiEl.innerHTML = '<div class="card"><strong>Total customers:</strong> ' + (data.total_customers || 0) + '</div><div class="card"><strong>AI tokens used:</strong> ' + (data.ai_usage ? data.ai_usage.tokens : 0) + '</div>';
    }
    if ( chartEl && typeof Chart !== 'undefined' && data ) {
      if ( ! window.smmcareAdminChart ) {
        window.smmcareAdminChart = new Chart(chartEl, { type:'bar', data:{ labels:['Customers','Tasks','Campaigns'], datasets:[{ data:[ data.total_customers||0, data.total_tasks||0, data.total_campaigns||0 ], backgroundColor:['#6b5cff','#4a9df8','#ff7a2d'] }] }, options:{plugins:{legend:{display:false}}} });
      } else {
        window.smmcareAdminChart.data.datasets[0].data = [ data.total_customers||0, data.total_tasks||0, data.total_campaigns||0 ];
        window.smmcareAdminChart.update();
      }
    }
  }

  setInterval(fetchAdminMetrics, 15000);
  document.addEventListener('DOMContentLoaded', fetchAdminMetrics);
})();
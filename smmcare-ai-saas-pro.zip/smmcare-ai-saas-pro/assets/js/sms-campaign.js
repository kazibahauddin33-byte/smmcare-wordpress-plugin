/* Admin UI for bulk SMS campaigns (attach to CRM leads list)
   - select leads -> open bulk SMS modal -> submit recipients -> queue via REST
*/
jQuery(function($){
  var root = '/wp-json/smmcare/v1';
  function openBulkSMSModal(selectedNumbers, campaignId) {
    var html = '<div style="padding:12px"><h3>Bulk SMS</h3><div><textarea id="smmcare_bulk_sms_body" placeholder="Message" style="width:100%;min-height:120px"></textarea></div>';
    html += '<div style="margin-top:8px"><button id="smmcare_bulk_sms_send" class="button button-primary">Queue SMS</button> <button id="smmcare_bulk_sms_cancel" class="button">Cancel</button></div></div>';
    var modal = $('<div class="smmcare-modal"><div class="smmcare-modal-inner">' + html + '</div></div>');
    $('body').append(modal);
    modal.on('click', '#smmcare_bulk_sms_cancel', function(){ modal.remove(); });
    modal.on('click', '#smmcare_bulk_sms_send', function(){
      var body = $('#smmcare_bulk_sms_body').val().trim();
      if (!body) return alert('Enter a message');
      fetch(root + '/sms/campaigns/' + campaignId + '/queue', { method:'POST', credentials:'same-origin', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ recipients: selectedNumbers }) })
      .then(r=>r.json()).then(function(d){ if (d && d.success) { alert('Queued ' + d.queued + ' messages'); modal.remove(); } else alert('Queue failed'); });
    });
  }

  $(document).on('click', '.smmcare-open-bulk-sms', function(){
    var numbers = [];
    $('.smmcare-lead-checkbox:checked').each(function(){ numbers.push($(this).data('phone')); });
    if (numbers.length === 0) return alert('Select leads first');
    var campaignId = prompt('Enter campaign id to queue into (or leave blank to create new):','');
    if (!campaignId) {
      var title = prompt('Campaign title:','Bulk SMS');
      var body = prompt('Message (you can edit later):','');
      fetch(root + '/sms/campaigns', { method:'POST', credentials:'same-origin', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ title: title, body: body, customer_id: 0 }) })
      .then(r=>r.json()).then(function(d){ if (d && d.success) { openBulkSMSModal(numbers, d.campaign_id); } else alert('Create campaign failed'); });
    } else openBulkSMSModal(numbers, campaignId);
  });
});
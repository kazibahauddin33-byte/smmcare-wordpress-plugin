/**
 * Lightweight widgets library for SMMCARE admin & customer dashboards.
 * Provides:
 *  - createKPI(container, {title, value, delta, icon})
 *  - createListCard(container, {title, items})
 *  - updateKPI(el, newValue, delta)
 *
 * No dependencies (vanilla JS). Designed to be used alongside chart-init.js.
 */
(function(window){
  function el(tag, attrs, html){
    var e = document.createElement(tag);
    attrs = attrs || {};
    for (var k in attrs) {
      if (!attrs.hasOwnProperty(k)) continue;
      if (k === 'class') e.className = attrs[k];
      else if (k === 'style') e.style.cssText = attrs[k];
      else e.setAttribute(k, attrs[k]);
    }
    if (html !== undefined) e.innerHTML = html;
    return e;
  }

  function createKPI(container, opts){
    opts = opts || {};
    var wrap = el('div', { class: 'smmcare-kpi' });
    var label = el('div', { class: 'kpi-label' }, opts.title || '');
    var value = el('div', { class: 'kpi-value' }, opts.value == null ? '—' : String(opts.value));
    var meta = el('div', { class: 'kpi-meta' }, opts.delta ? ('<span class="kpi-delta">' + opts.delta + '</span>') : '' );
    if (opts.icon) {
      var ic = el('div', { class: 'kpi-icon' }, opts.icon);
      wrap.appendChild(ic);
    }
    wrap.appendChild(label);
    wrap.appendChild(value);
    wrap.appendChild(meta);
    (typeof container === 'string' ? document.querySelector(container) : container).appendChild(wrap);
    return wrap;
  }

  function updateKPI(el, newValue, delta){
    if (!el) return;
    var v = el.querySelector('.kpi-value');
    if (v) v.textContent = newValue;
    var d = el.querySelector('.kpi-delta');
    if (d) d.textContent = delta || '';
  }

  function createListCard(container, opts){
    opts = opts || {};
    var card = el('div', { class: 'smmcare-card smmcare-card--compact' });
    var title = el('div', { class: 'card-title' }, opts.title || '');
    card.appendChild(title);
    var list = el('div', { class: 'card-list' });
    (opts.items || []).forEach(function(it){
      var row = el('div', { class: 'smmcare-lead-row' });
      var avatar = el('div', { class: 'smmcare-lead-avatar' }, it.avatar || '');
      var meta = el('div', { class: 'lead-meta' }, '<strong>' + (it.name || '—') + '</strong><div class="lead-sub">' + (it.sub || '') + '</div>');
      row.appendChild(avatar); row.appendChild(meta);
      list.appendChild(row);
    });
    card.appendChild(list);
    (typeof container === 'string' ? document.querySelector(container) : container).appendChild(card);
    return card;
  }

  // Expose
  window.SmmcareWidgets = {
    createKPI: createKPI,
    updateKPI: updateKPI,
    createListCard: createListCard
  };
})(window);
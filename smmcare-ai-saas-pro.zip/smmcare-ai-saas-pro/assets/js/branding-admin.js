(function($){
  $(function(){
    var defaults = window.smmcareBranding && window.smmcareBranding.defaults || {};
    $('#smmcare_branding_logo').val(defaults.logo || '');
    if(defaults.logo) $('.branding-preview').attr('src', defaults.logo).show();
    $('#smmcare_upload_branding_logo').on('click', function(e){ e.preventDefault(); var frame = wp.media({ title: 'Select branding logo', multiple: false, library: { type: 'image' }, button: { text: 'Use logo' } }); frame.on('select', function(){ var att = frame.state().get('selection').first().toJSON(); $('#smmcare_branding_logo').val(att.url); $('.branding-preview').attr('src', att.url).show(); }); frame.open(); });
    $('#smmcare_save_branding').on('click', function(e){ e.preventDefault(); var payload = { logo: $('#smmcare_branding_logo').val(), accent_color: $('#smmcare_branding_accent').val(), theme_mode: $('#smmcare_branding_theme').val(), footer_text: $('#smmcare_branding_footer').val() }; fetch(window.smmcareBranding.rest, { method:'POST', credentials:'same-origin', headers:{ 'Content-Type':'application/json', 'X-WP-Nonce': window.smmcareBranding.nonce }, body: JSON.stringify(payload) }).then(r=>r.json()).then(function(d){ if(d && d.success) { $('#smmcare_branding_status').text('Saved'); setTimeout(function(){ location.reload(); }, 700); } else { $('#smmcare_branding_status').text('Save failed'); } }).catch(function(){ $('#smmcare_branding_status').text('Error'); }); });
  });
})(jQuery);
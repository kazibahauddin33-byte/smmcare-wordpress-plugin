// Tiny Chart.js initializer helper
// Requires Chart.js to be enqueued already on the page.
var SmmcareChart = (function(){
  function initBar(ctx, labels, data, opts){
    opts = opts || {};
    return new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: opts.label || '',
          data: data,
          backgroundColor: opts.backgroundColor || '#4a9df8'
        }]
      },
      options: opts.options || { responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false } } }
    });
  }
  return { initBar: initBar };
})();
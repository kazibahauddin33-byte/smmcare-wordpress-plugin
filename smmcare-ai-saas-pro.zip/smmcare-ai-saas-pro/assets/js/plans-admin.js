// Simple admin JS to show plans (used in settings modal)
jQuery(function($){
  var root = '/wp-json/smmcare/v1';
  function loadPlans() {
    fetch(root + '/admin/plans', { credentials:'same-origin' }).then(r=>r.json()).then(d=>{
      if ( d && d.success ) {
        var html = '<table class="smmcare-table"><thead><tr><th>Plan</th><th>Monthly</th><th>Features</th></tr></thead><tbody>';
        d.data.forEach(function(p){
          html += '<tr><td>' + p.name + '</td><td>$' + p.price_usd_month + '</td><td>' + (p.features||[]).join(', ') + '</td></tr>';
        });
        html += '</tbody></table>';
        $('#smmcare-plans-list').html(html);
      }
    });
  }
  $(document).ready(function(){ if ($('#smmcare-plans-list').length) loadPlans(); });
});
<?php
// Example replacement for direct wp_mail() usage.
//
// Before:
//   $headers = ['Content-Type: text/html; charset=UTF-8'];
//   wp_mail( $to, $subject, $message, $headers );
//
// After:
//   // determine customer id when possible (prefer explicit param from context)
$customer_id = defined('SOME_CUSTOMER_ID') ? SOME_CUSTOMER_ID : SMMCARE_Multitenant::instance()->get_customer_id();
// SMMCARE_Email send_email will use customer SMTP if configured, otherwise fallback to site SMTP
SMMCARE_Email::instance()->send_email( $to, $subject, $message, $customer_id );
//
// Notes:
// - If you have custom headers (From, Reply-To), include them in $message HTML or extend SMMCARE_Email::send_email to accept headers.
// - Where $message is plain-text, wrap it in simple HTML or adjust send_email to accept a 'text' param as fallback.
#!/usr/bin/env bash
# Run from repo root to list all occurrences of wp_mail
# Usage: ./scripts/find_wp_mail.sh
set -euo pipefail
echo "Searching for wp_mail occurrences (this may be incomplete if files are large)..."
grep -R --line-number --no-color "wp_mail\s*\(" . || true
echo
echo "To replace, consider calling SMMCARE_Email::instance()->send_email( \$to, \$subject, \$html, \$customer_id );"
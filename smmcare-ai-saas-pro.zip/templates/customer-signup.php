<?php
if(!defined('ABSPATH')) exit;
if(is_user_logged_in()){ wp_safe_redirect(home_url('/dashboard')); exit; }
get_header();
$logo=esc_url(get_option('smmcare_branding_logo',SMMCARE_URL.'assets/img/smmcare-logo.png'));
?>
<div style="padding:40px;display:flex;align-items:center;justify-content:center">
  <div style="max-width:900px;width:100%">
    <div style="display:flex;gap:24px">
      <div style="flex:0 0 420px">
        <div class="smmcare-auth card">
          <div style="text-align:center"><img src="<?php echo $logo;?>" style="height:44px"/><h2>Create your account</h2></div>
          <form id="smmcare-frontend-signup" action="<?php echo esc_url(rest_url('smmcare/v1/auth/signup'));?>">
            <label>Email</label><input id="smmcare_signup_email" name="email" type="email" required/>
            <label>Password</label><input id="smmcare_signup_password" name="password" type="password" required/>
            <div style="margin-top:12px"><button class="btn" type="submit" style="width:100%;">Create account</button></div>
          </form>
          <script>
          (function(){const f=document.getElementById('smmcare-frontend-signup');f.addEventListener('submit',function(e){e.preventDefault();fetch(f.action,{method:'POST',headers:{'Content-Type':'application/json','X-WP-Nonce':smmcare.nonce},credentials:'same-origin',body:JSON.stringify({email:document.getElementById('smmcare_signup_email').value,password:document.getElementById('smmcare_signup_password').value,username:document.getElementById('smmcare_signup_email').value.split('@')[0]})}).then(r=>r.json()).then(d=>{if(d&&d.success){alert('Account created. Sign in.');window.location='<?php echo esc_js(home_url('/customer-login'));?>';}else{alert('Signup failed: '+(d.message||'Try another email'))}}).catch(err=>alert('Signup error: '+err.message));});})();
          </script>
        </div>
      </div>
      <div style="flex:1"><div class="card"><h3>What you get</h3><ul style="color:var(--smmcare-muted)"><li>AI content</li><li>CRM & tasks</li><li>Planner & calendar</li><li>Reviews & reputation</li></ul></div></div>
    </div>
  </div>
</div>
<?php get_footer(); exit; ?>
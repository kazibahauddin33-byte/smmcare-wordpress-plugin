<?php if(!defined('ABSPATH')) exit; $logo = esc_url(get_option('smmcare_branding_logo', SMMCARE_URL.'assets/img/smmcare-logo.png')); $footer = esc_html(get_option('smmcare_footer_text','© SMMCARE LLC')); get_header(); ?>
<div class="smmcare-app">
  <aside class="smmcare-sidebar">
    <div class="brand"><img src="<?php echo $logo;?>" alt="logo"/><strong style="font-size:16px">SMMCARE</strong></div>
    <nav>
      <a class="nav-item" data-slug="dashboard" href="<?php echo esc_url(home_url('/dashboard'));?>">Dashboard</a>
      <a class="nav-item active" data-slug="ai-tools" href="<?php echo esc_url(home_url('/ai-tools'));?>">AI Tools</a>
      <a class="nav-item" data-slug="social-planner" href="<?php echo esc_url(home_url('/social-planner'));?>">Planner</a>
      <a class="nav-item" data-slug="crm" href="<?php echo esc_url(home_url('/crm'));?>">CRM</a>
      <a class="nav-item" data-slug="reviews" href="<?php echo esc_url(home_url('/reviews'));?>">Reviews</a>
    </nav>
  </aside>

  <header class="smmcare-topbar"><div class="left"><button class="smmcare-toggle-sidebar">☰</button><div class="page-title">Email Campaigns</div></div><div class="right"><img class="avatar" src="<?php echo esc_url(get_avatar_url(get_current_user_id())?:$logo);?>"/></div></header>

  <main class="smmcare-content">
    <div class="card">
      <h3>Create Campaign</h3>
      <label>Subject</label>
      <input id="smmcare-campaign-subject" style="width:100%;padding:10px;border-radius:8px;border:1px solid #e6e9ef"/>
      <label style="margin-top:8px">Body (HTML)</label>
      <textarea id="smmcare-campaign-body" rows="8" style="width:100%;padding:10px;border-radius:8px;border:1px solid #e6e9ef"></textarea>
      <label style="margin-top:8px">Recipients (comma-separated emails)</label>
      <input id="smmcare-campaign-list" style="width:100%;padding:10px;border-radius:8px;border:1px solid #e6e9ef"/>
      <label style="margin-top:8px">Schedule (optional)</label>
      <input id="smmcare-campaign-schedule" type="datetime-local" style="width:100%;padding:10px;border-radius:8px;border:1px solid #e6e9ef"/>
      <div style="margin-top:10px">
        <button id="smmcare-campaign-save" class="btn">Save Campaign</button>
        <button id="smmcare-campaign-send-test" class="btn" style="background:#6b7280;border:1px solid #6b7280">Send Test</button>
      </div>
    </div>

    <div class="card" style="margin-top:12px">
      <h3>Your Campaigns</h3>
      <div id="smmcare-campaign-list">Loading…</div>
    </div>

    <footer class="smmcare-footer"><?php echo $footer;?></footer>
  </main>
</div>

<script src="<?php echo esc_url( SMMCARE_URL . 'assets/js/campaigns.min.js' ); ?>"></script>
<?php get_footer(); exit; ?>
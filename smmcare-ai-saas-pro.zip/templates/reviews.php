<?php if(!defined('ABSPATH')) exit; $logo=esc_url(get_option('smmcare_branding_logo',SMMCARE_URL.'assets/img/smmcare-logo.png')); $footer=esc_html(get_option('smmcare_footer_text','© SMMCARE LLC')); get_header(); ?>
<div class="smmcare-app">
  <aside class="smmcare-sidebar"><div class="brand"><img src="<?php echo $logo;?>" alt="logo"/><strong style="font-size:16px">SMMCARE</strong></div>
    <nav><a class="nav-item" data-slug="dashboard" href="<?php echo esc_url(home_url('/dashboard'));?>">Dashboard</a><a class="nav-item" data-slug="ai-tools" href="<?php echo esc_url(home_url('/ai-tools'));?>">AI Tools</a><a class="nav-item" data-slug="social-planner" href="<?php echo esc_url(home_url('/social-planner'));?>">Planner</a><a class="nav-item" data-slug="crm" href="<?php echo esc_url(home_url('/crm'));?>">CRM</a><a class="nav-item active" data-slug="reviews" href="<?php echo esc_url(home_url('/reviews'));?>">Reviews</a></nav></aside>
  <header class="smmcare-topbar"><div class="left"><button class="smmcare-toggle-sidebar">☰</button><div class="page-title">Reviews</div></div><div class="right"><img class="avatar" src="<?php echo esc_url(get_avatar_url(get_current_user_id())?:$logo);?>"/></div></header>
  <main class="smmcare-content">
    <div class="card"><h3>Reputation & Reviews</h3>
      <p style="color:var(--smmcare-muted)">Send review invites and automate follow-ups. Supports Google review links and Trustpilot invites (adapter).</p>
      <form id="smmcare-review-send" style="display:grid;grid-template-columns:1fr 240px;gap:12px">
        <div><label>Recipient Email</label><input id="review_recipient" style="width:100%;padding:8px;border-radius:6px;border:1px solid #e6e9ef"/><label style="margin-top:8px">Message (optional)</label><textarea id="review_message" style="width:100%;padding:8px;border-radius:6px;border:1px solid #e6e9ef;min-height:120px"></textarea></div>
        <div><label>Send via</label><select id="review_via" style="width:100%;padding:8px;border-radius:6px;border:1px solid #e6e9ef"><option value="email">Email</option><option value="sms">SMS</option></select><div style="margin-top:12px"><button class="btn" type="button" id="smmcare-review-send-btn">Send Invite</button></div></div>
      </form>
    </div>
    <footer class="smmcare-footer"><?php echo $footer;?></footer>
  </main>
</div>
<?php get_footer(); exit; ?>
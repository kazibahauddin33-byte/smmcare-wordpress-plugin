<?php if(!defined('ABSPATH')) exit; $logo=esc_url(get_option('smmcare_branding_logo',SMMCARE_URL.'assets/img/smmcare-logo.png')); $footer=esc_html(get_option('smmcare_footer_text','© SMMCARE LLC')); get_header(); ?>
<div class="smmcare-app">
  <aside class="smmcare-sidebar"><div class="brand"><img src="<?php echo $logo;?>" alt="logo"/><strong style="font-size:16px">SMMCARE</strong></div>
    <nav><a class="nav-item" data-slug="dashboard" href="<?php echo esc_url(home_url('/dashboard'));?>">Dashboard</a><a class="nav-item active" data-slug="ai-tools" href="<?php echo esc_url(home_url('/ai-tools'));?>">AI Tools</a><a class="nav-item" data-slug="social-planner" href="<?php echo esc_url(home_url('/social-planner'));?>">Planner</a><a class="nav-item" data-slug="crm" href="<?php echo esc_url(home_url('/crm'));?>">CRM</a></nav></aside>
  <header class="smmcare-topbar"><div class="left"><button class="smmcare-toggle-sidebar">☰</button><div class="page-title">AI Tools</div></div><div class="right"><img class="avatar" src="<?php echo esc_url(get_avatar_url(get_current_user_id())?:$logo);?>"/></div></header>
  <main class="smmcare-content">
    <div class="card"><h3>AI Tools</h3>
      <div style="display:flex;gap:12px;align-items:flex-start">
        <div style="flex:1">
          <label>Tool</label>
          <select id="smmcare-ai-tool" style="width:100%;padding:8px;border-radius:6px;border:1px solid #e6e9ef">
            <option value="blog">Blog</option><option value="ads">Ads</option><option value="social">Social Posts</option><option value="email">Email Drafts</option>
          </select>
          <label style="margin-top:10px">Prompt</label>
          <textarea id="smmcare-ai-prompt" rows="8" style="width:100%;padding:10px;border-radius:6px;border:1px solid #e6e9ef"></textarea>
          <div style="margin-top:10px"><button id="smmcare-ai-run" class="btn">Generate</button></div>
        </div>
        <div style="flex:1">
          <h4>Result</h4>
          <pre id="smmcare-ai-result" style="white-space:pre-wrap;background:#fafafa;padding:12px;border-radius:6px;border:1px solid #eef2f6;min-height:240px"></pre>
        </div>
      </div>
    </div>
    <footer class="smmcare-footer"><?php echo $footer;?></footer>
  </main>
</div>
<script src="<?php echo esc_url( SMMCARE_URL . 'assets/js/ai-tools.min.js' ); ?>"></script>
<?php get_footer(); exit; ?>
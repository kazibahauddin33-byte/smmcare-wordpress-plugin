<?php if(!defined('ABSPATH')) exit; $logo = esc_url(get_option('smmcare_branding_logo', SMMCARE_URL.'assets/img/smmcare-logo.png')); $footer = esc_html(get_option('smmcare_footer_text','© SMMCARE LLC')); get_header(); ?>
<div class="smmcare-app">
  <aside class="smmcare-sidebar">
    <div class="brand"><img src="<?php echo $logo;?>" alt="logo"/><strong style="font-size:16px">SMMCARE</strong></div>
    <nav>
      <a class="nav-item active" data-slug="dashboard" href="<?php echo esc_url(home_url('/dashboard'));?>">Dashboard</a>
      <a class="nav-item" data-slug="ai-tools" href="<?php echo esc_url(home_url('/ai-tools'));?>">AI Tools</a>
      <a class="nav-item" data-slug="social-planner" href="<?php echo esc_url(home_url('/social-planner'));?>">Planner</a>
      <a class="nav-item" data-slug="crm" href="<?php echo esc_url(home_url('/crm'));?>">CRM</a>
      <a class="nav-item" data-slug="reviews" href="<?php echo esc_url(home_url('/reviews'));?>">Reviews</a>
      <a class="nav-item" data-slug="campaigns" href="<?php echo esc_url(home_url('/campaigns'));?>">Campaigns</a>
    </nav>
  </aside>

  <header class="smmcare-topbar">
    <div class="left"><button class="smmcare-toggle-sidebar">☰</button><div class="page-title">Dashboard</div></div>
    <div class="right"><img class="avatar" src="<?php echo esc_url(get_avatar_url(get_current_user_id())?:$logo);?>" /></div>
  </header>

  <main class="smmcare-content">
    <div class="card" style="display:flex;gap:12px">
      <div style="flex:1"><h3>Total leads</h3><div class="stat-box"><div class="num">1,240</div></div></div>
      <div style="flex:1"><h3>Scheduled posts</h3><div class="stat-box"><div class="num">42</div></div></div>
      <div style="flex:2"><h3>Overview</h3><canvas id="smmcare-tasks-chart" style="width:100%;height:120px"></canvas></div>
    </div>
    <div class="card" style="margin-top:12px"><h3>Calendar</h3><div id="smmcare-calendar"></div></div>
    <footer class="smmcare-footer"><?php echo $footer;?></footer>
  </main>
</div>
<?php get_footer(); exit; ?>
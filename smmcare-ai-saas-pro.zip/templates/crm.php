<?php if(!defined('ABSPATH')) exit; $logo = esc_url(get_option('smmcare_branding_logo', SMMCARE_URL.'assets/img/smmcare-logo.png')); $footer = esc_html(get_option('smmcare_footer_text','© SMMCARE LLC')); get_header(); ?>
<div class="smmcare-app">
  <aside class="smmcare-sidebar">
    <div class="brand"><img src="<?php echo $logo;?>" alt="logo"/><strong style="font-size:16px">SMMCARE</strong></div>
    <nav>
      <a class="nav-item" data-slug="dashboard" href="<?php echo esc_url(home_url('/dashboard'));?>">Dashboard</a>
      <a class="nav-item" data-slug="ai-tools" href="<?php echo esc_url(home_url('/ai-tools'));?>">AI Tools</a>
      <a class="nav-item" data-slug="social-planner" href="<?php echo esc_url(home_url('/social-planner'));?>">Planner</a>
      <a class="nav-item active" data-slug="crm" href="<?php echo esc_url(home_url('/crm'));?>">CRM</a>
      <a class="nav-item" data-slug="reviews" href="<?php echo esc_url(home_url('/reviews'));?>">Reviews</a>
    </nav>
  </aside>

  <header class="smmcare-topbar">
    <div class="left"><button class="smmcare-toggle-sidebar">☰</button><div class="page-title">CRM</div></div>
    <div class="right"><img class="avatar" src="<?php echo esc_url(get_avatar_url(get_current_user_id())?:$logo);?>" /></div>
  </header>

  <main class="smmcare-content">
    <div class="card card--header"><div class="title">CRM - Leads & Tasks</div><div class="actions"><button class="btn">+ New Lead</button></div></div>
    <div class="smmcare-crm-grid" style="margin-top:12px">
      <div class="card col-9">
        <h3>Leads</h3>
        <div id="smmcare-crm-list" class="smmcare-leads-list"><div class="smmcare-empty">Loading…</div></div>
      </div>
      <div class="card col-3">
        <h3>Task quick add</h3>
        <form id="smmcare-task-add">
          <label>Title</label>
          <input id="task_title" required style="width:100%;padding:10px;border-radius:8px;border:1px solid #e6e9ef;margin-bottom:10px" />
          <label>Due</label>
          <input id="task_due" type="datetime-local" style="width:100%;padding:10px;border-radius:8px;border:1px solid #e6e9ef;margin-bottom:10px" />
          <div><button class="btn" type="submit" style="background:#ff6b81;border:1px solid #ff6b81;">Add Task</button></div>
        </form>
      </div>
    </div>
    <footer class="smmcare-footer"><?php echo $footer;?></footer>
  </main>
</div>
<script src="<?php echo esc_url( SMMCARE_URL . 'assets/js/crm.min.js' ); ?>"></script>
<?php get_footer(); exit; ?>
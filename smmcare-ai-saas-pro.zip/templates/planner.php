<?php if(!defined('ABSPATH')) exit; $logo=esc_url(get_option('smmcare_branding_logo',SMMCARE_URL.'assets/img/smmcare-logo.png')); $footer=esc_html(get_option('smmcare_footer_text','© SMMCARE LLC')); get_header(); ?>
<div class="smmcare-app">
  <aside class="smmcare-sidebar"><div class="brand"><img src="<?php echo $logo;?>" alt="logo"/><strong style="font-size:16px">SMMCARE</strong></div>
    <nav><a class="nav-item" data-slug="dashboard" href="<?php echo esc_url(home_url('/dashboard'));?>">Dashboard</a><a class="nav-item" data-slug="ai-tools" href="<?php echo esc_url(home_url('/ai-tools'));?>">AI Tools</a><a class="nav-item active" data-slug="social-planner" href="<?php echo esc_url(home_url('/social-planner'));?>">Planner</a></nav></aside>
  <header class="smmcare-topbar"><div class="left"><button class="smmcare-toggle-sidebar">☰</button><div class="page-title">Social Planner</div></div><div class="right"><img class="avatar" src="<?php echo esc_url(get_avatar_url(get_current_user_id())?:$logo);?>"/></div></header>
  <main class="smmcare-content">
    <div class="card"><h3>Planner</h3><div id="smmcare-planner-calendar" style="min-height:420px">Calendar placeholder (FullCalendar will be loaded).</div></div>
    <footer class="smmcare-footer"><?php echo $footer;?></footer>
  </main>
</div>
<?php get_footer(); exit; ?>
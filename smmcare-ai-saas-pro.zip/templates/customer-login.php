<?php
if(!defined('ABSPATH')) exit;
if(is_user_logged_in()){ wp_safe_redirect(home_url('/dashboard')); exit; }
get_header();
$logo=esc_url(get_option('smmcare_branding_logo',SMMCARE_URL.'assets/img/smmcare-logo.png'));
?>
<div style="min-height:70vh;display:flex;align-items:center;justify-content:center;padding:36px">
  <div style="max-width:980px;width:100%;display:flex;gap:28px">
    <div style="flex:0 0 360px">
      <div class="smmcare-auth card">
        <div style="text-align:center"><img src="<?php echo $logo;?>" style="height:44px"/><h2 style="margin:8px 0 0">Sign in to SMMCARE</h2></div>
        <form id="smmcare-frontend-login" action="<?php echo esc_url(rest_url('smmcare/v1/auth/login'));?>">
          <label>Email or Username</label><input id="smmcare_login_user" name="username" type="text" required/>
          <label>Password</label><input id="smmcare_login_pass" name="password" type="password" required/>
          <div style="margin-top:12px"><button class="btn" type="submit" style="width:100%">Sign in</button></div>
        </form>
        <script>
        (function(){const f=document.getElementById('smmcare-frontend-login');f.addEventListener('submit',function(e){e.preventDefault();fetch(f.action,{method:'POST',headers:{'Content-Type':'application/json','X-WP-Nonce':smmcare.nonce},credentials:'same-origin',body:JSON.stringify({username:document.getElementById('smmcare_login_user').value,password:document.getElementById('smmcare_login_pass').value})}).then(r=>r.json()).then(d=>{if(d&&d.success)window.location='<?php echo esc_js(home_url('/dashboard'));?>';else alert('Login failed: '+(d.message||'Invalid credentials'))}).catch(err=>alert('Login error: '+err.message));});})();
        </script>
      </div>
    </div>
    <div style="flex:1"><div class="card"><h3>Why SMMCARE</h3><p style="color:var(--smmcare-muted)">Unified SaaS for AI copy, email campaigns, CRM & planner.</p></div></div>
  </div>
</div>
<?php get_footer(); exit; ?>
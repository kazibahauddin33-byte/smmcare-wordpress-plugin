jQuery(function($){
  // Test email connection
  $('#smmcare-test-email-btn').on('click', function(e){
    e.preventDefault();
    var to = $('#smmcare-test-email').val();
    if (!to) { alert('Enter a test email'); return; }
    $('#smmcare-test-email-result').text('Testing...');
    $.post(smmcareAdmin.ajax_url, {
      action: 'smmcare_test_email',
      nonce: smmcareAdmin.nonce,
      to: to
    }).done(function(resp){
      if (resp.success) $('#smmcare-test-email-result').css('color','green').text(resp.data);
      else $('#smmcare-test-email-result').css('color','red').text(resp.data || 'Failed');
    }).fail(function(xhr){
      var msg = (xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : 'Error';
      $('#smmcare-test-email-result').css('color','red').text(msg);
    });
  });

  // Impersonate button
  $(document).on('click', '.smmcare-impersonate', function(e){
    e.preventDefault();
    if (!confirm('Impersonate this user? You will be redirected.')) return;
    var user = $(this).data('user');
    $.post(smmcareAdmin.ajax_url, { action: 'smmcare_impersonate', nonce: smmcareAdmin.nonce, user_id: user })
      .done(function(resp){
        if (resp.success && resp.data.url) {
          window.open(resp.data.url, '_blank');
        } else alert('Impersonation failed');
      }).fail(function(){ alert('Request failed'); });
  });

  // Export customer
  $(document).on('click', '.smmcare-export', function(e){
    e.preventDefault();
    var user = $(this).data('user');
    if (!confirm('Export customer data?')) return;
    $.post(smmcareAdmin.ajax_url, { action:'smmcare_export_customer', nonce: smmcareAdmin.nonce, user_id: user })
      .done(function(resp){
        if (resp.success && resp.data.csv) {
          var csv = atob(resp.data.csv);
          var blob = new Blob([csv], { type: 'text/csv' });
          var url = URL.createObjectURL(blob);
          var a = document.createElement('a');
          a.href = url;
          a.download = resp.data.filename || 'export.csv';
          document.body.appendChild(a);
          a.click();
          a.remove();
        } else alert('Export failed');
      }).fail(function(){ alert('Export failed'); });
  });

  // OAuth connect popups (open and poll)
  $('#smmcare-connect-google').on('click', function(e){
    e.preventDefault();
    var w = window.open(smmcareAdmin.rest_root + 'oauth/start/google', 'smmcare_oauth', 'width=900,height=700');
    this._oauth_poll_key = Math.random().toString(36).slice(2);
    var that = this;
    var poll = setInterval(function(){
      $.post(smmcareAdmin.ajax_url, { action:'smmcare_oauth_poll', nonce: smmcareAdmin.nonce, key: that._oauth_poll_key })
        .done(function(resp){
          if (resp.success) {
            clearInterval(poll);
            alert('Google connected successfully.');
            location.reload();
          }
        }).fail(function(xhr){
          // continue polling until server responds with success
        });
    }, 1500);
  });

  $('#smmcare-connect-ms').on('click', function(e){
    e.preventDefault();
    window.open(smmcareAdmin.rest_root + 'oauth/start/microsoft', 'smmcare_oauth', 'width=900,height=700');
    // polling as above (omitted for brevity in demo)
  });

});
<?php
// (only the function below — replace existing smmcare_enqueue_assets() in your loader)

function smmcare_enqueue_assets() {
    if ( is_admin() ) return;

    // Core plugin styles & layout
    if ( file_exists( SMMCARE_DIR . 'assets/css/style.min.css' ) ) {
        wp_enqueue_style( 'smmcare-style', SMMCARE_URL . 'assets/css/style.min.css', [], SMMCARE_VERSION );
    }

    // FullCalendar (CSS + JS) - CDN
    wp_enqueue_style( 'fullcalendar-core-css', 'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.css', [], '6.1.8' );
    wp_enqueue_script( 'fullcalendar-js', 'https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.global.min.js', [], '6.1.8', true );

    // Chart.js (CDN)
    wp_enqueue_script( 'chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.3.0/dist/chart.umd.min.js', [], '4.3.0', true );

    // Plugin front-end scripts (depend on FullCalendar & Chart.js)
    if ( file_exists( SMMCARE_DIR . 'assets/js/app-layout.min.js' ) ) {
        wp_enqueue_script( 'smmcare-app', SMMCARE_URL . 'assets/js/app-layout.min.js', [ 'jquery' ], SMMCARE_VERSION, true );
    }
    if ( file_exists( SMMCARE_DIR . 'assets/js/planner-calendar.min.js' ) ) {
        wp_enqueue_script( 'smmcare-planner', SMMCARE_URL . 'assets/js/planner-calendar.min.js', [ 'fullcalendar-js', 'smmcare-app' ], SMMCARE_VERSION, true );
    }
    if ( file_exists( SMMCARE_DIR . 'assets/js/dashboard-init.js' ) ) {
        wp_enqueue_script( 'smmcare-dashboard', SMMCARE_URL . 'assets/js/dashboard-init.js', [ 'chartjs', 'smmcare-app' ], SMMCARE_VERSION, true );
    }

    // Localize common data
    wp_localize_script( 'smmcare-app', 'smmcare', [
        'rest_url' => esc_url_raw( rest_url( 'smmcare/v1' ) ),
        'nonce'    => wp_create_nonce( 'wp_rest' ),
        'logo'     => esc_url( smmcare_get_branding_logo_url() ),
        'footer'   => wp_kses_post( get_option( 'smmcare_footer_text', '© SMMCARE LLC' ) ),
    ] );
}
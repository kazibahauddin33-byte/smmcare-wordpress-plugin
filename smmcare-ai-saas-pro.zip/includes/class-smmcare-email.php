<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_Email
 * - Per-customer provider settings saved encrypted with SMMCARE_SECRET_KEY
 * - Supports: SMTP (phpmailer_init), API adapters (Brevo/SendGrid) - basic
 * - IMAP polling for inbound replies is implemented elsewhere (cron)
 */
class SMMCARE_Email {
    private static $instance = null;
    private $secret_key;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->secret_key = defined('SMMCARE_SECRET_KEY') ? SMMCARE_SECRET_KEY : '';
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        // phpmailer hook for per-send SMTP overrides
        add_action( 'phpmailer_init', [ $this, 'maybe_configure_phpmailer' ], 10, 1 );
    }

    /**
     * Encryption helpers (AES-256-CBC using SMMCARE_SECRET_KEY)
     */
    public function encrypt( $plaintext ) {
        if ( empty( $this->secret_key ) ) return $plaintext; // fallback (not encrypted)
        $key = hash( 'sha256', $this->secret_key, true );
        $iv = openssl_random_pseudo_bytes( 16 );
        $cipher = openssl_encrypt( $plaintext, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
        return base64_encode( $iv . $cipher );
    }

    public function decrypt( $ciphertext_b64 ) {
        if ( empty( $this->secret_key ) ) return $ciphertext_b64;
        $raw = base64_decode( $ciphertext_b64 );
        if ( strlen( $raw ) < 16 ) return '';
        $iv = substr( $raw, 0, 16 );
        $cipher = substr( $raw, 16 );
        $key = hash( 'sha256', $this->secret_key, true );
        $plain = openssl_decrypt( $cipher, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
        return $plain === false ? '' : $plain;
    }

    /**
     * Save provider settings for customer_id (encrypted)
     */
    public function save_provider_settings( $customer_id, $settings ) {
        if ( ! $customer_id || ! is_array( $settings ) ) return false;
        $enc = $settings;
        if ( isset( $enc['password'] ) && $enc['password'] ) $enc['password'] = $this->encrypt( $enc['password'] );
        if ( isset( $enc['api_key'] ) && $enc['api_key'] ) $enc['api_key'] = $this->encrypt( $enc['api_key'] );
        update_user_meta( $customer_id, 'smmcare_email_provider', $enc );
        return true;
    }

    public function get_provider_settings( $customer_id ) {
        $raw = get_user_meta( $customer_id, 'smmcare_email_provider', true );
        if ( ! is_array( $raw ) ) return [];
        if ( isset( $raw['password'] ) && $raw['password'] ) $raw['password'] = $this->decrypt( $raw['password'] );
        if ( isset( $raw['api_key'] ) && $raw['api_key'] ) $raw['api_key'] = $this->decrypt( $raw['api_key'] );
        return $raw;
    }

    /**
     * Send email with provider selection:
     * priority: campaign provider -> customer provider -> site default
     */
    public function send_email( $to, $subject, $body, $customer_id = 0, $provider_override = null ) {
        // determine provider
        $provider = null;
        if ( $provider_override ) {
            $provider = $provider_override;
        } elseif ( $customer_id ) {
            $p = $this->get_provider_settings( $customer_id );
            if ( ! empty( $p ) ) $provider = $p;
        }
        if ( empty( $provider ) ) {
            $provider = get_option( 'smmcare_email_site_default', [] );
            if ( isset( $provider['password'] ) ) $provider['password'] = $this->decrypt( $provider['password'] );
            if ( isset( $provider['api_key'] ) ) $provider['api_key'] = $this->decrypt( $provider['api_key'] );
        }

        // If provider type is smtp: use wp_mail + phpmailer hook (set transient for send)
        if ( is_array( $provider ) && ( $provider['type'] ?? '' ) === 'smtp' ) {
            set_transient( 'smmcare_smtp_override', $provider, 30 );
            add_filter( 'wp_mail_from', function() use ( $provider ) { return $provider['from_email'] ?? get_option('admin_email'); } );
            add_filter( 'wp_mail_from_name', function() use ( $provider ) { return $provider['from_name'] ?? get_bloginfo('name'); } );
            $sent = wp_mail( $to, $subject, $body );
            delete_transient( 'smmcare_smtp_override' );
            return $sent;
        }

        // API providers (basic Brevo example)
        if ( is_array( $provider ) && ($provider['type'] ?? '') === 'brevo' ) {
            $api_key = $provider['api_key'] ?? '';
            if ( empty( $api_key ) ) return false;
            $args = [
                'headers' => [ 'Accept' => 'application/json', 'Content-Type' => 'application/json', 'api-key' => $api_key ],
                'body' => wp_json_encode( [
                    'sender' => [ 'name' => $provider['from_name'] ?? get_bloginfo('name'), 'email' => $provider['from_email'] ?? get_option('admin_email') ],
                    'to'     => [ [ 'email' => $to ] ],
                    'subject'=> $subject,
                    'htmlContent' => $body,
                ] ),
                'timeout' => 20,
            ];
            $r = wp_remote_post( 'https://api.brevo.com/v3/smtp/email', $args );
            if ( is_wp_error( $r ) ) return false;
            $code = wp_remote_retrieve_response_code( $r );
            return $code >= 200 && $code < 300;
        }

        // fallback to wp_mail server default
        return wp_mail( $to, $subject, $body );
    }

    /**
     * phpmailer_init hook: apply transient smtp override if present
     */
    public function maybe_configure_phpmailer( $phpmailer ) {
        $override = get_transient( 'smmcare_smtp_override' );
        if ( ! $override || ! is_array( $override ) ) return;
        // apply smtp settings
        $phpmailer->isSMTP();
        $phpmailer->Host = $override['host'] ?? 'localhost';
        $phpmailer->Port = intval( $override['port'] ?? 587 );
        $secure = $override['encryption'] ?? '';
        if ( $secure === 'ssl' ) $phpmailer->SMTPSecure = 'ssl';
        if ( $secure === 'tls' ) $phpmailer->SMTPSecure = 'tls';
        $phpmailer->SMTPAuth = ! empty( $override['username'] );
        if ( $phpmailer->SMTPAuth ) {
            $phpmailer->Username = $override['username'];
            $phpmailer->Password = $override['password'];
        }
        $phpmailer->From = $override['from_email'] ?? $phpmailer->From;
        $phpmailer->FromName = $override['from_name'] ?? $phpmailer->FromName;
    }
}
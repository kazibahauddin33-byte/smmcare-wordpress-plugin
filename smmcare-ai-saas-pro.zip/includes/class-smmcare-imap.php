<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_IMAP
 * - Polls configured IMAP mailboxes and ingests replies as tickets (poll via cron)
 * - Uses get_user_meta( $user_id, 'smmcare_email_provider', true ) for per-customer IMAP config
 * - If IMAP PHP extension is not available, logs a notice
 */
class SMMCARE_IMAP {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'smmcare_imap_poll', [ $this, 'poll_all_mailboxes' ] );
        // ensure scheduled event exists (activation in main loader already adds five_min_cron)
    }

    /**
     * Poll all configured mailboxes (site-level and per-customer)
     */
    public function poll_all_mailboxes() {
        if ( ! function_exists( 'imap_open' ) ) {
            error_log( 'SMMCARE: imap extension not available; cannot poll mailboxes.' );
            return;
        }

        // 1) site default mailbox (option)
        $site = get_option( 'smmcare_email_site_default', [] );
        if ( ! empty( $site ) && ( $site['type'] ?? '' ) === 'imap' ) {
            $this->poll_mailbox( 0, $site );
        }

        // 2) per-customer mailboxes
        $users = get_users( [ 'role' => 'smmcare_customer', 'number' => 200 ] );
        foreach ( $users as $u ) {
            $cfg = get_user_meta( $u->ID, 'smmcare_email_provider', true );
            if ( ! empty( $cfg ) && ( $cfg['type'] ?? '' ) === 'imap' ) {
                $this->poll_mailbox( $u->ID, $cfg );
            }
        }
    }

    /**
     * Poll single mailbox and create tickets for new messages
     */
    private function poll_mailbox( $customer_id, $cfg ) {
        $host = $cfg['host'] ?? '';
        $port = intval( $cfg['port'] ?? 993 );
        $secure = $cfg['encryption'] ?? 'ssl';
        $user = $cfg['username'] ?? '';
        $password = $cfg['password'] ?? '';

        // decrypt if necessary
        if ( class_exists( 'SMMCARE_Email' ) ) {
            $email = SMMCARE_Email::instance();
            if ( ! empty( $cfg['password'] ) ) {
                // password may be stored encrypted — try decrypt
                $decrypted = $email->decrypt( $cfg['password'] );
                if ( ! empty( $decrypted ) ) $password = $decrypted;
            }
        }

        if ( empty( $host ) || empty( $user ) || empty( $password ) ) {
            return;
        }

        $flags = '/imap/novalidate-cert';
        if ( $secure === 'ssl' ) $flags = '/imap/ssl/novalidate-cert';
        if ( $secure === 'tls' ) $flags = '/imap/tls/novalidate-cert';

        $mailbox = "{" . $host . ":" . $port . $flags . "}INBOX";
        $stream = @imap_open( $mailbox, $user, $password );
        if ( ! $stream ) {
            error_log( 'SMMCARE: IMAP open failed for ' . $host . ' - ' . imap_last_error() );
            return;
        }

        // search for unseen messages
        $msgs = imap_search( $stream, 'UNSEEN' );
        if ( empty( $msgs ) ) {
            imap_close( $stream );
            return;
        }

        foreach ( $msgs as $msgnum ) {
            $header = imap_headerinfo( $stream, $msgnum );
            $body_struct = imap_fetchstructure( $stream, $msgnum );
            $body = $this->fetch_body( $stream, $msgnum, $body_struct );

            // basic parsing: use subject as ticket title and body as reply
            $subject = isset( $header->subject ) ? imap_mime_header_decode( $header->subject )[0]->text : 'No subject';
            $from = ( isset( $header->from[0]->mailbox ) && isset( $header->from[0]->host ) ) ? $header->from[0]->mailbox . '@' . $header->from[0]->host : '';
            $message = trim( strip_tags( $body ) );

            // create ticket (attach as new reply or create new ticket)
            if ( class_exists( 'SMMCARE_Tickets' ) ) {
                global $wpdb;
                // naive: always create a new ticket for incoming messages (can be improved by matching In-Reply-To)
                $table = $wpdb->prefix . 'smmcare_tickets';
                $wpdb->insert( $table, [
                    'customer_id' => $customer_id ?: 0,
                    'title' => wp_trim_words( $subject, 12, '...' ),
                    'message' => $message,
                    'status' => 'open',
                    'created_at' => current_time( 'mysql' ),
                ], [ '%d','%s','%s','%s','%s' ] );
            }

            // mark as seen
            imap_setflag_full( $stream, $msgnum, "\\Seen" );
        }

        imap_close( $stream );
    }

    /**
     * Fetch textual body from part structure
     */
    private function fetch_body( $stream, $msgnum, $structure ) {
        if ( ! $structure ) return '';
        $parts = $structure->parts ?? null;
        if ( ! $parts ) {
            $text = imap_body( $stream, $msgnum );
            return $text;
        }
        // loop and find text/plain or text/html
        $body = '';
        foreach ( $parts as $i => $part ) {
            $section = $i + 1;
            if ( $part->type == 0 ) {
                $t = imap_fetchbody( $stream, $msgnum, $section );
                if ( $part->encoding == 3 ) $t = base64_decode( $t );
                if ( $part->encoding == 4 ) $t = quoted_printable_decode( $t );
                if ( stripos( $part->subtype, 'PLAIN' ) !== false || stripos( $part->subtype, 'HTML' ) === false ) {
                    $body .= $t;
                }
            }
        }
        return $body;
    }
}

SMMCARE_IMAP::instance();
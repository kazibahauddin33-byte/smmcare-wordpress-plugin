<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Tickets {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }
    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }
    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/tickets', [
            'methods' => 'POST',
            'callback' => [ $this, 'create_ticket' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/tickets', [
            'methods' => 'GET',
            'callback' => [ $this, 'list_tickets' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/tickets/(?P<id>\d+)', [
            'methods' => [ 'POST','PUT' ],
            'callback' => [ $this, 'update_ticket' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }

    public function create_ticket( WP_REST_Request $request ) {
        $p = $request->get_json_params();
        $title = sanitize_text_field( $p['title'] ?? '' );
        $message = sanitize_textarea_field( $p['message'] ?? '' );
        $user = get_current_user_id();
        if ( empty( $title ) || empty( $message ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'Title and message required' ], 400 );
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_tickets';
        $wpdb->insert( $table, [
            'customer_id' => $user,
            'title' => $title,
            'message' => $message,
            'status' => 'open',
            'created_at' => current_time( 'mysql' ),
        ], [ '%d','%s','%s','%s','%s' ] );
        return rest_ensure_response( [ 'success' => true, 'message' => 'Ticket created' ] );
    }

    public function list_tickets() {
        global $wpdb;
        $user = get_current_user_id();
        if ( current_user_can( 'manage_options' ) ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_tickets ORDER BY created_at DESC LIMIT 500" );
        } else {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_tickets WHERE customer_id = %d ORDER BY created_at DESC LIMIT 500", $user ) );
        }
        return rest_ensure_response( [ 'success' => true, 'data' => $rows ] );
    }

    public function update_ticket( WP_REST_Request $request ) {
        $id = intval( $request->get_param( 'id' ) );
        $p = $request->get_json_params();
        $status = sanitize_text_field( $p['status'] ?? '' );
        $reply = isset( $p['reply'] ) ? sanitize_textarea_field( $p['reply'] ) : '';
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_tickets';
        $ticket = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
        if ( ! $ticket ) return rest_ensure_response( [ 'success' => false, 'message' => 'Ticket not found' ], 404 );
        if ( ! current_user_can( 'manage_options' ) && $ticket->customer_id != get_current_user_id() ) return rest_ensure_response( [ 'success' => false, 'message' => 'Forbidden' ], 403 );
        if ( $status ) $wpdb->update( $table, [ 'status' => $status ], [ 'id' => $id ], [ '%s' ], [ '%d' ] );
        if ( $reply ) {
            $reply_table = $wpdb->prefix . 'smmcare_ticket_replies';
            $wpdb->insert( $reply_table, [
                'ticket_id' => $id,
                'user_id'   => get_current_user_id(),
                'message'   => $reply,
                'created_at'=> current_time( 'mysql' ),
            ], [ '%d','%d','%s','%s' ] );
        }
        return rest_ensure_response( [ 'success' => true, 'message' => 'Updated' ] );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_Impersonate
 * - On init checks for GET param smmcare_impersonate and logs in the user associated with transient smmcare_impersonate_{key}
 * - Intended to be used only for admin-created one-time impersonation links
 */
class SMMCARE_Impersonate {
    public static function init() {
        add_action( 'init', [ __CLASS__, 'maybe_impersonate' ], 5 );
    }

    public static function maybe_impersonate() {
        if ( empty( $_GET['smmcare_impersonate'] ) ) {
            return;
        }
        $secret = sanitize_text_field( wp_unslash( $_GET['smmcare_impersonate'] ) );
        $user_id = get_transient( 'smmcare_impersonate_' . $secret );
        if ( ! $user_id ) {
            wp_die( 'Impersonation token invalid or expired.' );
        }

        // Only allow if current user is admin OR token exists (token created by an admin earlier)
        // For security we do not require a logged-in admin here because the admin created a one-time link.
        $user = get_user_by( 'id', intval( $user_id ) );
        if ( ! $user ) {
            wp_die( 'User not found.' );
        }

        // Log in as the target user
        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID );
        // remove the transient to prevent reuse
        delete_transient( 'smmcare_impersonate_' . $secret );

        // redirect to dashboard
        wp_safe_redirect( home_url( '/dashboard' ) );
        exit;
    }
}

SMMCARE_Impersonate::init();
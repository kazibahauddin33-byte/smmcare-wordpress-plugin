<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Planner {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }
    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }
    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/planner', [
            'methods' => 'POST',
            'callback' => [ $this, 'create_post' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/planner', [
            'methods' => 'GET',
            'callback' => [ $this, 'list_posts' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }
    public function create_post( WP_REST_Request $request ) {
        $p = $request->get_json_params();
        $content = sanitize_textarea_field( $p['content'] ?? '' );
        $date = sanitize_text_field( $p['date'] ?? '' );
        $network = sanitize_text_field( $p['network'] ?? 'facebook' );
        $user = get_current_user_id();
        if ( empty( $content ) || empty( $date ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Content and date required' ], 400 );
        }
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_planner_posts';
        $wpdb->insert( $table, [
            'customer_id' => $user,
            'content' => $content,
            'network' => $network,
            'scheduled_for' => date( 'Y-m-d H:i:s', strtotime( $date ) ),
            'status' => 'scheduled',
            'created_at' => current_time( 'mysql' ),
        ], [ '%d','%s','%s','%s','%s','%s' ] );
        return rest_ensure_response( [ 'success' => true, 'message' => 'Scheduled' ] );
    }
    public function list_posts() {
        global $wpdb;
        $user = get_current_user_id();
        if ( current_user_can( 'manage_options' ) ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_planner_posts ORDER BY scheduled_for DESC LIMIT 500" );
        } else {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_planner_posts WHERE customer_id = %d ORDER BY scheduled_for DESC LIMIT 500", $user ) );
        }
        return rest_ensure_response( [ 'success' => true, 'data' => $rows ] );
    }
    public static function publish_pending_posts() {
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_planner_posts';
        $now = current_time( 'mysql' );
        $posts = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status = 'scheduled' AND scheduled_for <= %s LIMIT 50", $now ) );
        if ( empty( $posts ) ) return;
        foreach ( $posts as $p ) {
            $wpdb->update( $table, [ 'status' => 'published' ], [ 'id' => $p->id ], [ '%s' ], [ '%d' ] );
            // TODO: add social network publishing via adapters
        }
    }
}
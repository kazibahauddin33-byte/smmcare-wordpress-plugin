<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Admin {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_post_smmcare_save_settings', [ $this, 'handle_save_settings' ] );

        // AJAX actions
        add_action( 'wp_ajax_smmcare_test_email', [ $this, 'ajax_test_email' ] );
        add_action( 'wp_ajax_smmcare_impersonate', [ $this, 'ajax_impersonate_user' ] );
        add_action( 'wp_ajax_smmcare_export_customer', [ $this, 'ajax_export_customer' ] );
        add_action( 'wp_ajax_smmcare_oauth_poll', [ $this, 'ajax_oauth_poll' ] );
    }

    public function add_admin_menu() {
        add_menu_page( 'SMMCARE Pro', 'SMMCARE Pro', 'manage_options', 'smmcare-pro', [ $this, 'settings_page' ], 'dashicons-chart-area', 59 );
    }

    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'smmcare-pro' ) === false && strpos( $hook, 'toplevel_page_smmcare-pro' ) === false ) {
            return;
        }
        wp_enqueue_style( 'smmcare-admin-style', SMMCARE_URL . 'assets/css/admin.css', [], SMMCARE_VERSION );
        wp_enqueue_script( 'smmcare-admin-js', SMMCARE_URL . 'assets/js/admin-settings.js', [ 'jquery' ], SMMCARE_VERSION, true );
        wp_localize_script( 'smmcare-admin-js', 'smmcareAdmin', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'smmcare_admin' ),
            'rest_root' => esc_url_raw( rest_url( 'smmcare/v1' ) ),
        ] );
    }

    /**
     * Settings page render (tabs)
     */
    public function settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $tab = sanitize_text_field( $_GET['tab'] ?? 'general' );

        // Load current values
        $branding_logo = esc_url( get_option( 'smmcare_branding_logo', SMMCARE_URL . 'assets/img/smmcare-logo.png' ) );
        $footer_text = esc_attr( get_option( 'smmcare_footer_text', '© SMMCARE LLC' ) );
        $stripe_secret = esc_attr( get_option( 'smmcare_stripe_secret', '' ) );
        $stripe_webhook = esc_attr( get_option( 'smmcare_stripe_webhook_secret', '' ) );
        $email_default = get_option( 'smmcare_email_site_default', [] );

        // Check for missing include warnings
        $missing = get_option( 'smmcare_missing_includes', [] );

        ?>
        <div class="wrap smmcare-admin-wrap">
            <h1>SMMCARE Pro Settings</h1>

            <?php if ( ! empty( $missing ) ) : ?>
                <div class="notice notice-warning"><p><strong>SMMCARE:</strong> Missing include files - see plugin folder.</p></div>
            <?php endif; ?>

            <h2 class="nav-tab-wrapper">
                <a class="nav-tab <?php echo $tab === 'general' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=smmcare-pro&tab=general' ) ); ?>">General</a>
                <a class="nav-tab <?php echo $tab === 'integrations' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=smmcare-pro&tab=integrations' ) ); ?>">Integrations</a>
                <a class="nav-tab <?php echo $tab === 'email' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=smmcare-pro&tab=email' ) ); ?>">Email</a>
                <a class="nav-tab <?php echo $tab === 'stripe' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=smmcare-pro&tab=stripe' ) ); ?>">Payments</a>
                <a class="nav-tab <?php echo $tab === 'customers' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=smmcare-pro&tab=customers' ) ); ?>">Customers</a>
                <a class="nav-tab <?php echo $tab === 'logs' ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=smmcare-pro&tab=logs' ) ); ?>">Logs</a>
            </h2>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'smmcare_settings' ); ?>
                <input type="hidden" name="action" value="smmcare_save_settings" />
                <input type="hidden" name="smmcare_tab" value="<?php echo esc_attr( $tab ); ?>" />

                <div class="smmcare-settings-panel">
                <?php if ( $tab === 'general' ) : ?>
                    <h2>General</h2>
                    <table class="form-table">
                        <tr><th>Branding Logo URL</th>
                            <td><input type="text" name="smmcare_branding_logo" value="<?php echo esc_attr( $branding_logo ); ?>" style="width:60%"/><p class="description">You can upload a logo later from Media or use the uploader button in the Integrations tab.</p></td></tr>
                        <tr><th>Footer Text</th>
                            <td><input type="text" name="smmcare_footer_text" value="<?php echo esc_attr( $footer_text ); ?>" style="width:60%"/></td></tr>
                    </table>

                <?php elseif ( $tab === 'integrations' ) : ?>
                    <h2>Integrations</h2>
                    <p>OAuth & API integrations (Google / Microsoft). For production, register your own OAuth apps and paste Client IDs/Secrets below.</p>
                    <table class="form-table">
                        <tr><th>Google Client ID</th><td><input type="text" name="smmcare_google_client_id" value="<?php echo esc_attr( get_option( 'smmcare_google_client_id', '' ) ); ?>" style="width:60%"/></td></tr>
                        <tr><th>Google Client Secret</th><td><input type="text" name="smmcare_google_client_secret" value="<?php echo esc_attr( get_option( 'smmcare_google_client_secret', '' ) ); ?>" style="width:60%"/></td></tr>
                        <tr><th>Microsoft Client ID</th><td><input type="text" name="smmcare_ms_client_id" value="<?php echo esc_attr( get_option( 'smmcare_ms_client_id', '' ) ); ?>" style="width:60%"/></td></tr>
                        <tr><th>Microsoft Client Secret</th><td><input type="text" name="smmcare_ms_client_secret" value="<?php echo esc_attr( get_option( 'smmcare_ms_client_secret', '' ) ); ?>" style="width:60%"/></td></tr>
                        <tr><th>OAuth Redirects</th><td><code><?php echo esc_html( rest_url( 'smmcare/v1/oauth/callback/google' ) ); ?></code><br/><code><?php echo esc_html( rest_url( 'smmcare/v1/oauth/callback/microsoft' ) ); ?></code></td></tr>
                        <tr><th>Connect Buttons</th>
                            <td>
                                <button id="smmcare-connect-google" class="button">Open Google Connect Popup</button>
                                <button id="smmcare-connect-ms" class="button">Open Microsoft Connect Popup</button>
                                <p class="description">These open a popup to begin OAuth flows (you must have client IDs configured or use plugin dev app).</p>
                            </td></tr>
                    </table>

                <?php elseif ( $tab === 'email' ) : ?>
                    <h2>Email / Transactional</h2>
                    <p>Per-customer & site default providers. Credentials are encrypted with <code>SMMCARE_SECRET_KEY</code> if present.</p>
                    <table class="form-table">
                        <tr><th>Site Default Provider</th>
                            <td>
                                <select name="smmcare_email_site_default[type]">
                                    <option value="" <?php selected( $email_default['type'] ?? '', '' ); ?>>Use wp_mail (server)</option>
                                    <option value="smtp" <?php selected( $email_default['type'] ?? '', 'smtp' ); ?>>SMTP</option>
                                    <option value="brevo" <?php selected( $email_default['type'] ?? '', 'brevo' ); ?>>Brevo (API)</option>
                                </select>
                                <p class="description">Customers may override with their own provider in their settings.</p>
                            </td></tr>

                        <tr class="smmcare-row-smtp">
                            <th>SMTP Host / Port</th>
                            <td><input type="text" name="smmcare_email_site_default[host]" value="<?php echo esc_attr( $email_default['host'] ?? '' ); ?>" /> <input type="text" name="smmcare_email_site_default[port]" value="<?php echo esc_attr( $email_default['port'] ?? '' ); ?>" style="width:70px" /></td>
                        </tr>
                        <tr class="smmcare-row-smtp"><th>SMTP Username</th><td><input type="text" name="smmcare_email_site_default[username]" value="<?php echo esc_attr( $email_default['username'] ?? '' ); ?>" /></td></tr>
                        <tr class="smmcare-row-smtp"><th>SMTP Password</th><td><input type="password" name="smmcare_email_site_default[password]" value="<?php echo esc_attr( $email_default['password'] ?? '' ); ?>" /></td></tr>

                        <tr class="smmcare-row-brevo"><th>Brevo API Key</th><td><input type="text" name="smmcare_email_site_default[api_key]" value="<?php echo esc_attr( $email_default['api_key'] ?? '' ); ?>" /></td></tr>

                        <tr><th>From Email</th><td><input type="text" name="smmcare_email_site_default[from_email]" value="<?php echo esc_attr( $email_default['from_email'] ?? get_option('admin_email') ); ?>" /></td></tr>
                        <tr><th>From Name</th><td><input type="text" name="smmcare_email_site_default[from_name]" value="<?php echo esc_attr( $email_default['from_name'] ?? get_bloginfo('name') ); ?>" /></td></tr>

                        <tr><th>Test Connection</th>
                            <td>
                                <input type="email" id="smmcare-test-email" placeholder="test@you.com" />
                                <button id="smmcare-test-email-btn" class="button">Send Test</button>
                                <span id="smmcare-test-email-result" style="margin-left:10px;color:#333"></span>
                            </td></tr>
                    </table>

                <?php elseif ( $tab === 'stripe' ) : ?>
                    <h2>Payments / Stripe</h2>
                    <table class="form-table">
                        <tr><th>Stripe Secret Key</th><td><input type="text" name="smmcare_stripe_secret" value="<?php echo esc_attr( $stripe_secret ); ?>" style="width:60%"/></td></tr>
                        <tr><th>Webhook Signing Secret</th><td><input type="text" name="smmcare_stripe_webhook_secret" value="<?php echo esc_attr( $stripe_webhook ); ?>" style="width:60%"/></td></tr>
                        <tr><th>Webhook Endpoint</th><td><code><?php echo esc_html( rest_url( 'smmcare/v1/payments/webhook' ) ); ?></code></td></tr>
                    </table>

                <?php elseif ( $tab === 'customers' ) : ?>
                    <h2>Customers</h2>
                    <p>List of registered SMMCARE customers (role: smmcare_customer). Use <strong>Impersonate</strong> to login as customer for troubleshooting.</p>
                    <table class="widefat fixed">
                        <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Plan</th><th>Actions</th></tr></thead>
                        <tbody>
                        <?php
                        $users = get_users( [ 'role' => 'smmcare_customer', 'number' => 200 ] );
                        if ( empty( $users ) ) {
                            echo '<tr><td colspan="5">No customers yet.</td></tr>';
                        } else {
                            foreach ( $users as $u ) {
                                $plan = get_user_meta( $u->ID, 'smmcare_plan', true ) ?: 'starter';
                                echo '<tr>';
                                echo '<td>' . intval( $u->ID ) . '</td>';
                                echo '<td>' . esc_html( $u->display_name ?: $u->user_login ) . '</td>';
                                echo '<td>' . esc_html( $u->user_email ) . '</td>';
                                echo '<td>' . esc_html( $plan ) . '</td>';
                                echo '<td><button class="button smmcare-impersonate" data-user="' . intval( $u->ID ) . '">Impersonate</button> ';
                                echo '<button class="button smmcare-export" data-user="' . intval( $u->ID ) . '">Export</button></td>';
                                echo '</tr>';
                            }
                        }
                        ?>
                        </tbody>
                    </table>

                <?php elseif ( $tab === 'logs' ) : ?>
                    <h2>Logs</h2>
                    <p>Recent plugin log output (wp-content/debug.log). Keep WP_DEBUG_LOG enabled to capture plugin debug info.</p>
                    <pre style="max-height:420px;overflow:auto;background:#fff;padding:12px;border:1px solid #eee"><?php
                        $log = '';
                        $file = WP_CONTENT_DIR . '/debug.log';
                        if ( file_exists( $file ) ) $log = wp_strip_all_tags( wp_trim_words( @file_get_contents( $file ), 3000, '...' ) );
                        echo esc_html( $log ?: 'No debug.log found or empty.' );
                    ?></pre>
                <?php endif; ?>
                </div>

                <p class="submit"><input type="submit" class="button button-primary" value="Save Settings" /></p>
            </form>
        </div>
        <?php
    }

    /**
     * Handle form POST save
     */
    public function handle_save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        check_admin_referer( 'smmcare_settings' );
        $tab = sanitize_text_field( $_POST['smmcare_tab'] ?? 'general' );

        if ( $tab === 'general' ) {
            update_option( 'smmcare_branding_logo', esc_url_raw( $_POST['smmcare_branding_logo'] ?? '' ) );
            update_option( 'smmcare_footer_text', sanitize_text_field( $_POST['smmcare_footer_text'] ?? '' ) );
        } elseif ( $tab === 'integrations' ) {
            update_option( 'smmcare_google_client_id', sanitize_text_field( $_POST['smmcare_google_client_id'] ?? '' ) );
            update_option( 'smmcare_google_client_secret', sanitize_text_field( $_POST['smmcare_google_client_secret'] ?? '' ) );
            update_option( 'smmcare_ms_client_id', sanitize_text_field( $_POST['smmcare_ms_client_id'] ?? '' ) );
            update_option( 'smmcare_ms_client_secret', sanitize_text_field( $_POST['smmcare_ms_client_secret'] ?? '' ) );
        } elseif ( $tab === 'email' ) {
            $def = $_POST['smmcare_email_site_default'] ?? [];
            // encrypt sensitive fields before saving if SMMCARE_SECRET_KEY present
            if ( isset( $def['password'] ) && ! empty( $def['password'] ) ) {
                $def['password'] = SMMCARE_Email::instance()->encrypt( $def['password'] );
            }
            if ( isset( $def['api_key'] ) && ! empty( $def['api_key'] ) ) {
                $def['api_key'] = SMMCARE_Email::instance()->encrypt( $def['api_key'] );
            }
            update_option( 'smmcare_email_site_default', $def );
        } elseif ( $tab === 'stripe' ) {
            update_option( 'smmcare_stripe_secret', sanitize_text_field( $_POST['smmcare_stripe_secret'] ?? '' ) );
            update_option( 'smmcare_stripe_webhook_secret', sanitize_text_field( $_POST['smmcare_stripe_webhook_secret'] ?? '' ) );
        }

        // Redirect back to settings page and preserve tab
        wp_safe_redirect( add_query_arg( [ 'page' => 'smmcare-pro', 'tab' => $tab ], admin_url( 'admin.php' ) ) );
        exit;
    }

    /**
     * AJAX: Send a test email using provided address and current site default/provider
     */
    public function ajax_test_email() {
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden', 403 );
        check_ajax_referer( 'smmcare_admin', 'nonce' );
        $to = sanitize_email( $_POST['to'] ?? '' );
        if ( empty( $to ) || ! is_email( $to ) ) wp_send_json_error( 'Valid test email required', 400 );

        $email = SMMCARE_Email::instance();
        $success = $email->send_email( $to, 'SMMCARE test email', '<p>This is a test from SMMCARE plugin</p>', 0 );

        if ( $success ) wp_send_json_success( 'Test email sent' );
        wp_send_json_error( 'Send failed' );
    }

    /**
     * AJAX: impersonate a customer (admin only) - create short-lived login cookie
     */
    public function ajax_impersonate_user() {
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden', 403 );
        check_ajax_referer( 'smmcare_admin', 'nonce' );
        $user_id = intval( $_POST['user_id'] ?? 0 );
        if ( ! $user_id ) wp_send_json_error( 'Invalid user', 400 );
        $user = get_user_by( 'id', $user_id );
        if ( ! $user ) wp_send_json_error( 'User not found', 404 );

        // Create a one-time secret, store in transient and return URL with secret to impersonate
        $secret = wp_generate_password( 32, true, true );
        set_transient( 'smmcare_impersonate_' . $secret, $user_id, HOUR_IN_SECONDS );
        $url = add_query_arg( [ 'smmcare_impersonate' => $secret ], home_url() );
        wp_send_json_success( [ 'url' => $url ] );
    }

    /**
     * AJAX: export customer data (CSV)
     */
    public function ajax_export_customer() {
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden', 403 );
        check_ajax_referer( 'smmcare_admin', 'nonce' );
        $user_id = intval( $_POST['user_id'] ?? 0 );
        if ( ! $user_id ) wp_send_json_error( 'Invalid user', 400 );

        // Build CSV: basic user info + tasks + reviews
        global $wpdb;
        $user = get_user_by( 'id', $user_id );
        $rows = [];
        $rows[] = [ 'User ID', $user->ID ];
        $rows[] = [ 'User Email', $user->user_email ];
        $rows[] = [ 'Display Name', $user->display_name ];
        $rows[] = [ '' ];
        $rows[] = [ 'Tasks' ];
        $tasks = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_tasks WHERE customer_id = %d", $user_id ) );
        foreach ( $tasks as $t ) {
            $rows[] = [ $t->id, $t->title, $t->status, $t->due_date, $t->created_at ];
        }
        $rows[] = [ '' ];
        $rows[] = [ 'Reviews' ];
        $revs = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_reviews WHERE customer_id = %d", $user_id ) );
        foreach ( $revs as $r ) {
            $rows[] = [ $r->id, $r->recipient, $r->status, $r->message, $r->created_at ];
        }

        // prepare CSV output
        $fh = fopen( 'php://memory', 'w' );
        foreach ( $rows as $r ) fputcsv( $fh, $r );
        fseek( $fh, 0 );
        $csv = stream_get_contents( $fh );
        fclose( $fh );

        // return as base64 so client can trigger download
        wp_send_json_success( [ 'filename' => 'smmcare-customer-' . $user_id . '.csv', 'csv' => base64_encode( $csv ) ] );
    }

    /**
     * OAuth poll handler (optional) - used by admin JS to check popup status
     */
    public function ajax_oauth_poll() {
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Forbidden', 403 );
        check_ajax_referer( 'smmcare_admin', 'nonce' );
        $key = sanitize_text_field( $_POST['key'] ?? '' );
        if ( empty( $key ) ) wp_send_json_error( 'Missing' );
        $val = get_transient( 'smmcare_oauth_' . $key );
        if ( $val ) {
            delete_transient( 'smmcare_oauth_' . $key );
            wp_send_json_success( $val );
        }
        wp_send_json_error( 'pending', 202 );
    }
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Auth {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/auth/login', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_login' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( 'smmcare/v1', '/auth/signup', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_signup' ],
            'permission_callback' => '__return_true',
        ] );
    }

    public function rest_login( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $user = wp_signon( [
            'user_login'    => sanitize_text_field( $params['username'] ?? '' ),
            'user_password' => $params['password'] ?? '',
            'remember'      => boolval( $params['remember'] ?? false ),
        ], is_ssl() );

        if ( is_wp_error( $user ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => $user->get_error_message() ] );
        }
        wp_set_current_user( $user->ID );
        return rest_ensure_response( [ 'success' => true, 'user_id' => $user->ID ] );
    }

    public function rest_signup( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $email = sanitize_email( $params['email'] ?? '' );
        $password = $params['password'] ?? wp_generate_password();

        if ( empty( $email ) || ! is_email( $email ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Valid email required' ], 400 );
        }

        if ( email_exists( $email ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Email already exists' ], 400 );
        }

        $username = sanitize_user( sanitize_text_field( $params['username'] ?? strstr( $email, '@', true ) ) );
        $user_id = wp_create_user( $username, $password, $email );
        if ( is_wp_error( $user_id ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => $user_id->get_error_message() ], 500 );
        }

        $user = new WP_User( $user_id );
        $user->set_role( 'smmcare_customer' );
        update_user_meta( $user_id, 'smmcare_plan', 'starter' );

        return rest_ensure_response( [ 'success' => true, 'user_id' => $user_id ] );
    }
}
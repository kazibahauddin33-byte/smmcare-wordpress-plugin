<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_Migration
 * - Provides an admin action to re-encrypt stored provider credentials when SMMCARE_SECRET_KEY is added later.
 * - Iterates site default and per-customer provider settings and encrypts plaintext secrets.
 */
class SMMCARE_Migration {
    public static function init() {
        add_action( 'admin_post_smmcare_reencrypt', [ __CLASS__, 'handle_reencrypt' ] );
    }

    /**
     * Admin action handler: re-encrypt site default and all user provider creds
     */
    public static function handle_reencrypt() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden' );
        check_admin_referer( 'smmcare_settings' );

        if ( ! defined( 'SMMCARE_SECRET_KEY' ) || empty( SMMCARE_SECRET_KEY ) ) {
            wp_redirect( add_query_arg( [ 'page' => 'smmcare-pro', 'tab' => 'email', 'msg' => 'no_key' ], admin_url( 'admin.php' ) ) );
            exit;
        }

        $email = SMMCARE_Email::instance();
        // Re-encrypt site default
        $site = get_option( 'smmcare_email_site_default', [] );
        $changed = false;
        if ( is_array( $site ) && ! empty( $site ) ) {
            // if password present and does not look encrypted, encrypt it
            if ( isset( $site['password'] ) && $site['password'] ) {
                $val = $site['password'];
                // detect probable existing encryption (base64 with iv+cipher) — try decrypt: if decrypt returns non-empty assume already encrypted
                $try = $email->decrypt( $val );
                if ( empty( $try ) ) {
                    $site['password'] = $email->encrypt( $val );
                    update_option( 'smmcare_email_site_default', $site );
                    $changed = true;
                }
            }
            if ( isset( $site['api_key'] ) && $site['api_key'] ) {
                $val = $site['api_key'];
                $try = $email->decrypt( $val );
                if ( empty( $try ) ) {
                    $site['api_key'] = $email->encrypt( $val );
                    update_option( 'smmcare_email_site_default', $site );
                    $changed = true;
                }
            }
        }

        // Re-encrypt per-user providers
        $users = get_users( [ 'role' => 'smmcare_customer', 'number' => 500 ] );
        foreach ( $users as $u ) {
            $cfg = get_user_meta( $u->ID, 'smmcare_email_provider', true );
            if ( is_array( $cfg ) && ! empty( $cfg ) ) {
                $update = false;
                if ( isset( $cfg['password'] ) && $cfg['password'] ) {
                    $try = $email->decrypt( $cfg['password'] );
                    if ( empty( $try ) ) {
                        $cfg['password'] = $email->encrypt( $cfg['password'] );
                        $update = true;
                    }
                }
                if ( isset( $cfg['api_key'] ) && $cfg['api_key'] ) {
                    $try = $email->decrypt( $cfg['api_key'] );
                    if ( empty( $try ) ) {
                        $cfg['api_key'] = $email->encrypt( $cfg['api_key'] );
                        $update = true;
                    }
                }
                if ( $update ) {
                    update_user_meta( $u->ID, 'smmcare_email_provider', $cfg );
                    $changed = true;
                }
            }
        }

        $redirect = add_query_arg( [ 'page' => 'smmcare-pro', 'tab' => 'email', 'reencrypted' => $changed ? 1 : 0 ], admin_url( 'admin.php' ) );
        wp_safe_redirect( $redirect );
        exit;
    }
}

SMMCARE_Migration::init();
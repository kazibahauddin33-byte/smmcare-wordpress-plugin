<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_Onboarding
 * - Simple onboarding helper for first-run experience.
 * - Stores onboarding step completion in option 'smmcare_onboarding'.
 * - Exposes REST endpoints so the frontend/admin UI can show progress and mark steps completed.
 */
class SMMCARE_Onboarding {
    private static $instance = null;
    private $option_key = 'smmcare_onboarding';

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    private function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_action( 'admin_notices', [ $this, 'maybe_show_admin_notice' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/onboarding', [
            'methods' => 'GET',
            'callback' => [ $this, 'rest_get_status' ],
            'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        ] );
        register_rest_route( 'smmcare/v1', '/onboarding/complete', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_complete_step' ],
            'permission_callback' => function() { return current_user_can( 'manage_options' ); },
            'args' => [
                'step' => [ 'required' => true, 'type' => 'string' ],
            ],
        ] );
        register_rest_route( 'smmcare/v1', '/onboarding/reset', [
            'methods' => 'POST',
            'callback' => [ $this, 'rest_reset' ],
            'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        ] );
    }

    /**
     * Default steps for onboarding. You can extend these if you add more items.
     */
    public function default_steps() {
        return [
            'add_secret_key' => [
                'title' => 'Add SMMCARE_SECRET_KEY to wp-config.php',
                'description' => 'Add the encryption key to wp-config.php to securely store provider secrets.',
            ],
            'configure_email' => [
                'title' => 'Configure site email provider',
                'description' => 'Set a site default email provider so transactional emails can be sent.',
            ],
            'connect_oauth' => [
                'title' => 'Connect Google / Microsoft (optional)',
                'description' => 'Connect OAuth providers to enable Gmail/Outlook sending and IMAP polling.',
            ],
            'set_openai' => [
                'title' => 'Add OpenAI API key (optional)',
                'description' => 'Add your OpenAI key to enable real AI outputs in AI Tools.',
            ],
            'configure_stripe' => [
                'title' => 'Configure Stripe (optional)',
                'description' => 'Add Stripe keys to accept payments and manage subscriptions.',
            ],
            'create_demo_customer' => [
                'title' => 'Create demo customer (optional)',
                'description' => 'Create demo users to test customer flows quickly.',
            ],
        ];
    }

    /**
     * Get onboarding status (list of steps with completed flag)
     */
    public function get_status() {
        $stored = get_option( $this->option_key, [] );
        $steps = $this->default_steps();
        $out = [];
        foreach ( $steps as $key => $meta ) {
            $out[ $key ] = [
                'title' => $meta['title'],
                'description' => $meta['description'],
                'completed' => ! empty( $stored[ $key ] ),
                'completed_at' => $stored[ $key ] ?? null,
            ];
        }
        return $out;
    }

    /**
     * Mark a step completed
     */
    public function complete_step( $step ) {
        if ( empty( $step ) ) return false;
        $stored = get_option( $this->option_key, [] );
        $stored[ $step ] = current_time( 'mysql' );
        update_option( $this->option_key, $stored );
        return true;
    }

    /**
     * Reset onboarding (clears completions)
     */
    public function reset_onboarding() {
        delete_option( $this->option_key );
        return true;
    }

    /* ---------- REST callbacks ---------- */

    public function rest_get_status( WP_REST_Request $request ) {
        return rest_ensure_response( [ 'success' => true, 'data' => $this->get_status() ] );
    }

    public function rest_complete_step( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $step = sanitize_text_field( $params['step'] ?? '' );
        if ( empty( $step ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'step required' ], 400 );
        }
        $ok = $this->complete_step( $step );
        if ( $ok ) return rest_ensure_response( [ 'success' => true, 'message' => 'Completed' ] );
        return rest_ensure_response( [ 'success' => false, 'message' => 'Failed' ], 500 );
    }

    public function rest_reset( WP_REST_Request $request ) {
        $this->reset_onboarding();
        return rest_ensure_response( [ 'success' => true, 'message' => 'Onboarding reset' ] );
    }

    /* ---------- Admin UI helpers ---------- */

    public function maybe_show_admin_notice() {
        if ( ! current_user_can( 'manage_options' ) ) return;

        $status = $this->get_status();
        // Show admin notice if core required step (add_secret_key) not completed
        if ( empty( $status['add_secret_key']['completed'] ) ) {
            echo '<div class="notice notice-warning is-dismissible"><p><strong>SMMCARE:</strong> Please add <code>SMMCARE_SECRET_KEY</code> to <code>wp-config.php</code> to securely store provider secrets. After adding the key, go to <em>SMMCARE Pro → Email</em> and run the re-encrypt tool.</p></div>';
        }
    }
}

SMMCARE_Onboarding::instance();
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_OAuth
 * - Provides REST endpoints to start OAuth flows and handle callbacks for Google & Microsoft
 * - On success it stores OAuth tokens (encrypted by SMMCARE_Email) and sets a transient so the admin popup can poll.
 *
 * NOTE: For production use register your own OAuth apps and paste client IDs/secrets into settings.
 */
class SMMCARE_OAuth {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/oauth/start/(?P<provider>[a-zA-Z0-9_-]+)', [
            'methods' => 'GET',
            'callback' => [ $this, 'start_flow' ],
            'permission_callback' => function() { return current_user_can( 'manage_options' ); },
        ] );
        register_rest_route( 'smmcare/v1', '/oauth/callback/(?P<provider>[a-zA-Z0-9_-]+)', [
            'methods' => 'GET',
            'callback' => [ $this, 'handle_callback' ],
            'permission_callback' => '__return_true',
        ] );
    }

    /**
     * Start OAuth flow: returns a redirect (used by admin JS popup)
     * query params: key (random string used to set transient on completion)
     */
    public function start_flow( WP_REST_Request $request ) {
        $provider = $request->get_param( 'provider' );
        $key = wp_generate_password( 16, false, false );
        $state = wp_json_encode( [ 'k' => $key, 'nonce' => wp_create_nonce( 'smmcare_oauth_state' ) ] );

        if ( $provider === 'google' ) {
            $client_id = get_option( 'smmcare_google_client_id', '' );
            $redirect = rest_url( "smmcare/v1/oauth/callback/google" );
            $scope = urlencode( 'openid email profile https://www.googleapis.com/auth/gmail.send https://www.googleapis.com/auth/gmail.modify' );
            $url = "https://accounts.google.com/o/oauth2/v2/auth?response_type=code&client_id=" . rawurlencode( $client_id ) .
                   "&redirect_uri=" . rawurlencode( $redirect ) . "&scope={$scope}&access_type=offline&prompt=consent&state=" . rawurlencode( $state );
            // store ephemeral key so JS can poll
            set_transient( 'smmcare_oauth_' . $key, [ 'status' => 'started' ], 300 );
            return rest_ensure_response( [ 'redirect' => $url, 'key' => $key ] );
        } elseif ( $provider === 'microsoft' ) {
            $client_id = get_option( 'smmcare_ms_client_id', '' );
            $redirect = rest_url( "smmcare/v1/oauth/callback/microsoft" );
            $scope = rawurlencode( 'openid offline_access User.Read Mail.Send Mail.Read Mail.ReadWrite' );
            $url = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=" . rawurlencode( $client_id ) .
                   "&response_type=code&redirect_uri=" . rawurlencode( $redirect ) . "&response_mode=query&scope={$scope}&state=" . rawurlencode( $state );
            set_transient( 'smmcare_oauth_' . $key, [ 'status' => 'started' ], 300 );
            return rest_ensure_response( [ 'redirect' => $url, 'key' => $key ] );
        }

        return new WP_Error( 'unsupported', 'Unsupported provider', [ 'status' => 400 ] );
    }

    /**
     * Handle callback from provider; exchange code for tokens and store.
     * Expects state to include key.
     */
    public function handle_callback( WP_REST_Request $request ) {
        $provider = $request->get_param( 'provider' );
        $code = sanitize_text_field( $_GET['code'] ?? '' );
        $state_raw = $_GET['state'] ?? '';
        $state = json_decode( wp_unslash( $state_raw ), true );
        $key = isset( $state['k'] ) ? sanitize_text_field( $state['k'] ) : '';

        if ( empty( $code ) || empty( $key ) ) {
            // redirect to a friendly admin page with error
            wp_safe_redirect( admin_url( 'admin.php?page=smmcare-pro&tab=integrations&oauth_error=1' ) );
            exit;
        }

        if ( $provider === 'google' ) {
            $client_id = get_option( 'smmcare_google_client_id', '' );
            $client_secret = get_option( 'smmcare_google_client_secret', '' );
            $redirect = rest_url( "smmcare/v1/oauth/callback/google" );

            $args = [
                'body' => [
                    'code' => $code,
                    'client_id' => $client_id,
                    'client_secret' => $client_secret,
                    'redirect_uri' => $redirect,
                    'grant_type' => 'authorization_code',
                ],
                'timeout' => 20,
            ];
            $resp = wp_remote_post( 'https://oauth2.googleapis.com/token', $args );
            if ( is_wp_error( $resp ) ) {
                set_transient( 'smmcare_oauth_' . $key, [ 'status' => 'error', 'message' => $resp->get_error_message() ], 300 );
                wp_safe_redirect( admin_url( 'admin.php?page=smmcare-pro&tab=integrations&oauth_error=1' ) );
                exit;
            }
            $data = json_decode( wp_remote_retrieve_body( $resp ), true );
            // store tokens (encrypt)
            $email = SMMCARE_Email::instance();
            $stored = [
                'provider' => 'google',
                'access_token' => $email->encrypt( $data['access_token'] ?? '' ),
                'refresh_token' => $email->encrypt( $data['refresh_token'] ?? '' ),
                'expires_in' => intval( $data['expires_in'] ?? 0 ),
            ];
            update_option( 'smmcare_google_tokens', $stored );
            set_transient( 'smmcare_oauth_' . $key, [ 'status' => 'connected', 'provider' => 'google' ], 300 );
            wp_safe_redirect( admin_url( 'admin.php?page=smmcare-pro&tab=integrations&oauth=google&success=1' ) );
            exit;
        } elseif ( $provider === 'microsoft' ) {
            $client_id = get_option( 'smmcare_ms_client_id', '' );
            $client_secret = get_option( 'smmcare_ms_client_secret', '' );
            $redirect = rest_url( "smmcare/v1/oauth/callback/microsoft" );
            $token_url = 'https://login.microsoftonline.com/common/oauth2/v2.0/token';
            $args = [
                'body' => [
                    'client_id' => $client_id,
                    'client_secret' => $client_secret,
                    'code' => $code,
                    'redirect_uri' => $redirect,
                    'grant_type' => 'authorization_code',
                ],
                'timeout' => 20,
            ];
            $resp = wp_remote_post( $token_url, $args );
            if ( is_wp_error( $resp ) ) {
                set_transient( 'smmcare_oauth_' . $key, [ 'status' => 'error', 'message' => $resp->get_error_message() ], 300 );
                wp_safe_redirect( admin_url( 'admin.php?page=smmcare-pro&tab=integrations&oauth_error=1' ) );
                exit;
            }
            $data = json_decode( wp_remote_retrieve_body( $resp ), true );
            $email = SMMCARE_Email::instance();
            $stored = [
                'provider' => 'microsoft',
                'access_token' => $email->encrypt( $data['access_token'] ?? '' ),
                'refresh_token' => $email->encrypt( $data['refresh_token'] ?? '' ),
                'expires_in' => intval( $data['expires_in'] ?? 0 ),
            ];
            update_option( 'smmcare_ms_tokens', $stored );
            set_transient( 'smmcare_oauth_' . $key, [ 'status' => 'connected', 'provider' => 'microsoft' ], 300 );
            wp_safe_redirect( admin_url( 'admin.php?page=smmcare-pro&tab=integrations&oauth=microsoft&success=1' ) );
            exit;
        }

        wp_safe_redirect( admin_url( 'admin.php?page=smmcare-pro&tab=integrations&oauth_error=1' ) );
        exit;
    }
}

SMMCARE_OAuth::instance();
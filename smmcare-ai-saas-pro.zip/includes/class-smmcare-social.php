<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_Social
 * - Adapter skeletons for social posting (Meta, X, LinkedIn)
 * - REST endpoints to queue posts and list scheduled posts
 * - Actual provider implementations should be added to adapters/* or extended here
 */
class SMMCARE_Social {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_action( 'smmcare_five_min_cron', [ $this, 'dispatch_scheduled_posts' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/social/post', [
            'methods' => 'POST',
            'callback' => [ $this, 'create_post' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/social/queue', [
            'methods' => 'GET',
            'callback' => [ $this, 'list_queue' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }

    /**
     * Queue a social post (stores in planner posts table with network)
     */
    public function create_post( WP_REST_Request $request ) {
        $p = $request->get_json_params();
        $content = sanitize_textarea_field( $p['content'] ?? '' );
        $network = sanitize_text_field( $p['network'] ?? 'facebook' );
        $date = sanitize_text_field( $p['scheduled_for'] ?? '' );
        $user = get_current_user_id();
        if ( empty( $content ) || empty( $date ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'content and scheduled_for required' ], 400 );
        }
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_planner_posts';
        $wpdb->insert( $table, [
            'customer_id' => $user,
            'content' => $content,
            'network' => $network,
            'scheduled_for' => date( 'Y-m-d H:i:s', strtotime( $date ) ),
            'status' => 'scheduled',
            'created_at' => current_time( 'mysql' ),
        ], [ '%d','%s','%s','%s','%s','%s' ] );
        return rest_ensure_response( [ 'success' => true, 'message' => 'Queued' ] );
    }

    /**
     * List queued/scheduled posts for current user
     */
    public function list_queue() {
        global $wpdb;
        $user = get_current_user_id();
        if ( current_user_can( 'manage_options' ) ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_planner_posts ORDER BY scheduled_for DESC LIMIT 500" );
        } else {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_planner_posts WHERE customer_id = %d ORDER BY scheduled_for DESC LIMIT 500", $user ) );
        }
        return rest_ensure_response( [ 'success' => true, 'data' => $rows ] );
    }

    /**
     * Dispatch scheduled posts (called by cron)
     * This uses placeholder adapter methods — implement real providers per network.
     */
    public function dispatch_scheduled_posts() {
        global $wpdb;
        $now = current_time( 'mysql' );
        $table = $wpdb->prefix . 'smmcare_planner_posts';
        $posts = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status = 'scheduled' AND scheduled_for <= %s LIMIT 20", $now ) );
        if ( empty( $posts ) ) return;
        foreach ( $posts as $p ) {
            $ok = false;
            switch ( strtolower( $p->network ) ) {
                case 'facebook':
                case 'instagram':
                    $ok = $this->post_to_meta( $p );
                    break;
                case 'twitter':
                case 'x':
                    $ok = $this->post_to_x( $p );
                    break;
                case 'linkedin':
                    $ok = $this->post_to_linkedin( $p );
                    break;
                default:
                    $ok = false;
            }
            $wpdb->update( $table, [ 'status' => $ok ? 'published' : 'failed' ], [ 'id' => $p->id ], [ '%s' ], [ '%d' ] );
        }
    }

    /* Placeholder provider implementations — extend these to call provider SDKs/APIs */
    private function post_to_meta( $post ) {
        // TODO: implement Facebook/Instagram API posting (use Graph API and page access tokens stored per-customer)
        return true; // return true if successful
    }

    private function post_to_x( $post ) {
        // TODO: implement X / Twitter posting (OAuth + API)
        return true;
    }

    private function post_to_linkedin( $post ) {
        // TODO: implement LinkedIn API posting
        return true;
    }
}

SMMCARE_Social::instance();
<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_Subscriptions
 * - Stripe subscription helper; uses stripe-php if available (composer)
 * - Exposes a REST route to create checkout sessions and a secure webhook handler using stripe-php if present
 */
class SMMCARE_Subscriptions {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/subscriptions/create', [
            'methods' => 'POST',
            'callback' => [ $this, 'create_checkout_session' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/subscriptions/webhook', [
            'methods' => 'POST',
            'callback' => [ $this, 'handle_webhook' ],
            'permission_callback' => '__return_true',
        ] );
    }

    public function create_checkout_session( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $plan = sanitize_text_field( $params['plan'] ?? 'starter' );
        $success = esc_url_raw( $params['success_url'] ?? home_url() );
        $cancel = esc_url_raw( $params['cancel_url'] ?? home_url() );
        $user = get_current_user_id();

        $secret = get_option( 'smmcare_stripe_secret', '' );
        if ( empty( $secret ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Stripe secret not configured' ], 500 );
        }

        $price = get_option( 'smmcare_price_' . $plan, '' );
        if ( empty( $price ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'Price ID missing' ], 400 );

        // Use stripe-php if available
        if ( class_exists( '\Stripe\Stripe' ) ) {
            \Stripe\Stripe::setApiKey( $secret );
            try {
                $session = \Stripe\Checkout\Session::create([
                    'mode' => 'subscription',
                    'line_items' => [ [ 'price' => $price, 'quantity' => 1 ] ],
                    'success_url' => $success . '?session_id={CHECKOUT_SESSION_ID}',
                    'cancel_url' => $cancel,
                    'metadata' => [ 'user_id' => $user, 'plan' => $plan ],
                ]);
                return rest_ensure_response( [ 'success' => true, 'data' => $session ] );
            } catch ( \Exception $e ) {
                return rest_ensure_response( [ 'success' => false, 'message' => $e->getMessage() ], 500 );
            }
        }

        // Fallback: REST call to Stripe (no signature verification here)
        $body = [
            'mode' => 'subscription',
            'line_items' => [ [ 'price' => $price, 'quantity' => 1 ] ],
            'success_url' => $success . '?session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => $cancel,
            'metadata' => [ 'user_id' => $user, 'plan' => $plan ],
        ];
        $args = [
            'headers' => [ 'Authorization' => 'Bearer ' . $secret, 'Content-Type' => 'application/x-www-form-urlencoded' ],
            'body' => $this->build_stripe_form_body( $body ),
            'timeout' => 30,
        ];
        $resp = wp_remote_post( 'https://api.stripe.com/v1/checkout/sessions', $args );
        if ( is_wp_error( $resp ) ) return rest_ensure_response( [ 'success' => false, 'message' => $resp->get_error_message() ], 500 );
        $code = wp_remote_retrieve_response_code( $resp );
        $data = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( $code >= 200 && $code < 300 ) return rest_ensure_response( [ 'success' => true, 'data' => $data ] );
        return rest_ensure_response( [ 'success' => false, 'message' => $data['error']['message'] ?? 'Stripe error' ], $code );
    }

    private function build_stripe_form_body( $data ) {
        $flat = [];
        $this->flatten_data( $data, '', $flat );
        return $flat;
    }
    private function flatten_data( $data, $prefix, &$out ) {
        if ( is_array( $data ) ) {
            foreach ( $data as $k => $v ) {
                $new = $prefix === '' ? $k : $prefix . '[' . $k . ']';
                $this->flatten_data( $v, $new, $out );
            }
        } else {
            $out[ $prefix ] = $data;
        }
    }

    public function handle_webhook( WP_REST_Request $request ) {
        $secret = get_option( 'smmcare_stripe_webhook_secret', '' );
        $payload = $request->get_body();
        $sig = isset( $_SERVER['HTTP_STRIPE_SIGNATURE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_STRIPE_SIGNATURE'] ) ) : '';

        if ( class_exists( '\Stripe\Webhook' ) && ! empty( $secret ) ) {
            try {
                \Stripe\Stripe::setApiKey( get_option( 'smmcare_stripe_secret', '' ) );
                $event = \Stripe\Webhook::constructEvent( $payload, $sig, $secret );
            } catch ( \UnexpectedValueException $e ) {
                return rest_ensure_response( [ 'received' => false, 'message' => 'Invalid payload' ], 400 );
            } catch ( \Stripe\Exception\SignatureVerificationException $e ) {
                return rest_ensure_response( [ 'received' => false, 'message' => 'Signature verification failed' ], 400 );
            }

            // handle event
            $type = $event->type;
            if ( $type === 'checkout.session.completed' ) {
                $session = $event->data->object;
                $meta = $session->metadata ?? [];
                $user_id = intval( $meta['user_id'] ?? 0 );
                $plan = sanitize_text_field( $meta['plan'] ?? 'starter' );
                if ( $user_id ) {
                    update_user_meta( $user_id, 'smmcare_plan', $plan );
                }
            }
            return rest_ensure_response( [ 'received' => true ] );
        }

        // fallback naive handler (no verification)
        $event = json_decode( $payload, true );
        if ( empty( $event ) ) return rest_ensure_response( [ 'received' => false, 'message' => 'Invalid payload' ], 400 );
        if ( $event['type'] === 'checkout.session.completed' ) {
            $session = $event['data']['object'] ?? null;
            if ( $session ) {
                $meta = $session['metadata'] ?? [];
                $user_id = intval( $meta['user_id'] ?? 0 );
                $plan = sanitize_text_field( $meta['plan'] ?? 'starter' );
                if ( $user_id ) update_user_meta( $user_id, 'smmcare_plan', $plan );
            }
        }
        return rest_ensure_response( [ 'received' => true ] );
    }
}

SMMCARE_Subscriptions::instance();
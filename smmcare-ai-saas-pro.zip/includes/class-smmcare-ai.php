<?php
if ( ! defined( 'ABSPATH' ) ) exit;
if ( class_exists( 'SMMCARE_AI' ) ) return;

class SMMCARE_AI {
    private static $instance = null;
    private $openai_key;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->openai_key = get_option( 'smmcare_openai_key', '' );
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/ai', [
            'methods' => 'POST',
            'callback' => [ $this, 'handle_ai' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }

    public function handle_ai( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $tool = sanitize_text_field( $params['tool'] ?? '' );
        $prompt = sanitize_textarea_field( $params['prompt'] ?? '' );
        if ( empty( $tool ) || empty( $prompt ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Tool and prompt required' ], 400 );
        }
        if ( empty( $this->openai_key ) ) {
            $mock = "SMMCARE AI (Demo) — " . ucfirst( $tool ) . " output for prompt:\n\n" . $prompt;
            return rest_ensure_response( [ 'success' => true, 'data' => $mock ] );
        }
        $body = [
            'model' => apply_filters( 'smmcare_openai_model', 'gpt-3.5-turbo' ),
            'messages' => [
                [ 'role' => 'system', 'content' => "You are SMMCARE AI: produce concise content for {$tool}." ],
                [ 'role' => 'user', 'content' => $prompt ],
            ],
            'max_tokens' => apply_filters( 'smmcare_openai_max_tokens', 800 ),
        ];
        $args = [
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->openai_key,
            ],
            'body' => wp_json_encode( $body ),
            'timeout' => 45,
        ];
        $resp = wp_remote_post( 'https://api.openai.com/v1/chat/completions', $args );
        if ( is_wp_error( $resp ) ) return rest_ensure_response( [ 'success' => false, 'message' => $resp->get_error_message() ], 500 );
        $data = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( isset( $data['choices'][0]['message']['content'] ) ) {
            return rest_ensure_response( [ 'success' => true, 'data' => trim( $data['choices'][0]['message']['content'] ) ] );
        }
        return rest_ensure_response( [ 'success' => false, 'message' => 'OpenAI error' ], 500 );
    }
}
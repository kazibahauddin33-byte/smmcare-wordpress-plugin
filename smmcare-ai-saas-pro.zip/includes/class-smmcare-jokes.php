<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_Jokes
 * - Provides a REST endpoint to return a random joke from an external API (cached)
 * - Adds a shortcode [smmcare_random_joke] to render a small widget and enqueue front-end script
 *
 * External APIs used (fallback chain):
 * 1) https://v2.jokeapi.dev/joke/Any?type=single
 * 2) https://official-joke-api.appspot.com/random_joke
 *
 * Response format:
 * { success: true, data: { joke: "..." } }
 */
class SMMCARE_Jokes {
    private static $instance = null;
    private $cache_ttl = 60; // seconds

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    private function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_shortcode( 'smmcare_random_joke', [ $this, 'shortcode_joke_widget' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/joke', [
            'methods' => 'GET',
            'callback' => [ $this, 'get_joke' ],
            'permission_callback' => '__return_true',
        ] );
    }

    public function get_joke( WP_REST_Request $request ) {
        $cache_key = 'smmcare_joke_cache';
        $cached = get_transient( $cache_key );
        if ( $cached ) {
            return rest_ensure_response( [ 'success' => true, 'data' => [ 'joke' => $cached ] ] );
        }

        // Primary API
        $resp = wp_remote_get( 'https://v2.jokeapi.dev/joke/Any?type=single', [ 'timeout' => 8 ] );
        if ( ! is_wp_error( $resp ) ) {
            $code = wp_remote_retrieve_response_code( $resp );
            $body = wp_remote_retrieve_body( $resp );
            $data = json_decode( $body, true );
            if ( $code >= 200 && $code < 300 && isset( $data['joke'] ) ) {
                set_transient( $cache_key, $data['joke'], $this->cache_ttl );
                return rest_ensure_response( [ 'success' => true, 'data' => [ 'joke' => $data['joke'] ] ] );
            }
        }

        // Fallback API
        $resp2 = wp_remote_get( 'https://official-joke-api.appspot.com/random_joke', [ 'timeout' => 8 ] );
        if ( ! is_wp_error( $resp2 ) ) {
            $code = wp_remote_retrieve_response_code( $resp2 );
            $body = wp_remote_retrieve_body( $resp2 );
            $data = json_decode( $body, true );
            if ( $code >= 200 && $code < 300 && isset( $data['setup'] ) && isset( $data['punchline'] ) ) {
                $joke = $data['setup'] . ' ' . $data['punchline'];
                set_transient( $cache_key, $joke, $this->cache_ttl );
                return rest_ensure_response( [ 'success' => true, 'data' => [ 'joke' => $joke ] ] );
            }
        }

        return rest_ensure_response( [ 'success' => false, 'message' => 'Could not fetch joke' ], 500 );
    }

    public function enqueue_assets() {
        if ( is_admin() ) return;
        wp_enqueue_script( 'smmcare-jokes', SMMCARE_URL . 'assets/js/jokes.min.js', [ 'jquery' ], SMMCARE_VERSION, true );
        wp_localize_script( 'smmcare-jokes', 'smmcareJokes', [ 'rest' => esc_url_raw( rest_url( 'smmcare/v1/joke' ) ) ] );
    }

    public function shortcode_joke_widget( $atts ) {
        $atts = shortcode_atts( [ 'refresh' => 60 ], $atts );
        $out  = '<div class="smmcare-joke-widget">';
        $out .= '<div id="smmcare-random-joke">Loading joke…</div>';
        $out .= '<button id="smmcare-joke-refresh" class="button">New joke</button>';
        $out .= '</div>';
        return $out;
    }
}
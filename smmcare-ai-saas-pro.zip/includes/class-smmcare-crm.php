<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_CRM {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/crm/tasks', [
            'methods' => 'POST',
            'callback' => [ $this, 'create_task' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/crm/tasks', [
            'methods' => 'GET',
            'callback' => [ $this, 'list_tasks' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/crm/tasks/(?P<id>\d+)', [
            'methods' => [ 'POST', 'PUT' ],
            'callback' => [ $this, 'update_task' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }

    public function create_task( WP_REST_Request $request ) {
        $params = $request->get_json_params();
        $title = sanitize_text_field( $params['title'] ?? '' );
        $due = sanitize_text_field( $params['due_date'] ?? '' );
        $user = get_current_user_id();
        if ( empty( $title ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Title required' ], 400 );
        }
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_tasks';
        $wpdb->insert( $table, [
            'customer_id' => $user,
            'title'       => $title,
            'description' => sanitize_textarea_field( $params['description'] ?? '' ),
            'due_date'    => $due ? date( 'Y-m-d H:i:s', strtotime( $due ) ) : null,
            'status'      => 'open',
            'created_at'  => current_time( 'mysql' ),
        ], [ '%d','%s','%s','%s','%s','%s' ] );
        return rest_ensure_response( [ 'success' => true, 'message' => 'Task created' ] );
    }

    public function list_tasks() {
        global $wpdb;
        $user = get_current_user_id();
        if ( current_user_can( 'manage_options' ) ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_tasks ORDER BY created_at DESC LIMIT 500" );
        } else {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_tasks WHERE customer_id = %d ORDER BY created_at DESC LIMIT 500", $user ) );
        }
        return rest_ensure_response( [ 'success' => true, 'data' => $rows ] );
    }

    public function update_task( WP_REST_Request $request ) {
        $id = intval( $request->get_param( 'id' ) );
        $params = $request->get_json_params();
        $status = sanitize_text_field( $params['status'] ?? '' );

        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_tasks';
        $task = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
        if ( ! $task ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Task not found' ], 404 );
        }
        if ( ! current_user_can( 'manage_options' ) && $task->customer_id != get_current_user_id() ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'Forbidden' ], 403 );
        }
        $data = [];
        $format = [];
        if ( $status ) { $data['status'] = $status; $format[] = '%s'; }
        if ( isset( $params['title'] ) ) { $data['title'] = sanitize_text_field( $params['title'] ); $format[] = '%s'; }
        if ( isset( $params['description'] ) ) { $data['description'] = sanitize_textarea_field( $params['description'] ); $format[] = '%s'; }
        if ( empty( $data ) ) return rest_ensure_response( [ 'success' => false, 'message' => 'No data' ], 400 );
        $wpdb->update( $table, $data, [ 'id' => $id ], $format, [ '%d' ] );
        return rest_ensure_response( [ 'success' => true, 'message' => 'Task updated' ] );
    }
}
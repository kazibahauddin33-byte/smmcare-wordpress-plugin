<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * SMMCARE_Campaigns
 * - Backend for email campaigns: create, list, schedule, and worker to send pending campaigns
 */
class SMMCARE_Campaigns {
    private static $instance = null;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_action( 'smmcare_five_min_cron', [ $this, 'process_pending_campaigns' ] );
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/campaigns', [
            'methods' => 'POST',
            'callback' => [ $this, 'create_campaign' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/campaigns', [
            'methods' => 'GET',
            'callback' => [ $this, 'list_campaigns' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
    }

    public function create_campaign( WP_REST_Request $request ) {
        $p = $request->get_json_params();
        $subject = sanitize_text_field( $p['subject'] ?? '' );
        $body = wp_kses_post( $p['body'] ?? '' );
        $list = sanitize_text_field( $p['list_id'] ?? '' );
        $scheduled = sanitize_text_field( $p['scheduled_at'] ?? '' );
        $user = get_current_user_id();

        if ( empty( $subject ) || empty( $body ) ) {
            return rest_ensure_response( [ 'success' => false, 'message' => 'subject and body required' ], 400 );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_email_campaigns';
        $wpdb->insert( $table, [
            'customer_id' => $user,
            'subject' => $subject,
            'body' => $body,
            'list_id' => $list,
            'scheduled_at' => $scheduled ? date( 'Y-m-d H:i:s', strtotime( $scheduled ) ) : null,
            'status' => $scheduled ? 'scheduled' : 'pending',
            'created_at' => current_time( 'mysql' ),
        ], [ '%d','%s','%s','%s','%s','%s','%s' ] );

        return rest_ensure_response( [ 'success' => true, 'message' => 'Campaign saved' ] );
    }

    public function list_campaigns() {
        global $wpdb;
        $user = get_current_user_id();
        if ( current_user_can( 'manage_options' ) ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}smmcare_email_campaigns ORDER BY created_at DESC LIMIT 500" );
        } else {
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smmcare_email_campaigns WHERE customer_id = %d ORDER BY created_at DESC LIMIT 500", $user ) );
        }
        return rest_ensure_response( [ 'success' => true, 'data' => $rows ] );
    }

    /**
     * Worker: sends pending/scheduled campaigns (invoked by cron)
     */
    public function process_pending_campaigns() {
        global $wpdb;
        $table = $wpdb->prefix . 'smmcare_email_campaigns';
        $now = current_time( 'mysql' );

        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status IN ('pending','scheduled') AND (scheduled_at IS NULL OR scheduled_at <= %s) LIMIT 20", $now ) );
        if ( empty( $rows ) ) return;

        foreach ( $rows as $c ) {
            // Resolve recipients — list_id can be comma-separated emails for now or integration with lists later
            $recipients = [];
            if ( ! empty( $c->list_id ) ) {
                $parts = array_map( 'trim', explode( ',', $c->list_id ) );
                foreach ( $parts as $p ) if ( is_email( $p ) ) $recipients[] = $p;
            }

            if ( empty( $recipients ) ) {
                $recipients = [ 'demo@smmcare.com' ];
            }

            foreach ( $recipients as $r ) {
                SMMCARE_Email::instance()->send_email( $r, $c->subject, $c->body, $c->customer_id );
            }

            $wpdb->update( $table, [ 'status' => 'sent' ], [ 'id' => $c->id ], [ '%s' ], [ '%d' ] );
        }
    }
}

SMMCARE_Campaigns::instance();
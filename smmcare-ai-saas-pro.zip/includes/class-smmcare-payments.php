<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMMCARE_Payments {
    private static $instance = null;
    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->hooks();
        }
        return self::$instance;
    }

    public function hooks() {
        add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'admin_enqueue_media' ] );
    }

    public function admin_enqueue_media( $hook ) {
        if ( strpos( $hook, 'smmcare-pro' ) === false && strpos( $hook, 'toplevel_page_smmcare-pro' ) === false ) return;
        wp_enqueue_media();
        wp_enqueue_script( 'smmcare-admin-media', SMMCARE_URL . 'assets/js/admin.min.js', [ 'jquery' ], SMMCARE_VERSION, true );
    }

    public function add_admin_menu() {
        add_menu_page( 'SMMCARE Pro', 'SMMCARE Pro', 'manage_options', 'smmcare-pro', [ $this, 'settings_page' ], 'dashicons-chart-area', 59 );
    }

    public function settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( isset( $_POST['smmcare_save_settings'] ) ) {
            check_admin_referer( 'smmcare_settings' );
            update_option( 'smmcare_openai_key', sanitize_text_field( $_POST['smmcare_openai_key'] ?? '' ) );
            update_option( 'smmcare_stripe_secret', sanitize_text_field( $_POST['smmcare_stripe_secret'] ?? '' ) );
            update_option( 'smmcare_stripe_publishable', sanitize_text_field( $_POST['smmcare_stripe_publishable'] ?? '' ) );
            update_option( 'smmcare_stripe_webhook_secret', sanitize_text_field( $_POST['smmcare_stripe_webhook_secret'] ?? '' ) );
            update_option( 'smmcare_price_starter', sanitize_text_field( $_POST['smmcare_price_starter'] ?? '' ) );
            update_option( 'smmcare_price_pro', sanitize_text_field( $_POST['smmcare_price_pro'] ?? '' ) );
            update_option( 'smmcare_price_enterprise', sanitize_text_field( $_POST['smmcare_price_enterprise'] ?? '' ) );
            update_option( 'smmcare_branding_logo', esc_url_raw( $_POST['smmcare_branding_logo'] ?? '' ) );
            update_option( 'smmcare_footer_text', sanitize_text_field( $_POST['smmcare_footer_text'] ?? '' ) );
            echo '<div class="updated"><p>Settings saved.</p></div>';
        }
        $openai = esc_attr( get_option( 'smmcare_openai_key', '' ) );
        $stripe_secret = esc_attr( get_option( 'smmcare_stripe_secret', '' ) );
        $stripe_pub = esc_attr( get_option( 'smmcare_stripe_publishable', '' ) );
        $stripe_webhook = esc_attr( get_option( 'smmcare_stripe_webhook_secret', '' ) );
        $logo = esc_url( get_option( 'smmcare_branding_logo', SMMCARE_URL . 'assets/img/smmcare-logo.png' ) );
        $footer = esc_html( get_option( 'smmcare_footer_text', '© SMMCARE LLC' ) );
        ?>
        <div class="wrap"><h1>SMMCARE Pro Settings</h1>
        <form method="post"><?php wp_nonce_field( 'smmcare_settings' ); ?>
        <table class="form-table">
        <tr><th>OpenAI API Key</th><td><input type="text" name="smmcare_openai_key" value="<?php echo $openai; ?>" style="width:60%"/></td></tr>
        <tr><th>Stripe Secret</th><td><input type="text" name="smmcare_stripe_secret" value="<?php echo $stripe_secret; ?>" style="width:60%"/></td></tr>
        <tr><th>Branding Logo URL</th><td><input type="text" name="smmcare_branding_logo" value="<?php echo $logo; ?>" style="width:60%"/> <button id="smmcare_upload_logo_button" class="button">Upload</button></td></tr>
        <tr><th>Footer Text</th><td><input type="text" name="smmcare_footer_text" value="<?php echo $footer; ?>" style="width:60%"/></td></tr>
        </table><p class="submit"><input type="submit" name="smmcare_save_settings" class="button button-primary" value="Save Settings"></p></form></div>
        <?php
    }

    public function register_routes() {
        register_rest_route( 'smmcare/v1', '/payments/create-checkout', [
            'methods' => 'POST',
            'callback' => [ $this, 'create_checkout' ],
            'permission_callback' => function(){ return is_user_logged_in(); },
        ] );
        register_rest_route( 'smmcare/v1', '/payments/webhook', [
            'methods' => 'POST',
            'callback' => [ $this, 'handle_webhook' ],
            'permission_callback' => '__return_true',
        ] );
    }

    private function build_stripe_form_body( $data ) {
        $flat = [];
        $this->flatten_data( $data, '', $flat );
        return $flat;
    }
    private function flatten_data( $data, $prefix, &$out ) {
        if ( is_array( $data ) ) {
            foreach ( $data as $k => $v ) {
                $new = $prefix === '' ? $k : $prefix . '[' . $k . ']';
                $this->flatten_data( $v, $new, $out );
            }
        } else {
            $out[ $prefix ] = $data;
        }
    }
}